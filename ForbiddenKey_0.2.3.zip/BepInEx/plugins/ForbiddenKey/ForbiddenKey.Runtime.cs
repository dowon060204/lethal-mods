// ForbiddenKey 0.2.3 - MIT License. Written for C# 5; actual compilation against the game remains unverified.
// Compiled against the user's installed Unity/BepInEx assemblies by the bootstrap.
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text;
using BepInEx;
using BepInEx.Logging;
using BepInEx.Configuration;
using Unity.Netcode;
using Unity.Collections;
using HarmonyLib;
using UnityEngine;
using UnityEngine.InputSystem;

namespace ForbiddenKey
{
    public enum BanKey { None = -1, W, A, S, D, Shift, Control, E, G, MB1, MB2, ESC, Space, Q }

    [Serializable]
    public sealed class KeyWeights
    {
        public double W = 10, A = 10, S = 10, D = 10, Shift = 10, Control = 10;
        public double E = 5, G = 7, MB1 = 10, MB2 = 10, ESC = 10, Space = 10, Q = 5;
        public double[] ToArray() { return new double[] { W, A, S, D, Shift, Control, E, G, MB1, MB2, ESC, Space, Q }; }
    }

    [Serializable]
    public sealed class Settings
    {
        public int schemaVersion = 2;
        public bool enabled = true;
        public KeyWeights weights = new KeyWeights();
        public string banMessage = "{player}님은 {key} 키를 사용할 수 없습니다.";
        public string releaseMessage = "모든 키 잠금이 해제되었습니다.";
        public bool announceRelease = true;
        public bool tryKoreanFontFallback = true;
        public bool diagnosticLogging = false;
    }

    [Serializable]
    public sealed class PlayerBan
    {
        public string clientId = "";
        public int key = -1;
        public string player = "";
        public string label = "";
        public string error = "";
    }

    [Serializable]
    public sealed class WirePacket
    {
        public int protocol = 4;
        public string kind = "";
        public bool bindingsReady;
        public int acknowledgedRevision = -1;
        public int acknowledgedPlayers = -1;
        public int acknowledgedKey = -2;
        public string acknowledgedDigest = "";
        public string session = "";
        public int roundId;
        public int revision;
        public bool active;
        public bool announceRelease = true;
        public string banMessage = "{player}님은 {key} 키를 사용할 수 없습니다.";
        public string releaseMessage = "모든 키 잠금이 해제되었습니다.";
        public PlayerBan[] entries = new PlayerBan[0];
        public string[] labels = new string[0];
        public bool[] supported = new bool[0];
    }

    // FK4 deliberately does not use Unity's native type serializer. The payload is a
    // bounded, explicit binary layout carried by NGO's already-working string API.
    internal static class WireCodec
    {
        internal const int Protocol = 4;
        internal const int MaxPlayers = 256;
        internal const int MaxBinaryBytes = 48000;
        internal const int MaxTextChars = 64004; // prefix + Base64(48000); fits 128 KiB NGO string.
        private const int Magic = 0x34574B46; // FKW4 in little endian
        private const string Prefix = "FK4:";
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);

        internal static string Encode(WirePacket packet)
        {
            if (packet == null || packet.protocol != Protocol)
                throw new InvalidDataException("Wrong wire protocol.");
            using (MemoryStream stream = new MemoryStream())
            {
                using (BinaryWriter writer = new BinaryWriter(stream, Utf8))
                {
                    writer.Write(Magic); writer.Write(packet.protocol);
                    WriteText(writer, packet.kind, 8);
                    writer.Write(packet.bindingsReady);
                    writer.Write(packet.acknowledgedRevision);
                    writer.Write(packet.acknowledgedPlayers);
                    writer.Write(packet.acknowledgedKey);
                    WriteText(writer, packet.acknowledgedDigest, 64);
                    WriteText(writer, packet.session, 32);
                    writer.Write(packet.roundId); writer.Write(packet.revision);
                    writer.Write(packet.active); writer.Write(packet.announceRelease);
                    WriteText(writer, packet.banMessage, 200);
                    WriteText(writer, packet.releaseMessage, 200);
                    if (packet.entries == null || packet.entries.Length > MaxPlayers)
                        throw new InvalidDataException("Invalid player array.");
                    writer.Write(packet.entries.Length);
                    foreach (PlayerBan item in packet.entries)
                    {
                        if (item == null) throw new InvalidDataException("Null player entry.");
                        WriteText(writer, item.clientId, 20);
                        writer.Write(item.key);
                        WriteText(writer, item.player, 48);
                        WriteText(writer, item.label, 128);
                        WriteText(writer, item.error, 160);
                    }
                    if (packet.labels == null || packet.labels.Length > 13 ||
                        packet.supported == null || packet.supported.Length > 13)
                        throw new InvalidDataException("Invalid binding arrays.");
                    writer.Write(packet.labels.Length);
                    foreach (string label in packet.labels) WriteText(writer, label, 128);
                    writer.Write(packet.supported.Length);
                    foreach (bool supported in packet.supported) writer.Write(supported);
                    writer.Flush();
                    if (stream.Length > MaxBinaryBytes)
                        throw new InvalidDataException("Wire packet exceeds 48000 bytes.");
                    return Prefix + Convert.ToBase64String(stream.ToArray());
                }
            }
        }

        internal static WirePacket Decode(string text)
        {
            if (text == null || text.Length > MaxTextChars || !text.StartsWith(Prefix, StringComparison.Ordinal))
                throw new InvalidDataException("Not an FK4 packet. All players need the same runtime update.");
            byte[] bytes = Convert.FromBase64String(text.Substring(Prefix.Length));
            if (bytes.Length < 8 || bytes.Length > MaxBinaryBytes)
                throw new InvalidDataException("Invalid wire length.");
            using (MemoryStream stream = new MemoryStream(bytes, false))
            using (BinaryReader reader = new BinaryReader(stream, Utf8))
            {
                if (reader.ReadInt32() != Magic || reader.ReadInt32() != Protocol)
                    throw new InvalidDataException("Wrong wire magic/version.");
                WirePacket packet = new WirePacket();
                packet.protocol = Protocol;
                packet.kind = ReadText(reader, 8);
                packet.bindingsReady = ReadFlag(reader);
                packet.acknowledgedRevision = reader.ReadInt32();
                packet.acknowledgedPlayers = reader.ReadInt32();
                packet.acknowledgedKey = reader.ReadInt32();
                packet.acknowledgedDigest = ReadText(reader, 64);
                packet.session = ReadText(reader, 32);
                packet.roundId = reader.ReadInt32(); packet.revision = reader.ReadInt32();
                packet.active = ReadFlag(reader); packet.announceRelease = ReadFlag(reader);
                packet.banMessage = ReadText(reader, 200);
                packet.releaseMessage = ReadText(reader, 200);
                int count = ReadCount(reader, MaxPlayers);
                packet.entries = new PlayerBan[count];
                for (int i = 0; i < count; i++)
                {
                    PlayerBan item = new PlayerBan();
                    item.clientId = ReadText(reader, 20); item.key = reader.ReadInt32();
                    item.player = ReadText(reader, 48); item.label = ReadText(reader, 128);
                    item.error = ReadText(reader, 160);
                    packet.entries[i] = item;
                }
                count = ReadCount(reader, 13); packet.labels = new string[count];
                for (int i = 0; i < count; i++) packet.labels[i] = ReadText(reader, 128);
                count = ReadCount(reader, 13); packet.supported = new bool[count];
                for (int i = 0; i < count; i++) packet.supported[i] = ReadFlag(reader);
                if (stream.Position != stream.Length) throw new InvalidDataException("Trailing wire data.");
                return packet;
            }
        }

        internal static string Digest(WirePacket packet)
        {
            using (SHA256 hash = SHA256.Create())
                return BitConverter.ToString(hash.ComputeHash(Utf8.GetBytes(Encode(packet)))).Replace("-", "");
        }

        private static void WriteText(BinaryWriter writer, string text, int maxChars)
        {
            if (text == null || text.Length > maxChars) throw new InvalidDataException("Invalid text field length.");
            byte[] bytes = Utf8.GetBytes(text);
            writer.Write(bytes.Length); writer.Write(bytes);
        }

        private static string ReadText(BinaryReader reader, int maxChars)
        {
            int size = reader.ReadInt32();
            if (size < 0 || size > maxChars * 4 || size > reader.BaseStream.Length - reader.BaseStream.Position)
                throw new InvalidDataException("Invalid text byte length.");
            byte[] bytes = reader.ReadBytes(size);
            if (bytes.Length != size) throw new EndOfStreamException();
            string text = Utf8.GetString(bytes);
            if (text.Length > maxChars) throw new InvalidDataException("Text character limit exceeded.");
            return text;
        }

        private static int ReadCount(BinaryReader reader, int maximum)
        {
            int count = reader.ReadInt32();
            if (count < 0 || count > maximum) throw new InvalidDataException("Invalid array count.");
            return count;
        }

        private static bool ReadFlag(BinaryReader reader)
        {
            byte value = reader.ReadByte();
            if (value > 1) throw new InvalidDataException("Invalid boolean.");
            return value != 0;
        }

        internal static WirePacket ProbeState()
        {
            WirePacket packet = new WirePacket();
            packet.kind = "state"; packet.session = new string('a', 32);
            packet.roundId = 1; packet.revision = 1; packet.active = true;
            packet.entries = new PlayerBan[] {
                new PlayerBan { clientId = "0", key = 0, player = "테스트1", label = "W" },
                new PlayerBan { clientId = "7", key = 11, player = "테스트2", label = "Space" },
                new PlayerBan { clientId = "42", key = 6, player = "테스트3", label = "E" },
                new PlayerBan { clientId = "108", key = 9, player = "테스트4", label = "마우스 우클릭" }
            };
            return packet;
        }

        // This executes in the real CLR at plugin startup, not in the Python model.
        // Passing means the wire codec survived a local round-trip, NOT multiplayer verification.
        internal static void SelfTest()
        {
            WirePacket source = ProbeState();
            string encoded = Encode(source);
            WirePacket decoded = Decode(encoded);
            if (decoded.entries.Length != 4 || Encode(decoded) != encoded ||
                decoded.entries[1].clientId != "7" || decoded.entries[1].key != 11 ||
                decoded.entries[3].label != "마우스 우클릭" || Digest(source) != Digest(decoded))
                throw new InvalidDataException("FK4 codec self-test failed: four-player roster lost.");
            // Independent Python reference vector; checks the precise .NET wire layout.
            if (Digest(source) != "CD3B962FDA7D035A3A1E420813E51A785CFB9B869B0D3B295FF399820BC67D20")
                throw new InvalidDataException("FK4 codec differs from the reference byte layout.");
            bool rejected = false;
            byte[] raw = Convert.FromBase64String(encoded.Substring(Prefix.Length));
            Array.Resize(ref raw, raw.Length - 1);
            try { Decode(Prefix + Convert.ToBase64String(raw)); }
            catch (Exception) { rejected = true; }
            if (!rejected) throw new InvalidDataException("FK4 codec accepted a truncated packet.");
        }
    }

    public static class DebugKeyParser
    {
        public const string Allowed = "W, A, S, D, Shift, Space, E, G, Q, ESC, MB1, MB2";
        public static bool TryParse(string text, out BanKey key)
        {
            key = BanKey.None;
            switch ((text ?? "").Trim().ToUpperInvariant())
            {
                case "W": key = BanKey.W; break;
                case "A": key = BanKey.A; break;
                case "S": key = BanKey.S; break;
                case "D": key = BanKey.D; break;
                case "SHIFT": key = BanKey.Shift; break;
                case "SPACE": key = BanKey.Space; break;
                case "E": key = BanKey.E; break;
                case "G": key = BanKey.G; break;
                case "Q": key = BanKey.Q; break;
                case "ESC": key = BanKey.ESC; break;
                case "MB1": key = BanKey.MB1; break;
                case "MB2": key = BanKey.MB2; break;
                default: return false; // Ctrl/Control/Tab/numeric enum values are NOT accepted.
            }
            return true;
        }
    }

    internal static class SafeText
    {
        public static string Clean(string value, int max)
        {
            StringBuilder b = new StringBuilder();
            string input = value ?? "";
            for (int i = 0; i < input.Length && b.Length < max; i++)
            {
                char c = input[i];
                if (char.IsHighSurrogate(c))
                {
                    if (i + 1 >= input.Length || !char.IsLowSurrogate(input[i + 1])) { b.Append('?'); continue; }
                    if (b.Length + 2 > max) break;
                    b.Append(c); b.Append(input[++i]); continue;
                }
                if (char.IsLowSurrogate(c)) { b.Append('?'); continue; }
                if (char.IsControl(c)) { b.Append(' '); continue; }
                b.Append(c == '<' ? '[' : c == '>' ? ']' : c);
            }
            return b.ToString().Trim();
        }
        public static string Format(string template, string player, string key)
        {
            // Replace tokens only in the template, never inside a user's name or binding label.
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < template.Length; )
            {
                if (i + 8 <= template.Length && string.CompareOrdinal(template, i, "{player}", 0, 8) == 0)
                { result.Append(Clean(player, 48)); i += 8; }
                else if (i + 5 <= template.Length && string.CompareOrdinal(template, i, "{key}", 0, 5) == 0)
                { result.Append(Clean(key, 128)); i += 5; }
                else result.Append(template[i++]);
            }
            return result.ToString();
        }
    }

    public static class WeightedPicker
    {
        // Normalize by the maximum so that summing large finite weights cannot overflow.
        // Returns -1 for all-zero weights. Reject invalid weights instead of silently changing odds.
        public static int Pick(double[] weights, double sample)
        {
            if (weights == null || weights.Length == 0) throw new ArgumentException("No weights.");
            if (double.IsNaN(sample) || sample < 0 || sample >= 1) throw new ArgumentOutOfRangeException("sample");
            double max = 0;
            for (int i = 0; i < weights.Length; i++)
            {
                double w = weights[i];
                if (double.IsNaN(w) || double.IsInfinity(w) || w < 0) throw new ArgumentException("Weights must be finite and non-negative.");
                if (w > max) max = w;
            }
            if (max == 0) return -1;
            double total = 0;
            for (int i = 0; i < weights.Length; i++) total += weights[i] / max;
            double target = sample * total, cumulative = 0;
            int last = -1;
            for (int i = 0; i < weights.Length; i++)
            {
                if (weights[i] <= 0) continue;
                last = i;
                cumulative += weights[i] / max;
                if (target < cumulative) return i;
            }
            return last; // Rounding protection at the upper endpoint.
        }

        public static Vector2 FilterDirection(Vector2 value, BanKey key)
        {
            if (key == BanKey.W && value.y > 0) value.y = 0;
            if (key == BanKey.S && value.y < 0) value.y = 0;
            if (key == BanKey.A && value.x < 0) value.x = 0;
            if (key == BanKey.D && value.x > 0) value.x = 0;
            return value;
        }
    }

    // Reflection is deliberate: game-private members are not compiled into the binary ABI.
    internal static class Game
    {
        private const BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance;
        private static readonly Dictionary<string, Type> Types = new Dictionary<string, Type>();
        private static readonly Dictionary<string, MemberInfo> Members = new Dictionary<string, MemberInfo>();
        public static Type Type(string name)
        {
            Type t;
            if (!Types.TryGetValue(name, out t) || t == null) { t = AccessTools.TypeByName(name); Types[name] = t; }
            return t;
        }
        public static object Get(object owner, string name)
        {
            if (owner == null) return null;
            Type t = owner as Type;
            bool isStatic = t != null;
            if (!isStatic) t = owner.GetType();
            string key = t.AssemblyQualifiedName + "|" + name;
            MemberInfo m;
            if (!Members.TryGetValue(key, out m))
            {
                m = (MemberInfo)AccessTools.Field(t, name) ?? (MemberInfo)AccessTools.Property(t, name);
                Members[key] = m;
            }
            FieldInfo f = m as FieldInfo;
            if (f != null) return f.GetValue(isStatic ? null : owner);
            PropertyInfo p = m as PropertyInfo;
            return p == null ? null : p.GetValue(isStatic ? null : owner, null);
        }
        public static bool Bool(object owner, string name, bool fallback)
        {
            object value = Get(owner, name);
            return value is bool ? (bool)value : fallback;
        }
        public static void Set(object owner, string name, object value)
        {
            if (owner == null) return;
            FieldInfo f = AccessTools.Field(owner.GetType(), name);
            if (f != null) f.SetValue(owner, value);
            else
            {
                PropertyInfo p = AccessTools.Property(owner.GetType(), name);
                if (p != null && p.CanWrite) p.SetValue(owner, value, null);
            }
        }
        public static object Singleton(string name)
        {
            Type t = Type(name);
            if (t == null) return null;
            object value = Get(t, "Instance");
            UnityEngine.Object unity = value as UnityEngine.Object;
            if (!object.ReferenceEquals(unity, null) && unity == null) return null;
            return value;
        }
        public static object Player()
        {
            object player = Get(Singleton("GameNetworkManager"), "localPlayerController");
            UnityEngine.Object unity = player as UnityEngine.Object;
            if (player != null && (object.ReferenceEquals(unity, null) || unity != null)) return player;
            player = Get(Singleton("StartOfRound"), "localPlayerController");
            unity = player as UnityEngine.Object;
            return !object.ReferenceEquals(unity, null) && unity == null ? null : player;
        }
        public static bool MenuOpen()
        {
            return Bool(Get(Player(), "quickMenuManager"), "isMenuOpen", false);
        }
        public static MethodInfo Method(Type type, string name, int count)
        {
            if (type == null) return null;
            foreach (MethodInfo m in type.GetMethods(Flags)) if (m.Name == name && m.GetParameters().Length == count) return m;
            return null;
        }
    }

    public static class RuntimeEntry
    {
        public static void Start(object loader, string pluginDirectory)
        {
            if (ForbiddenKeyRuntime.Instance != null) return;
            BaseUnityPlugin plugin = loader as BaseUnityPlugin;
            if (plugin == null) throw new ArgumentException("A live BepInEx loader is required.", "loader");
            ForbiddenKeyRuntime.PluginDirectory = pluginDirectory;
            // Keep the managed ConfigFile, not a Unity component that may be destroyed.
            // File path and entries remain exactly those of the existing loader config.
            ForbiddenKeyRuntime.DeveloperConfig = plugin.Config;

            // Defence in depth for an old loader: protect the shared manager too.
            // The 0.2.3 DLL already applies this before runtime compilation/loading.
            GameObject managerObject = plugin.gameObject;
            managerObject.hideFlags |= HideFlags.HideAndDontSave;
            UnityEngine.Object.DontDestroyOnLoad(managerObject);

            // A separate, unparented root prevents destruction of another plugin's
            // shared object from automatically destroying our update/network loop.
            GameObject runtimeObject = new GameObject("ForbiddenKey_Runtime");
            try
            {
                // Set flags BEFORE AddComponent: changing flags can trigger Unity
                // enable/disable notifications; no runtime hooks exist yet here.
                runtimeObject.hideFlags |= HideFlags.HideAndDontSave;
                UnityEngine.Object.DontDestroyOnLoad(runtimeObject);
                runtimeObject.AddComponent<ForbiddenKeyRuntime>();
            }
            catch
            {
                UnityEngine.Object.Destroy(runtimeObject);
                throw;
            }
        }
    }

    public sealed class ForbiddenKeyRuntime : MonoBehaviour
    {
        public static ForbiddenKeyRuntime Instance;
        internal static string PluginDirectory;
        internal static ManualLogSource Log;
        public BanKey Current = BanKey.None;
        internal bool Ready;
        private Harmony harmony;
        private Settings settings = new Settings();
        private System.Random random;
        private object round;
        private bool leftOrbit, pendingPick;
        private float nextRefresh;
        private readonly Queue<string> pendingChat = new Queue<string>();
        private readonly List<string> noticeHistory = new List<string>();
        private float nextChatRetry;
        private bool chatWasOpen;
        private bool chatUpdateWarned;
        private readonly List<InputActionAsset> assets = new List<InputActionAsset>();
        private readonly HashSet<InputActionAsset> assetSet = new HashSet<InputActionAsset>();
        private bool labelsDirty = true;
        private bool faulted;
        private bool quitting;
        private bool heartbeatLogged;

        private void Awake()
        {
            // A duplicate component must never take ownership of the live instance
            // or unpatch its hooks when Unity destroys the duplicate.
            if (Instance != null && !object.ReferenceEquals(Instance, this))
            {
                enabled = false;
                UnityEngine.Object.Destroy(this);
                return;
            }
            Instance = this;
            Log = BepInEx.Logging.Logger.CreateLogSource("ForbiddenKey");
            try
            {
                Log.LogInfo("Lifecycle 0.2.3: independent protected runtime root; BetterSpectate is not required.");
                byte[] seed = new byte[4];
                using (RandomNumberGenerator rng = RandomNumberGenerator.Create()) rng.GetBytes(seed);
                random = new System.Random(BitConverter.ToInt32(seed, 0));
                WireCodec.SelfTest();
                Log.LogInfo("FK4 codec self-test passed: 4 player entries and Korean labels survived a local round-trip.");
                // Diagnose the OLD conversion in the user's real Unity environment, once.
                // Its result never controls FK4, and no real player data is used here.
                try
                {
                    WirePacket probe = JsonUtility.FromJson<WirePacket>(JsonUtility.ToJson(WireCodec.ProbeState()));
                    int count = probe == null || probe.entries == null ? -1 : probe.entries.Length;
                    Log.LogInfo("Legacy JSON probe (diagnostic only): expectedPlayers=4, decodedPlayers=" + count + ". FK4 does not use JsonUtility for networking.");
                }
                catch (Exception probeError) { Log.LogWarning("Legacy JSON probe failed (FK4 is independent): " + probeError.Message); }
                InitDeveloperConfig();
                LoadSettings();
                network = new NetworkBridge(this);
                harmony = new Harmony("local.forbiddenkey.runtime");
                Ready = Patches.Install(harmony);
                ChatHooks.Install(harmony);
                ChatHooks.InstallJoinFilters(harmony);
                InputSystem.onActionChange += OnActionChange;
                Log.LogInfo("ForbiddenKey 0.2.3: host-authoritative independent player draws; protocol=4; explicit FK4 roster codec; content-checked acknowledgements. Ready=" + Ready);
                Log.LogInfo("Config: " + Path.Combine(Paths.ConfigPath, "ForbiddenKey.json"));
            }
            catch (Exception e) { Fail(e); }
        }

        private void OnApplicationQuit()
        {
            quitting = true;
        }

        private void OnDestroy()
        {
            // A duplicate is not the owner and must leave the live runtime alone.
            if (!object.ReferenceEquals(Instance, this)) return;
            Ready = false; Current = BanKey.None; debugWindow = false;
            if (Log != null)
            {
                if (quitting) Log.LogInfo("ForbiddenKey runtime stopped: application quit.");
                else Log.LogWarning("Protected ForbiddenKey runtime was destroyed before quit. Input restrictions are cleared; inspect other plugins or game cleanup.");
            }
            try
            {
                InputSystem.onActionChange -= OnActionChange;
                if (network != null) network.Detach();
            }
            catch (Exception e) { if (Log != null) Log.LogWarning("Runtime detach: " + e.Message); }
            try { if (harmony != null) harmony.UnpatchSelf(); }
            catch (Exception e) { if (Log != null) Log.LogWarning("Runtime unpatch: " + e.Message); }
            if (debugSkin != null) UnityEngine.Object.Destroy(debugSkin);
            Instance = null;
            DeveloperConfig = null;
        }

        private void OnActionChange(object changed, InputActionChange change)
        {
            if (change == InputActionChange.BoundControlsChanged) { labelsDirty = true; if (network != null) network.MarkBindingsDirty(); }
        }

        internal void Fail(Exception e)
        {
            if (!faulted && Log != null) Log.LogError("Disabled safely after an error: " + e);
            faulted = true; Ready = false; Current = BanKey.None;
            pendingPick = false;
            if (network != null) network.Detach();
        }

        private void LoadSettings()
        {
            string file = Path.Combine(Paths.ConfigPath, "ForbiddenKey.json");
            try
            {
                Directory.CreateDirectory(Paths.ConfigPath);
                if (!File.Exists(file))
                {
                    string template = Path.Combine(PluginDirectory, "ForbiddenKey.default.json");
                    if (File.Exists(template)) File.Copy(template, file);
                    else File.WriteAllText(file, JsonUtility.ToJson(new Settings(), true), new UTF8Encoding(false));
                }
                if (new FileInfo(file).Length > 65536) throw new InvalidDataException("Config exceeds 64 KiB.");
                Settings next = new Settings();
                string json = File.ReadAllText(file, Encoding.UTF8);
                if (!json.TrimStart().StartsWith("{")) throw new InvalidDataException("Config must be a JSON object.");
                JsonUtility.FromJsonOverwrite(json, next);
                if (next.schemaVersion == 1)
                {
                    // Explicit one-time update to requested defaults, with an untouched backup.
                    string backup = file + ".pre-0.2.0.bak";
                    int suffix = 1;
                    while (File.Exists(backup)) backup = file + ".pre-0.2.0." + (suffix++) + ".bak";
                    File.Copy(file, backup);
                    next.schemaVersion = 2; next.weights = new KeyWeights();
                    next.banMessage = "{player}님은 {key} 키를 사용할 수 없습니다.";
                    next.releaseMessage = "모든 키 잠금이 해제되었습니다.";
                    File.WriteAllText(file, JsonUtility.ToJson(next, true), new UTF8Encoding(false));
                    Log.LogInfo("Migrated schema 1 to requested 0.2.0 defaults; original config backed up at " + backup);
                }
                if (next.schemaVersion != 2 || next.weights == null) throw new InvalidDataException("Unsupported config schema.");
                WeightedPicker.Pick(next.weights.ToArray(), 0); // Validation, not the draw.
                if (string.IsNullOrEmpty(next.banMessage) || !next.banMessage.Contains("{key}") || !next.banMessage.Contains("{player}") || next.banMessage.Length > 200)
                    throw new InvalidDataException("banMessage must contain {player} and {key} and have at most 200 characters.");
                if (next.releaseMessage == null || next.releaseMessage.Length > 200) throw new InvalidDataException("Invalid releaseMessage.");
                settings = next;
            }
            catch (Exception e)
            {
                // Retain last known good settings rather than allowing a mid-session bypass.
                Log.LogError("Config not applied; keeping last valid settings. " + e.Message);
            }
        }

        internal void BeginRound()
        {
            if (!Ready || network == null) return;
            network.Tick();
            if (!network.IsHost || network.Active) return;
            object currentRound = Game.Singleton("StartOfRound");
            if (currentRound == null) return;
            round = currentRound;
            leftOrbit = !Game.Bool(round, "inShipPhase", true);
            LoadSettings();
            BanKey forced = ReadForcedKey(); // Capture once; editing the config cannot change an active ban.
            network.Begin(settings, forced);
            labelsDirty = true; nextRefresh = 0;
        }

        internal void EndRound(bool announce)
        {
            if (!announce)
            {
                if (network != null) network.Detach();
                ResetLocalSession();
                return;
            }
            if (network != null && network.IsHost) network.End();
            leftOrbit = false;
        }

        private void Update()
        {
            if (!Ready) return;
            try
            {
                if (!heartbeatLogged)
                {
                    heartbeatLogged = true;
                    Log.LogInfo("Runtime update loop active; persistent root=ForbiddenKey_Runtime.");
                }
                HandleDebugHotkey();
                if (labelsDirty || Time.unscaledTime >= nextRefresh)
                {
                    RefreshAssets(); nextRefresh = Time.unscaledTime + 0.5f; labelsDirty = false;
                }
                network.Tick(); // Transient networking errors are retried inside the bridge.
                object currentRound = Game.Singleton("StartOfRound");
                if (currentRound == null) { UpdateChat(); return; }
                if (!object.ReferenceEquals(round, currentRound))
                { round = currentRound; assets.Clear(); assetSet.Clear(); labelsDirty = true; }
                bool inOrbit = Game.Bool(round, "inShipPhase", true);
                if (network.IsHost)
                {
                    if (!network.Active && !inOrbit) BeginRound(); // Recovery if a start hook was missed.
                    if (network.Active)
                    {
                        if (!inOrbit) leftOrbit = true;
                        // Never unlock on the departure lever, ShipHasLeft, or shipIsLeaving.
                        if (leftOrbit && inOrbit) EndRound(true);
                    }
                }
                if (labelsDirty || Time.unscaledTime >= nextRefresh)
                { RefreshAssets(); nextRefresh = Time.unscaledTime + 0.5f; labelsDirty = false; }
                if (cancelPending && Current != BanKey.None && Game.Player() != null && assets.Count > 0)
                {
                    cancelPending = false;
                    CancelCurrentInput();
                    if (Current == BanKey.Control)
                    {
                        object player = Game.Player();
                        MethodInfo crouch = Game.Method(player.GetType(), "Crouch", 1);
                        if (crouch != null && Game.Bool(player, "isCrouching", false)) crouch.Invoke(player, new object[] { false });
                    }
                }
                // Existing safety exception: F10 opens ONLY the pause menu while ESC is banned.
                if (Current == BanKey.ESC && Keyboard.current != null && Keyboard.current.f10Key.wasPressedThisFrame && !Game.MenuOpen())
                {
                    object menu = Game.Get(Game.Player(), "quickMenuManager");
                    MethodInfo open = menu == null ? null : Game.Method(menu.GetType(), "OpenQuickMenu", 0);
                    if (open != null) open.Invoke(menu, null);
                }
                UpdateChat();
            }
            catch (Exception e) { Fail(e); }
        }

        private void CancelCurrentInput()
        {
            // Flush pre-existing held input via normal cancellation, without changing bindings.
            // This runs in MonoBehaviour.Update, not inside an Input System event callback.
            foreach (InputActionAsset asset in assets)
                foreach (InputAction action in asset)
                    if (action.enabled && InputGate.Matches(Current, action))
                    { action.Disable(); action.Enable(); }
        }

        private void Announce(string text)
        {
            if (string.IsNullOrEmpty(text)) return;
            Log.LogInfo(text);
            noticeHistory.Add(text); // Only our notices, never other players' chat.
            QueueLocal(text);
        }

        private void QueueLocal(string text)
        {
            if (!string.IsNullOrEmpty(text)) pendingChat.Enqueue(text);
            FlushChat();
        }

        private void FlushChat()
        {
            if (Time.unscaledTime < nextChatRetry) return;
            int budget = 4;
            while (pendingChat.Count > 0 && budget-- > 0)
            {
                if (!Chat.TryWrite(pendingChat.Peek(), settings.tryKoreanFontFallback))
                {
                    nextChatRetry = Time.unscaledTime + 0.5f;
                    return;
                }
                pendingChat.Dequeue();
            }
        }

        private void UpdateChat()
        {
            // Chat/UI problems must not disable the action restriction itself.
            try
            {
                object hud = Game.Singleton("HUDManager");
                bool open = Game.Bool(Game.Player(), "isTypingChat", false) ||
                    Game.Bool(Game.Get(hud, "chatTextField"), "isFocused", false);
                if (pendingRosterText.Length > 0 && Time.unscaledTime >= rosterNoticeDue)
                {
                    string notice = pendingRosterText; pendingRosterText = "";
                    Announce(notice);
                }
                if (open && !chatWasOpen && applied != null && applied.active)
                {
                    string text = RenderRoster(applied);
                    // Vanilla only retains a short recent-message window. Restore the current
                    // status on opening chat if it has scrolled out; do not append every frame.
                    if (text.Length > 0 && pendingRosterText.Length == 0 &&
                        !Chat.ContainsRecent(hud, text, 4) && !pendingChat.Contains(text)) QueueLocal(text);
                }
                chatWasOpen = open;
                FlushChat();
            }
            catch (Exception e)
            {
                if (!chatUpdateWarned) { chatUpdateWarned = true; Log.LogWarning("Chat refresh failed: " + e.Message); }
            }
        }

        internal string CurrentStatusText()
        {
            if (!Ready) return "[ForbiddenKey] 모드가 비활성화되어 있습니다. 로그를 확인하세요.";
            if (pendingPick) return "[ForbiddenKey] 호스트의 플레이어별 금지 키 배정을 기다리고 있습니다.";
            if (applied == null && network != null && network.Connected && !network.IsHost)
                return "[ForbiddenKey] 호스트의 상태를 기다리고 있습니다. 전원 0.2.1 설치를 확인하세요.";
            if (Current == BanKey.None) return "현재 금지된 키가 없습니다.";
            string name = SafeText.Clean(Convert.ToString(Game.Get(Game.Player(), "playerUsername")), 48);
            return SafeText.Format(applied == null ? settings.banMessage : applied.banMessage, name, BindingLabel(Current));
        }

        internal static bool IsLocalChatCommand(string text)
        {
            string[] words = ChatCommandWords(text);
            if (words.Length == 0) return false;
            return string.Equals(words[0], "/fk", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(words[0], "/forbiddenkey", StringComparison.OrdinalIgnoreCase) || words[0] == "/금지";
        }

        private static string[] ChatCommandWords(string text)
        {
            return (text ?? "").Trim().Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
        }

        internal void HandleLocalChatCommand(string text)
        {
            string[] words = ChatCommandWords(text);
            if (words.Length == 1) { QueueLocal(CurrentStatusText()); return; }
            if (words.Length == 2 && (words[1] == "동기화" || string.Equals(words[1], "sync", StringComparison.OrdinalIgnoreCase)))
            {
                QueueLocal(network == null ? "[ForbiddenKey] 네트워크 초기화 전입니다." : network.DiagnosticStatus());
                return;
            }
            if (string.Equals(words[1], "all", StringComparison.OrdinalIgnoreCase) || words[1] == "전체")
            {
                int allPage = 1;
                if (words.Length > 3 || (words.Length == 3 && (!int.TryParse(words[2], out allPage) || allPage < 1)))
                    QueueLocal("[ForbiddenKey] /금지 전체 [페이지]");
                else ShowAllStatus(allPage);
                return;
            }
            bool history = string.Equals(words[1], "history", StringComparison.OrdinalIgnoreCase) || words[1] == "기록";
            int page = 1;
            if (!history || words.Length > 3 || (words.Length == 3 && (!int.TryParse(words[2], out page) || page < 1)))
            {
                QueueLocal("[ForbiddenKey] /금지 : 내 상태 | /금지 전체 [페이지] | /금지 기록 [페이지]");
                return;
            }
            if (noticeHistory.Count == 0) { QueueLocal("[ForbiddenKey] 이번 접속에 저장된 금지 키 안내가 없습니다."); return; }
            const int pageSize = 3; // One heading + three records fits vanilla's four-message window.
            int pages = (noticeHistory.Count - 1) / pageSize + 1;
            if (page > pages) { QueueLocal("[ForbiddenKey] 기록 페이지는 1~" + pages + "까지입니다."); return; }
            QueueLocal("[ForbiddenKey] 기록 " + page + "/" + pages + " (이번 접속, 최신순)");
            int top = noticeHistory.Count - 1 - (page - 1) * pageSize;
            for (int i = top; i >= 0 && i > top - pageSize; i--)
                QueueLocal("[" + (i + 1) + "] " + noticeHistory[i]);
            // Query results are NOT recorded again and never cause a new weighted draw.
        }

        internal static ConfigFile DeveloperConfig;
        private ConfigEntry<bool> debugMode;
        private ConfigEntry<string> forcedKeyText;
        private NetworkBridge network;
        private WirePacket applied;
        private int appliedRevision = -1;
        private bool cancelPending;
        private bool debugWindow;
        private bool debugDraftEnabled;
        private string debugDraftKey = "", debugFeedback = "";
        private Rect debugRect = new Rect(40, 80, 580, 315);
        private GUISkin debugSkin;
        internal bool DebugWindowVisible { get { return debugWindow; } }

        private void InitDeveloperConfig()
        {
            if (DeveloperConfig == null) throw new InvalidOperationException("Missing BepInEx ConfigFile.");
            debugMode = DeveloperConfig.Bind<bool>("개발자", "디버그 모드", false,
                "호스트 전용 테스트 옵션. 체크한 경우에만 특정 키만 금지를 사용합니다. 다음 출발부터 적용됩니다.");
            forcedKeyText = DeveloperConfig.Bind<string>("개발자", "특정 키만 금지", "",
                "허용: " + DebugKeyParser.Allowed + ". 빈 값은 일반 추첨입니다. Ctrl/Control/Tab은 허용하지 않습니다. 다음 출발부터 적용됩니다.");
        }

        private BanKey ReadForcedKey()
        {
            try { DeveloperConfig.Reload(); }
            catch (Exception e) { Log.LogWarning("Developer config reload failed; retaining last values: " + e.Message); }
            if (!debugMode.Value || string.IsNullOrWhiteSpace(forcedKeyText.Value)) return BanKey.None;
            BanKey result;
            if (DebugKeyParser.TryParse(forcedKeyText.Value, out result)) return result;
            SystemNotice("[ForbiddenKey] 특정 키만 금지 입력이 잘못되어 일반 추첨을 사용합니다. 허용: " + DebugKeyParser.Allowed);
            return BanKey.None;
        }

        internal double NextSample() { return random.NextDouble(); }

        internal WirePacket BuildHello()
        {
            WirePacket hello = new WirePacket(); hello.kind = "hello";
            hello.bindingsReady = Ready && Game.Player() != null && assets.Count > 0;
            hello.labels = new string[13]; hello.supported = new bool[13];
            for (int i = 0; i < 13; i++)
            {
                hello.labels[i] = hello.bindingsReady ? SafeText.Clean(BindingLabel((BanKey)i), 128) : DefaultLabel((BanKey)i);
                hello.supported[i] = hello.bindingsReady && HasAction((BanKey)i);
            }
            return hello;
        }

        internal static string DefaultLabel(BanKey key)
        {
            if (key == BanKey.MB1) return "마우스 좌클릭";
            if (key == BanKey.MB2) return "마우스 우클릭";
            if (key == BanKey.Control) return "Ctrl";
            return key == BanKey.None ? "" : key.ToString();
        }

        private string pendingRosterText = "";
        private float rosterNoticeDue;
        private string lastRosterText = "";
        private int lastRosterRound = -1;

        internal static string RenderRoster(WirePacket packet)
        {
            StringBuilder text = new StringBuilder();
            if (packet == null || !packet.active) return "";
            foreach (PlayerBan item in packet.entries)
            {
                if (item.key < 0) continue;
                if (text.Length > 0) text.Append('\n');
                text.Append(SafeText.Format(packet.banMessage, item.player, item.label));
            }
            return text.ToString();
        }

        // Return success only AFTER applying the restriction and queuing its roster.
        // The bridge must not acknowledge a snapshot that failed local application.
        internal bool ApplyState(WirePacket packet, ulong localId)
        {
            // An active snapshot without THIS client is incomplete, not an unlock.
            // Preserve the previous ban and do not acknowledge the broken snapshot.
            if (packet == null || packet.entries == null ||
                (packet.active && !HasLocalEntry(packet, localId))) return false;
            bool sameSession = applied != null && packet.session == applied.session;
            if (sameSession && packet.revision <= appliedRevision) return true;
            WirePacket previous = applied;
            bool newRound = !sameSession || previous == null || packet.roundId != previous.roundId;
            BanKey oldKey = Current;
            BanKey selected = BanKey.None;
            foreach (PlayerBan item in packet.entries)
            {
                if (item.clientId != localId.ToString(System.Globalization.CultureInfo.InvariantCulture)) continue;
                if (packet.active && item.key >= 0)
                {
                    selected = (BanKey)item.key;
                    if (item.error.Length > 0) Log.LogWarning(item.error + "; selected ban retained.");
                }
                break;
            }
            Current = selected;
            applied = packet; appliedRevision = packet.revision;
            pendingPick = packet.active && !HasLocalEntry(packet, localId);
            if (Current != oldKey || newRound) cancelPending = Current != BanKey.None;
            if (packet.active)
            {
                string roster = RenderRoster(packet);
                bool shouldAnnounce = roster.Length > 0 &&
                    (newRound || lastRosterRound != packet.roundId || roster != lastRosterText);
                if (shouldAnnounce)
                {
                    // A short coalescing window gathers labels that arrive just after the lever.
                    // Input blocking is already active; only the chat presentation is deferred.
                    if (pendingRosterText.Length == 0 || newRound) rosterNoticeDue = Time.unscaledTime + 0.35f;
                    pendingRosterText = roster;
                    lastRosterText = roster; lastRosterRound = packet.roundId;
                }
                else if (roster.Length == 0)
                {
                    pendingRosterText = ""; lastRosterText = ""; lastRosterRound = packet.roundId;
                }
            }
            else
            {
                // Never let a delayed lock notice appear AFTER the release notice.
                pendingRosterText = ""; lastRosterText = ""; lastRosterRound = -1;
                if (sameSession && previous != null && previous.active && packet.announceRelease)
                    Announce(packet.releaseMessage);
            }
            Log.LogInfo("Applied state: local=" + localId + ", round=" + packet.roundId +
                ", revision=" + packet.revision + ", players=" + packet.entries.Length + ", key=" + Current + ".");
            return true;
        }

        internal static bool HasLocalEntry(WirePacket packet, ulong id)
        {
            foreach (PlayerBan item in packet.entries)
                if (item.clientId == id.ToString(System.Globalization.CultureInfo.InvariantCulture)) return true;
            return false;
        }

        internal void ResetLocalSession()
        {
            Current = BanKey.None; applied = null; appliedRevision = -1;
            leftOrbit = pendingPick = cancelPending = false;
            round = null;
            pendingChat.Clear(); noticeHistory.Clear(); nextChatRetry = 0; chatWasOpen = false;
            assets.Clear(); assetSet.Clear(); labelsDirty = true; nextRefresh = 0;
            pendingRosterText = lastRosterText = ""; lastRosterRound = -1; rosterNoticeDue = 0;
        }

        internal void SystemNotice(string text) { Announce(text); }

        private void HandleDebugHotkey()
        {
            if (Keyboard.current == null || !Keyboard.current.f8Key.wasPressedThisFrame) return;
            if (debugWindow) { debugWindow = false; return; }
            // The in-game pause menu already owns cursor/input. The debug panel never
            // releases restrictions or opens an unrestricted mid-round gameplay overlay.
            if (Game.Player() != null && !Game.MenuOpen())
            {
                QueueLocal("[ForbiddenKey] 일시정지 메뉴를 연 뒤 F8을 누르세요. ESC 금지 중에는 F10으로 메뉴를 열 수 있습니다.");
                return;
            }
            try { DeveloperConfig.Reload(); } catch (Exception e) { Log.LogWarning(e.Message); }
            debugDraftEnabled = debugMode.Value; debugDraftKey = forcedKeyText.Value;
            debugFeedback = ""; debugWindow = true;
            debugRect.x = Mathf.Max(10, (Screen.width - debugRect.width) / 2f);
            debugRect.y = Mathf.Max(10, (Screen.height - debugRect.height) / 2f);
        }

        private void OnGUI()
        {
            if (!Ready || !debugWindow) return;
            if (Game.Player() != null && !Game.MenuOpen()) { debugWindow = false; return; }
            GUISkin previous = GUI.skin;
            try
            {
                if (debugSkin == null)
                {
                    debugSkin = UnityEngine.Object.Instantiate(GUI.skin) as GUISkin;
                    Font font = Font.CreateDynamicFontFromOSFont(new string[] { "Malgun Gothic", "Apple SD Gothic Neo", "Noto Sans CJK KR" }, 17);
                    if (font != null) debugSkin.font = font;
                    debugSkin.label.wordWrap = true;
                }
                GUI.skin = debugSkin;
                debugRect = GUI.Window(170212006, debugRect, DrawDebugWindow, "ForbiddenKey 0.2.3 - 개발자 설정");
            }
            catch (Exception e) { debugWindow = false; Log.LogWarning("Debug window unavailable; use the .cfg file: " + e.Message); }
            finally { GUI.skin = previous; GUI.enabled = true; }
        }

        private void DrawDebugWindow(int id)
        {
            bool canEdit = network == null || !network.Connected || network.IsHost;
            GUILayout.Space(12);
            GUILayout.Label("호스트 설정만 사용하며, 저장한 값은 다음 함선 출발부터 적용됩니다.");
            if (!canEdit) GUILayout.Label("현재 클라이언트입니다. 호스트만 이 설정을 변경할 수 있습니다.");
            GUI.enabled = canEdit;
            debugDraftEnabled = GUILayout.Toggle(debugDraftEnabled, "디버그 모드");
            GUI.enabled = canEdit && debugDraftEnabled;
            GUILayout.Label("특정 키만 금지");
            debugDraftKey = GUILayout.TextField(debugDraftKey ?? "", 32);
            GUILayout.Label("허용: " + DebugKeyParser.Allowed);
            GUI.enabled = canEdit;
            GUILayout.Label("빈 값: 일반 가중치 추첨. 디버그 모드가 꺼져 있으면 입력값을 무시합니다.");
            BanKey parsed;
            bool valid = !debugDraftEnabled || string.IsNullOrWhiteSpace(debugDraftKey) || DebugKeyParser.TryParse(debugDraftKey, out parsed);
            if (!valid) GUILayout.Label("지원하지 않는 입력입니다. Ctrl/Control/Tab은 강제 지정할 수 없습니다.");
            GUILayout.BeginHorizontal();
            GUI.enabled = canEdit && valid;
            if (GUILayout.Button("저장 (다음 출발부터)"))
            {
                debugMode.Value = debugDraftEnabled;
                forcedKeyText.Value = (debugDraftKey ?? "").Trim();
                DeveloperConfig.Save();
                debugFeedback = "저장했습니다. 현재 라운드의 금지 키는 바뀌지 않습니다.";
            }
            GUI.enabled = true;
            if (GUILayout.Button("닫기")) debugWindow = false;
            GUILayout.EndHorizontal();
            if (debugFeedback.Length > 0) GUILayout.Label(debugFeedback);
            GUI.DragWindow(new Rect(0, 0, 580, 25));
        }

        private void ShowAllStatus(int page)
        {
            if (applied == null || !applied.active || applied.entries.Length == 0)
            { QueueLocal(CurrentStatusText()); return; }
            const int pageSize = 4;
            int pages = (applied.entries.Length - 1) / pageSize + 1;
            if (page < 1 || page > pages)
            { QueueLocal("[ForbiddenKey] 전체 상태 페이지는 1~" + pages + "까지입니다."); return; }
            StringBuilder text = new StringBuilder();
            if (pages > 1) text.Append("[ForbiddenKey] 전체 상태 ").Append(page).Append("/").Append(pages).Append('\n');
            int first = (page - 1) * pageSize;
            for (int i = first; i < applied.entries.Length && i < first + pageSize; i++)
            {
                PlayerBan item = applied.entries[i];
                if (i > first) text.Append('\n');
                string label = network != null && item.clientId == network.LocalId.ToString(System.Globalization.CultureInfo.InvariantCulture) && item.key >= 0 ? BindingLabel((BanKey)item.key) : item.label;
                text.Append(item.key < 0 ? item.player + "님은 금지된 키가 없습니다." : SafeText.Format(applied.banMessage, item.player, label));
            }
            QueueLocal(text.ToString());
        }

        private void AddAsset(object candidate)
        {
            if (candidate == null) return;
            InputActionAsset asset = candidate as InputActionAsset;
            if (asset == null) asset = Game.Get(candidate, "asset") as InputActionAsset;
            if (asset == null) asset = Game.Get(candidate, "actions") as InputActionAsset;
            if (asset != null && assetSet.Add(asset)) assets.Add(asset);
        }

        private void RefreshAssets()
        {
            assets.Clear(); assetSet.Clear();
            // Settings' PlayerInput carries current binding overrides. Prefer it for display.
            AddAsset(Game.Get(Game.Singleton("IngamePlayerSettings"), "playerInput"));
            AddAsset(Game.Get(Game.Player(), "playerActions"));
            AddAsset(Game.Get(Game.Singleton("HUDManager"), "playerActions"));
            if (assets.Count == 0)
                foreach (InputActionAsset asset in Resources.FindObjectsOfTypeAll<InputActionAsset>())
                    if (asset.FindActionMap("Movement", false) != null) AddAsset(asset);
            if (settings.diagnosticLogging && assets.Count > 0) WriteDiagnostics();
        }

        private bool HasAction(BanKey key)
        {
            foreach (InputActionAsset asset in assets)
                foreach (InputAction action in asset) if (InputGate.Matches(key, action)) return true;
            return false;
        }

        private string BindingLabel(BanKey key)
        {
            bool controller = Game.Bool(round, "localPlayerUsingController", false);
            foreach (InputActionAsset asset in assets)
            {
                List<string> labels = new List<string>();
                foreach (InputAction action in asset)
                {
                    if (!InputGate.Matches(key, action)) continue;
                    for (int i = 0; i < action.bindings.Count; i++)
                    {
                        InputBinding b = action.bindings[i];
                        if (b.isComposite || string.IsNullOrEmpty(b.effectivePath)) continue;
                        string path = b.effectivePath;
                        bool keyboardMouse = path.IndexOf("Keyboard", StringComparison.OrdinalIgnoreCase) >= 0 || path.IndexOf("Mouse", StringComparison.OrdinalIgnoreCase) >= 0;
                        if (controller == keyboardMouse) continue;
                        if ((int)key <= (int)BanKey.D)
                        {
                            string part = key == BanKey.W ? "up" : key == BanKey.S ? "down" : key == BanKey.A ? "left" : "right";
                            if (b.isPartOfComposite && !string.Equals(b.name, part, StringComparison.OrdinalIgnoreCase)) continue;
                            if (!b.isPartOfComposite && keyboardMouse) continue;
                        }
                        string label;
                        if (string.Equals(path, "<Mouse>/leftButton", StringComparison.OrdinalIgnoreCase)) label = "마우스 좌클릭";
                        else if (string.Equals(path, "<Mouse>/rightButton", StringComparison.OrdinalIgnoreCase)) label = "마우스 우클릭";
                        else label = action.GetBindingDisplayString(i);
                        if (string.IsNullOrEmpty(label)) label = path;
                        if (controller && (int)key <= (int)BanKey.D && !b.isPartOfComposite)
                            label += key == BanKey.W ? " 위" : key == BanKey.S ? " 아래" : key == BanKey.A ? " 왼쪽" : " 오른쪽";
                        label = label.Replace("<", "[").Replace(">", "]"); // Prevent rich-text markup in chat.
                        if (!labels.Contains(label)) labels.Add(label);
                    }
                }
                if (labels.Count > 0) return string.Join(" / ", labels.ToArray());
            }
            return "미지정(" + InputGate.Description(key) + ")";
        }

        private void WriteDiagnostics()
        {
            // Only when explicitly enabled; local file, no network or device identifiers.
            StringBuilder s = new StringBuilder();
            s.AppendLine("ForbiddenKey input diagnostics. These are action bindings, not keypress logs.");
            foreach (InputActionAsset asset in assets)
                foreach (InputAction action in asset)
                {
                    s.AppendLine((action.actionMap == null ? "" : action.actionMap.name + "/") + action.name);
                    for (int i = 0; i < action.bindings.Count; i++)
                    {
                        InputBinding b = action.bindings[i];
                        s.AppendLine("  " + b.name + " | default=" + b.path + " | effective=" + b.effectivePath);
                    }
                }
            string file = Path.Combine(PluginDirectory, "input-diagnostics.txt");
            string data = s.ToString();
            if (!File.Exists(file) || File.ReadAllText(file) != data) File.WriteAllText(file, data, new UTF8Encoding(false));
        }
    }

    // All assignments are chosen by the host, once per player per round. Messages use
    // NGO's authenticated transport sender ID; a client never selects its own ban.
    // Named messages need no NetworkObject or generated RPC stubs. Roster discovery,
    // metadata handshakes, replication and acknowledgement are deliberately independent.
    internal sealed class NetworkBridge
    {
        private const string Channel = "local.forbiddenkey.v4";
        private const int Protocol = WireCodec.Protocol;
        private const int MaxPacketBytes = 131072;
        private const int MaxPlayers = 256;
        private readonly ForbiddenKeyRuntime owner;
        private NetworkManager manager;
        private CustomMessagingManager messaging;
        private readonly Dictionary<ulong, WirePacket> peers = new Dictionary<ulong, WirePacket>();
        private readonly Dictionary<ulong, PlayerBan> bans = new Dictionary<ulong, PlayerBan>();
        private readonly Dictionary<string, int> roundDraws = new Dictionary<string, int>();
        private readonly Dictionary<ulong, float> lastHelloAt = new Dictionary<ulong, float>();
        private readonly Dictionary<ulong, float> lastSentAt = new Dictionary<ulong, float>();
        private readonly Dictionary<ulong, int> loggedSentRevision = new Dictionary<ulong, int>();
        private readonly Dictionary<ulong, int> acknowledged = new Dictionary<ulong, int>();
        private readonly HashSet<ulong> missingWarned = new HashSet<ulong>();
        private string session = "", lastHello = "";
        private int roundId, revision;
        private float nextHello, nextRoster, attachedAt, nextLocalCheck, nextRepair, nextWarning;
        private bool hostSeen, hostWarning, registered, attachedAsServer;
        private Settings roundSettings = new Settings();
        private BanKey forced = BanKey.None;
        public bool Active { get; private set; }
        public bool Connected { get { return manager != null && manager.IsListening; } }
        public bool IsHost { get { return Connected && manager.IsServer; } }
        public ulong LocalId { get { return manager == null ? ulong.MaxValue : manager.LocalClientId; } }

        public NetworkBridge(ForbiddenKeyRuntime runtime) { owner = runtime; }

        public void Tick()
        {
            try { TickCore(); }
            catch (Exception e)
            {
                // A loading-time/null/network exception must NOT permanently turn the guest
                // plugin off. Keep the last restriction and retry registration/replication.
                Warn("Network update will retry: " + e);
            }
        }

        private void TickCore()
        {
            NetworkManager current = NetworkManager.Singleton;
            if (current == null || !current.IsListening)
            {
                if (manager != null || registered) Detach();
                return;
            }
            if (!object.ReferenceEquals(manager, current) || attachedAsServer != current.IsServer)
            {
                Detach();
                manager = current; attachedAsServer = current.IsServer;
                attachedAt = Time.unscaledTime;
                manager.OnClientConnectedCallback += ConnectedClient;
                manager.OnClientDisconnectCallback += Disconnected;
                if (IsHost) session = Guid.NewGuid().ToString("N");
                owner.ResetLocalSession();
                ForbiddenKeyRuntime.Log.LogInfo("Multiplayer attached: " + (IsHost ? "host" : "client") + "; protocol=4.");
            }
            // NGO can replace the messaging service while keeping the NetworkManager object.
            // A handler registered on the OLD service does not receive messages on the NEW one.
            BindMessaging(current.CustomMessagingManager);
            if (!registered) return;
            if (!IsHost && !current.IsConnectedClient) return; // LocalClientId is not final yet.

            if (Time.unscaledTime >= nextLocalCheck)
            {
                nextLocalCheck = Time.unscaledTime + 0.5f;
                WirePacket hello = owner.BuildHello(); // Available even before inputs/HUD/player spawn.
                hello.session = session; hello.acknowledgedRevision = hostSeen ? revision : -1;
                string json = WireCodec.Encode(hello);
                if (json != lastHello || Time.unscaledTime >= nextHello)
                {
                    if (IsHost) AcceptHello(LocalId, hello);
                    else if (!Send(NetworkManager.ServerClientId, hello)) return;
                    lastHello = json;
                    nextHello = Time.unscaledTime + (IsHost || hostSeen ? 5f : 1f);
                }
            }
            if (IsHost && Time.unscaledTime >= nextRoster)
            {
                nextRoster = Time.unscaledTime + 0.5f;
                bool changed = ReconcileRoster();
                if (changed) Publish();
            }
            if (IsHost && Time.unscaledTime >= nextRepair)
            {
                nextRepair = Time.unscaledTime + 1.5f;
                WirePacket state = State();
                foreach (ulong id in ConnectedIds())
                {
                    if (id == LocalId) continue;
                    int ack; float last;
                    bool confirmed = acknowledged.TryGetValue(id, out ack) && ack >= revision;
                    if (!confirmed || !lastSentAt.TryGetValue(id, out last) || Time.unscaledTime - last >= 10f)
                        SendState(id, state);
                    if (Time.unscaledTime - attachedAt > 15f && !confirmed && missingWarned.Add(id))
                        ForbiddenKeyRuntime.Log.LogWarning("No state ACK yet: client=" + id + ", revision=" + revision +
                            ". Verify guest build.log and protocol 4. Retrying; no join notification is shown.");
                }
            }
            if (!IsHost && !hostSeen && !hostWarning && Time.unscaledTime - attachedAt > 15f)
            {
                hostWarning = true;
                ForbiddenKeyRuntime.Log.LogWarning("No host state received yet. Retrying hello; all players require ForbiddenKey 0.2.3. No join notification is shown.");
            }
        }

        private void BindMessaging(CustomMessagingManager current)
        {
            if (registered && object.ReferenceEquals(messaging, current)) return;
            if (registered && messaging != null)
            {
                try { messaging.UnregisterNamedMessageHandler(Channel); }
                catch (Exception e) { ForbiddenKeyRuntime.Log.LogDebug(e.Message); }
            }
            registered = false; messaging = current;
            if (messaging == null) return;
            messaging.RegisterNamedMessageHandler(Channel, Receive);
            registered = true; nextHello = nextLocalCheck = nextRepair = 0; lastHello = "";
            ForbiddenKeyRuntime.Log.LogInfo("Message handler registered: " + Channel + ".");
        }

        private void ConnectedClient(ulong id)
        {
            // Connection callbacks and periodic polling cover either initialization order.
            // Never announce player arrival or successful handshake to chat.
            nextHello = nextLocalCheck = nextRoster = nextRepair = 0; lastHello = "";
            acknowledged.Remove(id); lastSentAt.Remove(id); missingWarned.Remove(id);
        }

        public void MarkBindingsDirty() { lastHello = ""; nextHello = nextLocalCheck = 0; }

        public void Detach()
        {
            bool hadSession = manager != null || registered;
            if (registered && messaging != null)
            {
                try { messaging.UnregisterNamedMessageHandler(Channel); }
                catch (Exception e) { ForbiddenKeyRuntime.Log.LogDebug(e.Message); }
            }
            if (manager != null)
            {
                manager.OnClientConnectedCallback -= ConnectedClient;
                manager.OnClientDisconnectCallback -= Disconnected;
            }
            manager = null; messaging = null; registered = false;
            peers.Clear(); bans.Clear(); roundDraws.Clear(); lastHelloAt.Clear(); lastSentAt.Clear();
            acknowledged.Clear(); missingWarned.Clear(); loggedSentRevision.Clear();
            session = lastHello = ""; roundId = revision = 0;
            Active = hostSeen = hostWarning = false;
            nextHello = nextRoster = nextLocalCheck = nextRepair = nextWarning = 0;
            if (hadSession) owner.ResetLocalSession();
        }

        public void Begin(Settings settings, BanKey forcedKey)
        {
            // StartGame can be called before this component's first Update after joining.
            Tick();
            if (!IsHost || Active) return;
            Active = true; roundId++; roundSettings = settings; forced = forcedKey;
            bans.Clear(); roundDraws.Clear();
            ReconcileRoster();
            Publish();
            ForbiddenKeyRuntime.Log.LogInfo("Round " + roundId + ": " + bans.Count +
                " independent assignments from connected player roster; forced=" + forced + ".");
        }

        public void End()
        {
            if (!IsHost || !Active) return;
            Active = false; bans.Clear(); Publish();
        }

        private bool ReconcileRoster()
        {
            if (!IsHost) return false;
            bool changed = false;
            List<ulong> connected = ConnectedIds();
            foreach (ulong id in new List<ulong>(bans.Keys))
                if (!connected.Contains(id)) { bans.Remove(id); changed = true; }
            foreach (ulong id in new List<ulong>(peers.Keys))
                if (!connected.Contains(id))
                {
                    peers.Remove(id); lastHelloAt.Remove(id); lastSentAt.Remove(id);
                    acknowledged.Remove(id); missingWarned.Remove(id);
                }
            if (Active)
                foreach (ulong id in connected)
                    changed |= bans.ContainsKey(id) ? RefreshLabelAndName(id) : Assign(id);
            return changed;
        }

        private bool Assign(ulong id)
        {
            // A hello packet is metadata, NOT permission to be included in the game.
            if (bans.ContainsKey(id) || bans.Count >= MaxPlayers || PlayerFor(id) == null) return false;
            string identity = Identity(id);
            int selected;
            if (!roundDraws.TryGetValue(identity, out selected))
            {
                selected = !roundSettings.enabled ? -1 : forced != BanKey.None ? (int)forced :
                    WeightedPicker.Pick(roundSettings.weights.ToArray(), owner.NextSample());
                roundDraws[identity] = selected;
            }
            PlayerBan entry = new PlayerBan();
            entry.clientId = id.ToString(System.Globalization.CultureInfo.InvariantCulture);
            entry.player = PlayerName(id); entry.key = selected;
            entry.label = selected < 0 ? "" : ForbiddenKeyRuntime.DefaultLabel((BanKey)selected);
            bans[id] = entry;
            RefreshLabelAndName(id); // Apply real rebound labels whenever metadata is available.
            return true;
        }

        private bool RefreshLabelAndName(ulong id)
        {
            PlayerBan entry;
            if (!bans.TryGetValue(id, out entry)) return false;
            string name = PlayerName(id), label = entry.label, error = entry.error;
            WirePacket peer;
            if (entry.key >= 0 && peers.TryGetValue(id, out peer) && peer.bindingsReady)
            {
                label = peer.labels[entry.key];
                error = peer.supported[entry.key] ? "" : "선택된 입력 동작을 찾지 못했습니다: " + ((BanKey)entry.key);
            }
            if (entry.player == name && entry.label == label && entry.error == error) return false;
            entry.player = name; entry.label = label; entry.error = error;
            // Rebinds/duplicate hello/retries NEVER change entry.key.
            return true;
        }

        private void AcceptHello(ulong sender, WirePacket packet)
        {
            if (!IsHost || !IsConnected(sender) || !ValidHello(packet)) return;
            if (!peers.ContainsKey(sender) && peers.Count >= MaxPlayers) return;
            float last;
            if (lastHelloAt.TryGetValue(sender, out last) && Time.unscaledTime - last < 0.2f) return;
            lastHelloAt[sender] = Time.unscaledTime;
            for (int i = 0; i < 13; i++) packet.labels[i] = SafeText.Clean(packet.labels[i], 128);
            WirePacket previous;
            bool first = !peers.TryGetValue(sender, out previous);
            // Temporary asset teardown must not replace a known rebound label with defaults.
            if (first || packet.bindingsReady || !previous.bindingsReady) peers[sender] = packet;
            // A hello's revision alone is not proof of receiving the player array.
            // Only the explicit, content-checked ACK below confirms application.
            bool changed = false;
            if (Active) changed = bans.ContainsKey(sender) ? RefreshLabelAndName(sender) : Assign(sender);
            if (changed) Publish();
            else SendState(sender, State());
            if (first) ForbiddenKeyRuntime.Log.LogInfo("Hello received: client=" + sender + ", bindingsReady=" + packet.bindingsReady + ".");
        }

        private static bool ValidHello(WirePacket packet)
        {
            return packet != null && packet.protocol == Protocol && packet.kind == "hello" &&
                packet.labels != null && packet.labels.Length == 13 &&
                packet.supported != null && packet.supported.Length == 13;
        }

        private void Receive(ulong sender, FastBufferReader reader)
        {
            try
            {
                if (!Connected) return;
                if (!IsHost && sender != NetworkManager.ServerClientId) return;
                if (!IsHost && !manager.IsConnectedClient) return;
                if (IsHost && !IsConnected(sender)) return;
                if (reader.Length - reader.Position < 4) return;
                // Reader.Length can include a surrounding NGO message buffer; check the
                // decoded payload, not an unrelated whole-buffer upper bound.
                string text;
                reader.ReadValueSafe(out text, false);
                if (string.IsNullOrEmpty(text) || text.Length > MaxPacketBytes / 2) return;
                WirePacket packet = WireCodec.Decode(text);
                if (packet == null || packet.protocol != Protocol) return;
                if (IsHost)
                {
                    if (packet.kind == "hello") AcceptHello(sender, packet);
                    else if (packet.kind == "ack" && packet.session == session) RecordAcknowledgement(sender, packet);
                    return;
                }
                if (!ValidState(packet))
                {
                    Warn("Invalid host state: round=" + packet.roundId + ", revision=" + packet.revision +
                        ", active=" + packet.active + ", players=" + (packet.entries == null ? -1 : packet.entries.Length) +
                        ". No ACK; waiting for retransmission.");
                    return;
                }
                if (hostSeen && session != packet.session) return;
                if (hostSeen && (packet.revision < revision || packet.roundId < roundId)) return;
                // Duplicate state still produces an ACK (the earlier ACK may have been lost).
                // ApplyState itself deduplicates chat and never rerolls an assignment.
                if (packet.active && !ForbiddenKeyRuntime.HasLocalEntry(packet, LocalId))
                {
                    Warn("Incomplete host roster: local=" + LocalId + ", players=" + packet.entries.Length +
                        "; own entry missing. No ACK, no false unlock; waiting for a complete state.");
                    return;
                }
                bool changedState = !hostSeen || packet.revision != revision || packet.session != session;
                string receivedDigest = WireCodec.Digest(packet);
                if (!owner.ApplyState(packet, LocalId)) return;
                session = packet.session; revision = packet.revision; roundId = packet.roundId;
                Active = packet.active; hostSeen = true;
                WirePacket ack = new WirePacket(); ack.kind = "ack"; ack.session = session; ack.revision = revision;
                ack.roundId = roundId;
                ack.acknowledgedPlayers = packet.entries.Length;
                ack.acknowledgedKey = (int)owner.Current;
                ack.acknowledgedDigest = receivedDigest;
                Send(NetworkManager.ServerClientId, ack);
                if (changedState) ForbiddenKeyRuntime.Log.LogInfo("Host state received: local=" + LocalId +
                    ", round=" + roundId + ", revision=" + revision + ", active=" + Active +
                    ", players=" + packet.entries.Length + ", ownEntry=" +
                    ForbiddenKeyRuntime.HasLocalEntry(packet, LocalId) + ", key=" + owner.Current + ".");
            }
            catch (Exception e) { Warn("Rejected network packet; state will be retried: " + e); }
        }

        private void RecordAcknowledgement(ulong sender, WirePacket receipt)
        {
            if (receipt.revision != revision || receipt.roundId != roundId || receipt.session != session) return;
            PlayerBan local;
            int expectedKey = -1;
            if (Active)
            {
                if (!bans.TryGetValue(sender, out local)) return;
                expectedKey = local.key;
            }
            if (receipt.acknowledgedPlayers != bans.Count || receipt.acknowledgedKey != expectedKey ||
                receipt.acknowledgedDigest != WireCodec.Digest(State()))
            {
                Warn("ACK content mismatch: client=" + sender + ", receivedPlayers=" + receipt.acknowledgedPlayers +
                    ", expectedPlayers=" + bans.Count + ". Not confirmed; same assignments will be resent.");
                return;
            }
            int previous;
            if (acknowledged.TryGetValue(sender, out previous) && receipt.revision <= previous) return;
            acknowledged[sender] = receipt.revision; missingWarned.Remove(sender);
            ForbiddenKeyRuntime.Log.LogInfo("State ACK verified: client=" + sender + ", revision=" + receipt.revision +
                ", players=" + receipt.acknowledgedPlayers + ", key=" + (BanKey)expectedKey + ".");
        }

        private static bool ValidState(WirePacket packet)
        {
            if (packet.kind != "state" || packet.session == null || packet.session.Length != 32 ||
                packet.revision < 0 || packet.roundId < 0 || packet.entries == null || packet.entries.Length > MaxPlayers ||
                packet.banMessage == null || packet.banMessage.Length > 200 ||
                !packet.banMessage.Contains("{player}") || !packet.banMessage.Contains("{key}") ||
                packet.releaseMessage == null || packet.releaseMessage.Length > 200) return false;
            if (!packet.active && packet.entries.Length != 0) return false;
            if (packet.active && packet.entries.Length == 0) return false; // Never accept the 0.2.1 empty-active-roster failure.
            HashSet<ulong> ids = new HashSet<ulong>();
            foreach (PlayerBan entry in packet.entries)
            {
                ulong id;
                if (entry == null || !ulong.TryParse(entry.clientId, out id) || !ids.Add(id) ||
                    entry.key < -1 || entry.key >= 13 || entry.player == null || entry.player.Length > 48 ||
                    entry.label == null || entry.label.Length > 128 || entry.error == null || entry.error.Length > 160) return false;
            }
            return true;
        }

        private WirePacket State()
        {
            WirePacket packet = new WirePacket();
            packet.kind = "state"; packet.session = session; packet.roundId = roundId;
            packet.revision = revision; packet.active = Active;
            packet.banMessage = roundSettings.banMessage; packet.releaseMessage = roundSettings.releaseMessage;
            packet.announceRelease = roundSettings.announceRelease;
            List<ulong> ids = new List<ulong>(bans.Keys); ids.Sort();
            List<PlayerBan> entries = new List<PlayerBan>();
            foreach (ulong id in ids)
            {
                PlayerBan old = bans[id];
                entries.Add(new PlayerBan { clientId = old.clientId, key = old.key, player = old.player, label = old.label, error = old.error });
            }
            packet.entries = entries.ToArray();
            return packet;
        }

        private void Publish()
        {
            revision++;
            WirePacket packet = State();
            // The host exercises the same encoding/decoding path as remote clients.
            // A successful host-only test can no longer bypass the player-array codec.
            WirePacket localPacket = WireCodec.Decode(WireCodec.Encode(packet));
            if (ValidState(localPacket) && owner.ApplyState(localPacket, LocalId))
                acknowledged[LocalId] = revision;
            // Target EVERY transport connection, not only peers that sent a hello.
            foreach (ulong id in ConnectedIds()) if (id != LocalId) SendState(id, packet);
            nextRepair = Time.unscaledTime + 1.5f;
        }

        private void SendState(ulong target, WirePacket packet)
        {
            if (target == LocalId)
            {
                WirePacket localPacket = WireCodec.Decode(WireCodec.Encode(packet));
                if (ValidState(localPacket) && owner.ApplyState(localPacket, LocalId))
                    acknowledged[LocalId] = packet.revision;
            }
            else if (Send(target, packet))
            {
                lastSentAt[target] = Time.unscaledTime;
                int prior;
                if (!loggedSentRevision.TryGetValue(target, out prior) || prior != packet.revision)
                {
                    loggedSentRevision[target] = packet.revision;
                    ForbiddenKeyRuntime.Log.LogInfo("State sent: target=" + target + ", round=" + packet.roundId +
                        ", revision=" + packet.revision + ", active=" + packet.active +
                        ", players=" + packet.entries.Length + ", codec=FK4.");
                }
            }
        }

        private bool Send(ulong target, WirePacket packet)
        {
            try
            {
                if (!Connected || !registered || messaging == null || (!IsHost && !manager.IsConnectedClient)) return false;
                string text = WireCodec.Encode(packet);
                int size = FastBufferWriter.GetWriteSize(text, false);
                if (size > MaxPacketBytes) throw new InvalidDataException("State exceeds network packet limit.");
                using (FastBufferWriter writer = new FastBufferWriter(Math.Max(256, size), Allocator.Temp))
                {
                    writer.WriteValueSafe(text, false);
                    messaging.SendNamedMessage(Channel, target, writer, NetworkDelivery.ReliableFragmentedSequenced);
                }
                return true;
            }
            catch (Exception e) { Warn("Network send failed; retry is scheduled: " + e); return false; }
        }

        private void Disconnected(ulong id)
        {
            if (!IsHost)
            {
                if (id == LocalId) Detach();
                return;
            }
            peers.Remove(id); lastHelloAt.Remove(id); missingWarned.Remove(id);
            acknowledged.Remove(id); lastSentAt.Remove(id); loggedSentRevision.Remove(id);
            if (bans.Remove(id)) Publish();
        }

        private List<ulong> ConnectedIds()
        {
            List<ulong> ids = new List<ulong>();
            if (!IsHost) return ids; // ConnectedClientsIds is a SERVER-side API.
            foreach (ulong id in manager.ConnectedClientsIds) if (!ids.Contains(id)) ids.Add(id);
            if (manager.IsHost && !ids.Contains(LocalId)) ids.Add(LocalId);
            ids.Sort(); return ids;
        }

        private bool IsConnected(ulong id) { return IsHost && ConnectedIds().Contains(id); }

        internal static object PlayerFor(ulong id)
        {
            object round = Game.Singleton("StartOfRound");
            IList players = Game.Get(round, "allPlayerScripts") as IList;
            if (players == null) return null;
            // The game maps transport IDs to player slots. These are not interchangeable:
            // playerClientId/array index is a slot, actualClientId is the network identity.
            IDictionary map = Game.Get(round, "ClientPlayerList") as IDictionary;
            if (map != null && map.Contains(id))
            {
                int slot = Convert.ToInt32(map[id]);
                if (slot >= 0 && slot < players.Count && LiveObject(players[slot])) return players[slot];
            }
            foreach (object player in players)
            {
                if (!LiveObject(player)) continue;
                object value = Game.Get(player, "actualClientId");
                if (value != null && Convert.ToUInt64(value) == id &&
                    (Game.Bool(player, "isPlayerControlled", false) || Game.Bool(player, "isPlayerDead", false) ||
                     object.ReferenceEquals(player, Game.Player()))) return player;
            }
            return null;
        }

        private static bool LiveObject(object value)
        {
            if (value == null) return false;
            UnityEngine.Object unity = value as UnityEngine.Object;
            return object.ReferenceEquals(unity, null) || unity != null;
        }

        private static string PlayerName(ulong id)
        {
            string name = SafeText.Clean(Convert.ToString(Game.Get(PlayerFor(id), "playerUsername")), 48);
            return name.Length == 0 ? "플레이어 " + id : name;
        }

        private static string Identity(ulong id)
        {
            object value = Game.Get(PlayerFor(id), "playerSteamId");
            ulong steam = value == null ? 0 : Convert.ToUInt64(value);
            return steam == 0 ? "connection:" + id : "steam:" + steam;
        }

        private void Warn(string text)
        {
            if (Time.unscaledTime < nextWarning) return;
            nextWarning = Time.unscaledTime + 10f;
            ForbiddenKeyRuntime.Log.LogWarning(text); // Log only, never an entry/join chat alert.
        }

        internal string DiagnosticStatus()
        {
            if (!Connected) return "[ForbiddenKey 0.2.3] 네트워크 연결 전입니다.";
            if (!IsHost) return "[ForbiddenKey 0.2.3] 게스트 ID=" + LocalId + ", 수신=" + hostSeen +
                ", 라운드=" + roundId + ", 상태=" + revision + ", 잠금=" + owner.Current + ", 통신=FK4";
            int confirmed = 0; List<ulong> ids = ConnectedIds();
            foreach (ulong id in ids)
            {
                int ack;
                if (acknowledged.TryGetValue(id, out ack) && ack >= revision) confirmed++;
            }
            return "[ForbiddenKey 0.2.3] 호스트, 수신 확인=" + confirmed + "/" + ids.Count +
                ", 배정=" + bans.Count + ", 라운드=" + roundId + ", 상태=" + revision;
        }
    }

    public static class InputGate
    {
        private static readonly string[] PrimaryNames = { "Move", "Move", "Move", "Move", "Sprint", "Crouch", "Interact", "Discard", "ActivateItem", "PingScan", "OpenMenu", "Jump", "ItemSecondaryUse" };
        private static readonly string[] Descriptions = { "앞으로 이동", "왼쪽 이동", "뒤로 이동", "오른쪽 이동", "달리기", "웅크리기", "상호작용", "버리기", "아이템 사용", "스캔", "메뉴/터미널 나가기", "점프", "아이템 보조 사용" };
        public static string Description(BanKey key) { return key == BanKey.None ? "없음" : Descriptions[(int)key]; }
        public static bool Matches(BanKey key, InputAction action)
        {
            if (key < BanKey.W || key > BanKey.Q || action == null) return false;
            string map = action.actionMap == null ? "" : action.actionMap.name;
            if (string.Equals(map, "UI", StringComparison.OrdinalIgnoreCase)) return false;
            if (string.Equals(action.name, PrimaryNames[(int)key], StringComparison.OrdinalIgnoreCase)) return true;
            if (key == BanKey.MB1 && string.Equals(action.name, "Use", StringComparison.OrdinalIgnoreCase)) return true;
            // E also owns tertiary item use in the base game. Rebinding either action must not escape it.
            if (key == BanKey.E && string.Equals(action.name, "ItemTertiaryUse", StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }
        public static bool Enforce()
        {
            try { return EnforceCore(); }
            catch (Exception e)
            {
                if (ForbiddenKeyRuntime.Instance != null) ForbiddenKeyRuntime.Instance.Fail(e);
                return false;
            }
        }
        private static bool EnforceCore()
        {
            ForbiddenKeyRuntime r = ForbiddenKeyRuntime.Instance;
            if (r == null || !r.Ready || r.Current == BanKey.None) return false;
            object player = Game.Player();
            if (player == null || Game.Bool(player, "isPlayerDead", false)) return false;
            if (Game.MenuOpen()) return false; // Buttons in an already-open pause menu remain usable.
            if (r.Current == BanKey.ESC) return true; // Terminal exit remains forbidden, regardless of the physical key.
            return !Game.Bool(player, "isTypingChat", false) && !Game.Bool(player, "inTerminalMenu", false);
        }
        public static bool Block(InputAction action)
        {
            return Enforce() && Matches(ForbiddenKeyRuntime.Instance.Current, action);
        }
        public static Vector2 ReadVector(InputAction action)
        {
            Vector2 value = action.ReadValue<Vector2>();
            return Block(action) ? WeightedPicker.FilterDirection(value, ForbiddenKeyRuntime.Instance.Current) : value;
        }
        public static float ReadFloat(InputAction action) { return Block(action) ? 0 : action.ReadValue<float>(); }
        public static bool IsPressed(InputAction action) { return !Block(action) && action.IsPressed(); }
        public static bool WasPressed(InputAction action) { return !Block(action) && action.WasPressedThisFrame(); }
        public static bool WasPerformed(InputAction action) { return !Block(action) && action.WasPerformedThisFrame(); }
        public static bool Triggered(InputAction action) { return !Block(action) && action.triggered; }
        public static Vector2 ReadContextVector(ref InputAction.CallbackContext context)
        {
            Vector2 value = context.ReadValue<Vector2>();
            return Block(context.action) ? WeightedPicker.FilterDirection(value, ForbiddenKeyRuntime.Instance.Current) : value;
        }
        public static float ReadContextFloat(ref InputAction.CallbackContext context) { return Block(context.action) ? 0 : context.ReadValue<float>(); }
        public static bool CallbackPrefix(InputAction.CallbackContext __0)
        {
            // Never swallow cancellation: releasing a held item/button must clear vanilla state.
            if (__0.canceled) return true;
            if (!Block(__0.action)) return true;
            BanKey key = ForbiddenKeyRuntime.Instance.Current;
            // Movement callbacks must run with the filtered vector, not be skipped wholesale.
            return key >= BanKey.W && key <= BanKey.D;
        }
        public static void PlayerFramePrefix(object __instance)
        {
            if (!Enforce() || !object.ReferenceEquals(__instance, Game.Player())) return;
            BanKey key = ForbiddenKeyRuntime.Instance.Current;
            if (key >= BanKey.W && key <= BanKey.D)
            {
                object vector = Game.Get(__instance, "moveInputVector");
                if (vector is Vector2) Game.Set(__instance, "moveInputVector", WeightedPicker.FilterDirection((Vector2)vector, key));
            }
            if (key == BanKey.Shift) Game.Set(__instance, "isSprinting", false);
        }
    }

    public static class Patches
    {
        private static readonly string[] InputTypes = {
            "GameNetcodeStuff.PlayerControllerB", "HUDManager", "IngamePlayerSettings", "Terminal", "ShipBuildModeManager",
            "VehicleController", "JetpackItem", "WalkieTalkie", "Shovel", "KnifeItem", "ShotgunItem", "QuickMenuManager",
            "GrabbableObject", "InteractTrigger", "StartMatchLever"
        };
        private static HarmonyMethod Hook(Type type, string name) { return new HarmonyMethod(AccessTools.Method(type, name)); }

        public static bool Install(Harmony h)
        {
            int callbacks = 0, reads = 0, starts = 0;
            Type round = Game.Type("StartOfRound");
            if (round == null || Game.Type("GameNetcodeStuff.PlayerControllerB") == null)
                throw new InvalidOperationException("Lethal Company gameplay types were not found.");
            MethodInfo start = AccessTools.Method(round, "StartGame");
            if (start != null) { h.Patch(start, prefix: Hook(typeof(Patches), "StartPrefix")); starts++; }
            MethodInfo reset = AccessTools.Method(round, "ResetPlayersLoadedValueClientRpc");
            if (reset != null && reset.GetParameters().Length > 0 && reset.GetParameters()[0].ParameterType == typeof(bool))
            { h.Patch(reset, postfix: Hook(typeof(Patches), "ResetPostfix")); starts++; }
            MethodInfo disconnect = AccessTools.Method(Game.Type("GameNetworkManager"), "Disconnect");
            if (disconnect != null) h.Patch(disconnect, prefix: Hook(typeof(Patches), "DisconnectPrefix"));

            foreach (string typeName in InputTypes)
            {
                Type type = Game.Type(typeName);
                if (type == null) continue;
                List<Type> visit = new List<Type>(); visit.Add(type); visit.AddRange(type.GetNestedTypes(BindingFlags.Public | BindingFlags.NonPublic));
                foreach (Type target in visit)
                    foreach (MethodInfo method in target.GetMethods(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly))
                    {
                        if (method.IsAbstract || method.ContainsGenericParameters || method.GetMethodBody() == null) continue;
                        ParameterInfo[] p = method.GetParameters();
                        bool callback = p.Length == 1 && p[0].ParameterType == typeof(InputAction.CallbackContext) && method.ReturnType == typeof(void);
                        bool hasRead = ContainsInputRead(method);
                        if (!callback && !hasRead) continue;
                        h.Patch(method,
                            prefix: callback ? Hook(typeof(InputGate), "CallbackPrefix") : null,
                            transpiler: hasRead ? Hook(typeof(Patches), "InputTranspiler") : null);
                        if (callback) callbacks++;
                        if (hasRead) reads++;
                    }
            }
            Type player = Game.Type("GameNetcodeStuff.PlayerControllerB");
            foreach (string name in new string[] { "Update", "FixedUpdate" })
            {
                MethodInfo method = AccessTools.Method(player, name);
                if (method != null) h.Patch(method, prefix: Hook(typeof(InputGate), "PlayerFramePrefix"));
            }
            ForbiddenKeyRuntime.Log.LogInfo("Hooks: start=" + starts + ", callbacks=" + callbacks + ", input-read methods=" + reads);
            if (starts == 0 || callbacks == 0 || reads == 0) throw new InvalidOperationException("Required input/lifecycle hooks missing; mod disabled.");
            return true;
        }

        public static void StartPrefix(object __instance)
        {
            try
            {
                if (ForbiddenKeyRuntime.Instance != null && Game.Bool(__instance, "inShipPhase", false)) ForbiddenKeyRuntime.Instance.BeginRound();
            }
            catch (Exception e) { if (ForbiddenKeyRuntime.Instance != null) ForbiddenKeyRuntime.Instance.Fail(e); }
        }
        public static void ResetPostfix(bool __0)
        {
            try { if (__0 && ForbiddenKeyRuntime.Instance != null) ForbiddenKeyRuntime.Instance.BeginRound(); }
            catch (Exception e) { if (ForbiddenKeyRuntime.Instance != null) ForbiddenKeyRuntime.Instance.Fail(e); }
        }
        public static void DisconnectPrefix()
        {
            if (ForbiddenKeyRuntime.Instance != null) ForbiddenKeyRuntime.Instance.EndRound(false);
        }

        private static MethodInfo Replacement(MethodInfo m)
        {
            if (m == null) return null;
            string name = null;
            if (m.DeclaringType == typeof(InputAction))
            {
                if (m.Name == "ReadValue" && m.IsGenericMethod)
                {
                    Type arg = m.GetGenericArguments()[0];
                    if (arg == typeof(Vector2)) name = "ReadVector";
                    if (arg == typeof(float)) name = "ReadFloat";
                }
                if (m.Name == "IsPressed") name = "IsPressed";
                if (m.Name == "WasPressedThisFrame") name = "WasPressed";
                if (m.Name == "WasPerformedThisFrame") name = "WasPerformed";
                if (m.Name == "get_triggered") name = "Triggered";
            }
            if (m.DeclaringType == typeof(InputAction.CallbackContext) && m.Name == "ReadValue" && m.IsGenericMethod)
            {
                Type arg = m.GetGenericArguments()[0];
                if (arg == typeof(Vector2)) name = "ReadContextVector";
                if (arg == typeof(float)) name = "ReadContextFloat";
            }
            return name == null ? null : AccessTools.Method(typeof(InputGate), name);
        }

        private static readonly Dictionary<short, OpCode> OpCodesByValue = BuildOpcodeTable();
        private static Dictionary<short, OpCode> BuildOpcodeTable()
        {
            Dictionary<short, OpCode> table = new Dictionary<short, OpCode>();
            foreach (FieldInfo f in typeof(OpCodes).GetFields(BindingFlags.Public | BindingFlags.Static))
                if (f.FieldType == typeof(OpCode)) { OpCode op = (OpCode)f.GetValue(null); table[op.Value] = op; }
            return table;
        }
        private static bool ContainsInputRead(MethodInfo method)
        {
            byte[] bytes = method.GetMethodBody().GetILAsByteArray();
            for (int offset = 0; offset < bytes.Length; )
            {
                short value = bytes[offset++];
                if (value == 0xfe) { if (offset >= bytes.Length) return false; value = unchecked((short)(0xfe00 | bytes[offset++])); }
                OpCode op;
                if (!OpCodesByValue.TryGetValue(value, out op)) return false;
                if (op.OperandType == OperandType.InlineMethod && offset + 4 <= bytes.Length)
                {
                    try { if (Replacement(method.Module.ResolveMethod(BitConverter.ToInt32(bytes, offset)) as MethodInfo) != null) return true; }
                    catch (ArgumentException) { }
                }
                int size;
                switch (op.OperandType)
                {
                    case OperandType.InlineNone: size = 0; break;
                    case OperandType.ShortInlineBrTarget: case OperandType.ShortInlineI: case OperandType.ShortInlineVar: size = 1; break;
                    case OperandType.InlineVar: size = 2; break;
                    case OperandType.InlineI8: case OperandType.InlineR: size = 8; break;
                    case OperandType.InlineSwitch:
                        if (offset + 4 > bytes.Length) return false;
                        int count = BitConverter.ToInt32(bytes, offset);
                        if (count < 0 || count > (bytes.Length - offset - 4) / 4) return false;
                        size = 4 + 4 * count; break;
                    default: size = 4; break;
                }
                offset += size;
            }
            return false;
        }
        public static IEnumerable<CodeInstruction> InputTranspiler(IEnumerable<CodeInstruction> instructions)
        {
            foreach (CodeInstruction instruction in instructions)
            {
                MethodInfo replacement = Replacement(instruction.operand as MethodInfo);
                if (replacement != null && (instruction.opcode == OpCodes.Call || instruction.opcode == OpCodes.Callvirt))
                {
                    instruction.opcode = OpCodes.Call;
                    instruction.operand = replacement;
                }
                yield return instruction;
            }
        }
    }

    internal static class ChatHooks
    {
        internal static void Install(Harmony harmony)
        {
            try
            {
                Type hud = Game.Type("HUDManager");
                MethodInfo submit = hud == null ? null : AccessTools.Method(hud, "SubmitChat_performed", new Type[] { typeof(InputAction.CallbackContext) });
                if (submit == null) { ForbiddenKeyRuntime.Log.LogWarning("Chat command hook unavailable; current-ban restoration on chat open remains enabled."); return; }
                HarmonyMethod prefix = new HarmonyMethod(AccessTools.Method(typeof(ChatHooks), "SubmitPrefix"));
                prefix.priority = Priority.Last; // Respect other mods that already suppress submission.
                harmony.Patch(submit, prefix: prefix);
            }
            catch (Exception e) { ForbiddenKeyRuntime.Log.LogWarning("Chat command hook unavailable: " + e.Message); }
        }

        internal static void InstallJoinFilters(Harmony harmony)
        {
            try
            {
                Type hud = Game.Type("HUDManager");
                if (hud == null) return;
                int count = 0;
                foreach (MethodInfo method in hud.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly))
                {
                    ParameterInfo[] p = method.GetParameters();
                    if (p.Length == 0 || p[0].ParameterType != typeof(string)) continue;
                    string hook = null;
                    if (method.Name == "AddChatMessage" &&
                        (p.Length == 1 || (p.Length == 2 && p[1].ParameterType == typeof(string)))) hook = "ChatMessagePrefix";
                    else if (method.Name == "AddTextMessageClientRpc") hook = "SystemChatPrefix";
                    else if (method.Name == "DisplayTip" && p.Length >= 2 && p[1].ParameterType == typeof(string)) hook = "TipPrefix";
                    if (hook == null) continue;
                    harmony.Patch(method, prefix: new HarmonyMethod(AccessTools.Method(typeof(ChatHooks), hook)));
                    count++;
                }
                ForbiddenKeyRuntime.Log.LogInfo("Join notification filters installed: " + count + ". Ordinary player chat is not filtered.");
            }
            catch (Exception e) { ForbiddenKeyRuntime.Log.LogWarning("Optional join notification filter unavailable: " + e.Message); }
        }

        public static bool SystemChatPrefix(object[] __args)
        {
            return __args == null || __args.Length == 0 || !Chat.IsJoinNotice(__args[0] as string);
        }

        public static bool ChatMessagePrefix(object[] __args)
        {
            if (__args == null || __args.Length == 0) return true;
            // Keep normal player messages, including someone typing "... joined the ship".
            if (__args.Length > 1 && !string.IsNullOrEmpty(__args[1] as string)) return true;
            return !Chat.IsJoinNotice(__args[0] as string);
        }

        public static bool TipPrefix(object[] __args)
        {
            if (__args == null || __args.Length < 2) return true;
            string title = (Convert.ToString(__args[0]) ?? "").Trim();
            string message = Convert.ToString(__args[1]);
            bool joinTitle = string.Equals(title, "New crew member", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(title, "New player", StringComparison.OrdinalIgnoreCase) ||
                title == "새로운 승무원" || title == "새 승무원" || title == "플레이어 접속";
            return !(joinTitle || Chat.IsJoinNotice(message));
        }

        public static bool SubmitPrefix(object __instance, InputAction.CallbackContext __0)
        {
            if (!__0.performed || ForbiddenKeyRuntime.Instance == null) return true;
            object input = Game.Get(__instance, "chatTextField");
            if (input == null || !(Game.Bool(Game.Player(), "isTypingChat", false) || Game.Bool(input, "isFocused", false))) return true;
            string text = Convert.ToString(Game.Get(input, "text"));
            if (!ForbiddenKeyRuntime.IsLocalChatCommand(text)) return true;
            try
            {
                // Consume only our command. No ServerRpc, fabricated player message, or remote send.
                Game.Set(input, "text", "");
                ForbiddenKeyRuntime.Instance.HandleLocalChatCommand(text);
                // Keep the chat input open so the response can be read immediately.
                MethodInfo activate = Game.Method(input.GetType(), "ActivateInputField", 0);
                if (activate != null) activate.Invoke(input, null);
            }
            catch (Exception e) { ForbiddenKeyRuntime.Log.LogWarning("Local chat command failed: " + e.Message); }
            return false; // A recognized local command is never submitted to the server, even on failure.
        }
    }

    internal static class Chat
    {
        private static object fontAsset;
        private static bool fontAttempted, chatWarned, nativeWarned;

        internal static bool IsJoinNotice(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return false;
            // Strip display markup only for this exact system-message check.
            StringBuilder plain = new StringBuilder(); bool tag = false;
            foreach (char c in text)
            {
                if (c == '<') { tag = true; continue; }
                if (c == '>') { tag = false; continue; }
                if (!tag) plain.Append(c);
            }
            string message = plain.ToString().Trim().TrimEnd('.', '!').TrimEnd();
            // Never swallow a multiline roster or an unrelated notification block.
            if (message.IndexOf('\n') >= 0 || message.IndexOf('\r') >= 0) return false;
            foreach (string suffix in new string[] {
                " joined the ship", " joined the crew", " joined the game", " has joined the ship", " has joined the game",
                "님이 접속했습니다", "님이 접속하였습니다", "님이 입장했습니다", "님이 입장하였습니다",
                "님이 참가했습니다", "님이 참가하였습니다", "님이 함선에 합류했습니다", "님이 합류했습니다"
            })
                if (message.Length > suffix.Length && message.EndsWith(suffix, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        internal static bool ContainsRecent(object hud, string text, int count)
        {
            if (hud == null || string.IsNullOrEmpty(text)) return false;
            IList history = Game.Get(hud, "ChatMessageHistory") as IList;
            if (history == null) return false;
            int first = Math.Max(0, history.Count - count);
            for (int i = history.Count - 1; i >= first; i--)
                if (Convert.ToString(history[i]).IndexOf(text, StringComparison.Ordinal) >= 0) return true;
            return false;
        }

        public static bool TryWrite(string text, bool koreanFont)
        {
            try
            {
                object hud = Game.Singleton("HUDManager");
                if (hud == null) return false;
                if (koreanFont) InstallFontFallback(hud);
                IList history = Game.Get(hud, "ChatMessageHistory") as IList;
                if (history == null) { Warn("HUDManager.ChatMessageHistory is unavailable; notice remains queued."); return false; }

                // Match the actual parameter types, not just the overload's argument count.
                MethodInfo add = AccessTools.Method(hud.GetType(), "AddChatMessage", new Type[] { typeof(string), typeof(string) });
                if (add == null) add = AccessTools.Method(hud.GetType(), "AddChatMessage", new Type[] { typeof(string) });
                if (add != null)
                {
                    object previousLast = Game.Get(hud, "lastChatMessage");
                    try
                    {
                        // Allow consecutive rounds to announce the same key, while preserving
                        // vanilla's duplicate suppression for real player messages afterwards.
                        Game.Set(hud, "lastChatMessage", "");
                        if (add.GetParameters().Length == 2) add.Invoke(hud, new object[] { text, "" });
                        else add.Invoke(hud, new object[] { text });
                    }
                    catch (Exception e)
                    {
                        if (!nativeWarned) { nativeWarned = true; ForbiddenKeyRuntime.Log.LogWarning("Native chat call failed; using real-history fallback: " + e.Message); }
                    }
                    finally { Game.Set(hud, "lastChatMessage", previousLast); }

                    // Do not report success merely because text was flashed on the HUD.
                    // A patched native method may replace the list, so read it again.
                    history = Game.Get(hud, "ChatMessageHistory") as IList;
                    if (ContainsRecent(hud, text, 1)) { Reveal(hud); return true; }
                }

                // Fallback also inserts into the backing history; never append to chatText alone.
                object display = Game.Get(hud, "chatText");
                if (history == null || history.IsReadOnly || history.IsFixedSize || display == null) return false;
                int keep = Math.Max(4, history.Count); // Preserve a pre-existing extended history window.
                string entry = text;
                if (history.Count > 0)
                {
                    string example = Convert.ToString(history[history.Count - 1]);
                    if (example.StartsWith("\n", StringComparison.Ordinal)) entry = "\n" + entry;
                    if (example.EndsWith("\n", StringComparison.Ordinal)) entry += "\n";
                }
                history.Add(entry);
                while (history.Count > keep) history.RemoveAt(0);
                StringBuilder rendered = new StringBuilder();
                foreach (object item in history)
                {
                    string line = Convert.ToString(item);
                    if (rendered.Length > 0 && rendered[rendered.Length - 1] != '\n' && !line.StartsWith("\n", StringComparison.Ordinal)) rendered.Append('\n');
                    rendered.Append(line);
                }
                Game.Set(display, "text", rendered.ToString());
                Reveal(hud);
                return ContainsRecent(hud, text, 1);
            }
            catch (Exception e) { Warn("Chat unavailable: " + e.Message); return false; }
        }

        private static void Warn(string message)
        {
            if (!chatWarned) { chatWarned = true; ForbiddenKeyRuntime.Log.LogWarning(message); }
        }

        private static void Reveal(object hud)
        {
            // A fade is a visibility effect, not deletion. Keep normal fade behavior.
            try
            {
                object element = Game.Get(hud, "Chat");
                if (element == null) return;
                foreach (MethodInfo method in hud.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    if (method.Name != "PingHUDElement") continue;
                    ParameterInfo[] p = method.GetParameters();
                    if ((p.Length != 2 && p.Length != 4) || !p[0].ParameterType.IsInstanceOfType(element) || p[1].ParameterType != typeof(float)) continue;
                    if (p.Length == 2) method.Invoke(hud, new object[] { element, 4f });
                    else
                    {
                        if (p[2].ParameterType != typeof(float) || p[3].ParameterType != typeof(float)) continue;
                        float start = p[2].DefaultValue is float ? (float)p[2].DefaultValue : 1f;
                        float end = p[3].DefaultValue is float ? (float)p[3].DefaultValue : 0.2f;
                        method.Invoke(hud, new object[] { element, 4f, start, end });
                    }
                    return;
                }
            }
            catch (Exception e) { Warn("Chat history saved, but HUD reveal failed: " + e.Message); }
        }

        private static void InstallFontFallback(object hud)
        {
            try
            {
                if (!fontAttempted)
                {
                    fontAttempted = true;
                    Type tmp = Game.Type("TMPro.TMP_FontAsset");
                    if (tmp == null) return;
                    Font osFont = Font.CreateDynamicFontFromOSFont(new string[] { "Malgun Gothic", "Apple SD Gothic Neo", "Noto Sans CJK KR" }, 24);
                    foreach (MethodInfo m in tmp.GetMethods(BindingFlags.Static | BindingFlags.Public))
                    {
                        if (m.Name != "CreateFontAsset") continue;
                        ParameterInfo[] p = m.GetParameters();
                        if (p.Length != 1 || p[0].ParameterType != typeof(Font)) continue;
                        fontAsset = m.Invoke(null, new object[] { osFont });
                        break;
                    }
                    if (fontAsset == null) ForbiddenKeyRuntime.Log.LogWarning("Could not create a Korean fallback font. Use a Korean font mod if glyphs appear as squares.");
                }
                if (fontAsset == null) return;
                object text = Game.Get(hud, "chatText");
                object primary = Game.Get(text, "font");
                IList fallbacks = Game.Get(primary, "fallbackFontAssetTable") as IList;
                if (fallbacks != null && !fallbacks.Contains(fontAsset)) fallbacks.Add(fontAsset);
            }
            catch (Exception e) { ForbiddenKeyRuntime.Log.LogWarning("Korean font fallback unavailable: " + e.Message); fontAsset = null; }
        }
    }
}
