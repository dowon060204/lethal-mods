# ForbiddenKey 0.2.3 — BetterSpectate 간접 의존 제거

함선 출발 때 플레이어마다 하나의 금지 동작을 배정하고, 궤도 복귀 때 해제합니다.
이번 버전은 0.2.2의 FK4 게스트 명단 전송 수정을 유지하면서, BetterSpectate가 대신 수행하던 실행 객체 보호를 로더에서 직접 처리하고 본체를 별도 유지 객체로 분리한 수정본입니다.

> **검증 범위:** 실제 DLL 파일과 본체 소스를 포함합니다. 다만 DLL은 첫 실행에 본체 소스를 로컬 컴파일하는 Windows용 로더이며, 본체가 사전 컴파일된 DLL은 아닙니다. 작성 환경에서 CLR/Unity 실행과 본체 C# 컴파일은 하지 못했습니다. 구조 검사·소스 회귀 검사·Python 참고 모델 검사만 수행했습니다. BetterSpectate 없는 실기 성공이나 멀티플레이 해결을 검증 완료했다고 주장하지 않습니다.

## 설치와 업데이트

게임을 완전히 종료한 뒤, **현재 실행하는 모드 프로필**에 ZIP의 `BepInEx` 폴더를 합쳐 덮어씁니다. 아래 파일을 한 폴더에 함께 두세요.

```text
BepInEx/plugins/ForbiddenKey/ForbiddenKey.dll
BepInEx/plugins/ForbiddenKey/ForbiddenKey.Runtime.cs
BepInEx/plugins/ForbiddenKey/ForbiddenKey.default.json
```

이번에는 **DLL도 교체합니다.** 0.2.2의 소스 한 파일 교체 안내와 다릅니다. 기존 설치에 0.2.2를 따로 먼저 적용할 필요 없이, 0.2.1 또는 0.2.2에서 바로 업데이트할 수 있습니다. Gale에서 같은 모드를 다른 폴더에 중복 추가하지 말고 기존 ForbiddenKey 설치의 세 파일을 교체하세요.

호스트와 게스트 모두 같은 파일로 업데이트하세요. 통신 형식은 계속 FK4입니다. 0.2.2와 바이트 형식은 같지만 객체 보호까지 일치시키려면 전원 0.2.3을 권장합니다. 0.2.1/FK3과는 통신할 수 없습니다.

이 ZIP에는 `BepInEx/config`가 없습니다. 기존 `ForbiddenKey.json`의 가중치·메시지와 `local.forbiddenkey.bootstrap.cfg`의 개발자 설정을 덮어쓰거나 초기화하지 않습니다. `presets`는 참고 예제이며 자동 설치용 설정이 아닙니다. 이미 schemaVersion 2이면 기존 값을 유지합니다. 아주 오래된 schemaVersion 1의 최초 마이그레이션 규칙은 기존 코드와 같습니다.

### 최소 구성

```text
BepInEx 5 (manifest: BepInEx-BepInExPack-5.4.2305)
ForbiddenKey 0.2.3
```

BetterSpectate나 별도 네트워크·입력·설정 UI 모드를 요구하는 참조나 필수 의존성을 추가하지 않았습니다. BetterSpectate는 관전 기능이 필요하면 남겨도 됩니다. `HideManagerGameObject` 값을 수동 변경할 필요 없이 모드가 필요한 실행 중 보호 설정을 직접 적용하도록 작성했습니다. BepInEx.cfg 파일 자체는 수정하지 않습니다.

본체 로컬 컴파일에는 기존과 같이 Windows의 .NET Framework C# 컴파일러와 설치된 게임/BepInEx DLL이 필요합니다. 이것은 추가 게임 모드 의존성과 별개입니다. 컴파일러나 참조가 없으면 실패 로그가 남고 금지는 적용하지 않습니다. 인터넷 다운로드·관리자 권한 요청·게임 DLL 재배포는 하지 않습니다.

## 바뀐 객체 유지 구조

1. 새 로더의 `Awake()`에서 **본체 컴파일/로딩 전에** 공용 관리자 객체에 `HideAndDontSave`와 `DontDestroyOnLoad`를 적용합니다. 기존 hideFlags는 OR 연산으로 보존합니다.
2. 본체는 더 이상 공용 `BepInEx_Manager`에 붙이지 않고 **부모 없는 `ForbiddenKey_Runtime` 객체**에 붙입니다. 본체 컴포넌트 추가 전, 그 객체도 보호하고 장면 전환 시 유지합니다.
3. 설정은 로더 컴포넌트를 매번 경유하지 않고 관리형 `ConfigFile` 참조를 보관합니다. 경로·키 이름·값은 그대로입니다.
4. 중복 컴포넌트가 제거될 때 정상 본체의 입력 훅까지 해제하지 못하도록 정리 소유권을 검사합니다. 비정상 제거와 정상 게임 종료는 다른 로그를 남깁니다.

보호 플래그는 객체를 절대 삭제할 수 없게 만드는 기능이 아닙니다. 다른 모드가 이 특정 객체를 직접 Destroy하는 경우까지 막는 안티치트/불사 객체 기능은 아닙니다.

## 첫 실행 확인

다음 기록이 실제 `BepInEx/LogOutput.log`에 나오는지 확인하세요. Ready 로그에는 추가 설명이 들어갑니다.

```text
Loading [ForbiddenKey 0.2.3]
[ForbiddenKey] Bootstrap 0.2.3 lifecycle protection enabled before runtime load.
Lifecycle 0.2.3: independent protected runtime root; BetterSpectate is not required.
FK4 codec self-test passed: 4 player entries and Korean labels survived a local round-trip.
ForbiddenKey 0.2.3: ... protocol=4 ... Ready=True
Runtime update loop active; persistent root=ForbiddenKey_Runtime.
```

이 문구들은 성공 시 출력하도록 작성한 확인 기준이며, 작성 환경의 Unity 실행에서 관측한 결과는 아닙니다.

소스 변경을 감지하면 본체를 다시 컴파일합니다. 본체가 계속 0.2.1/0.2.2로 뜨면 교체 경로와 중복 설치부터 확인하세요. 캐시를 수동 제거해야 할 경우에는 게임을 종료하고 플러그인 폴더의 `ForbiddenKey.Runtime.bin`과 `runtime.fingerprint.txt` 두 파일만 지웁니다. 설정 파일은 삭제하지 마세요. 빌드 실패는 같은 폴더 `build.log`에서 확인합니다. 오래된 .bin 파일이 남았다는 사실은 빌드 성공 증거가 아닙니다.

## 기본 배정과 안내

가중치는 W/A/S/D/Shift/Control/MB1/MB2/ESC/Space 각각 10, E/Q 각각 5, G 7입니다. 합계 117, 실제 확률은 해당 값/합계입니다. 일반 추첨은 호스트 설정으로 플레이어별 독립 수행하며 같은 결과도 허용합니다. 키 바인딩을 바꾸어도 해당 동작 금지를 유지합니다.

```text
P1님은 W 키를 사용할 수 없습니다.
P2님은 Space 키를 사용할 수 없습니다.
P3님은 G 키를 사용할 수 없습니다.
P4님은 W 키를 사용할 수 없습니다.
```

전원 명단을 각자의 채팅 기록에 한 묶음으로 표시하는 처리와 궤도 복귀 시 `모든 키 잠금이 해제되었습니다.` 문구는 유지했습니다. 화면의 페이드 효과는 그대로이며, 채팅 재열기/조회로 확인하는 방식입니다. 이번 접속 안내 기록은 메모리에 남고 로비 이탈·게임 종료 후에는 보존하지 않습니다. 알려진 입장 알림 필터도 유지했습니다.

`/금지`, `/금지 전체`, `/금지 기록`, `/금지 동기화`를 유지합니다. 다른 채팅 명령 모드가 가로채면 명령이 동작하지 않을 수 있으며 이 버전에서 그 별도 호환 문제를 수정하지는 않았습니다.

## 개발자 설정과 키 예외

메인 메뉴 또는 일시정지 메뉴에서 F8로 개발자 창을 엽니다. 설정은 `BepInEx/config/local.forbiddenkey.bootstrap.cfg`를 그대로 사용합니다.

```ini
[개발자]
디버그 모드 = false
특정 키만 금지 =
```

호스트가 디버그 모드를 true로 하고 키를 지정하면 다음 출발부터 전원을 그 동작에 고정합니다. 일반 플레이는 독립 추첨입니다. 허용값은 `W, A, S, D, Shift, Space, E, G, Q, ESC, MB1, MB2`이며, Control은 일반 추첨에만 포함됩니다. 체크가 꺼져 있거나 값이 비면 일반 추첨입니다. 현재 진행 중 배정은 바꾸지 않습니다.

ESC는 OpenMenu 동작을 막으므로 같은 동작의 Tab도 제한됩니다. 기존 F10 일시정지 메뉴 예외는 유지합니다. E 금지에는 함선 레버 면제가 없으므로 솔로에서 레버 사용이 막히지 않게 하려면 E 가중치를 0으로 설정하세요. 한글 글꼴은 운영체제 글꼴로 보완을 시도하나, 특정 환경에서는 표시가 깨질 수 있습니다. 글꼴 파일은 포함하지 않았습니다.

## 검증과 빌드 자료

`docs/TEST_REPORT.md`, `docs/Runtime-lifecycle.patch`, `docs/Bootstrap-lifecycle.patch`에 검증 범위와 변경 코드를 담았습니다. `docs/CHECKLIST.md`는 BetterSpectate 없는 확인 순서입니다. `source/build_bootstrap.py`는 DLL을 재현하는 ECMA-335/CIL 생성기이며 C# 컴파일러가 아닙니다. `source/Bootstrap.cs`는 동일한 로더의 참조 C# 소스입니다.

`BUILD_LOCAL.cmd "게임 설치 경로" "모드 프로필의 BepInEx 경로"`는 사용자의 기존 C# 컴파일러로 본체와 로더를 선택적으로 빌드합니다. 빌드 출력은 패키지 폴더에 만들며 설치된 게임 파일을 자동 변경하지 않습니다. 성공 여부는 실제 실행 결과로 확인해야 합니다.
