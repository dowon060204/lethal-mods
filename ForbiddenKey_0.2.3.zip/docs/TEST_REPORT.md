# ForbiddenKey 0.2.3 — 실제 검증 범위

## 결론

새 **로더 DLL** 및 **본체 소스**를 작성했고, 로더 DLL의 구조/재현성/추가한 초기화 바이트코드 순서와 본체 소스 변경을 검사했습니다. **실제 C# 본체 컴파일, CLR 로딩, Windows 로더 실행, Unity 객체 유지, 입력 제한, 채팅 표시, 2인/4인 네트워크는 이 작성 환경에서 실행하지 못했습니다.** 테스트 수를 실제 게임 검증 수로 해석하지 마세요.

0.2.2에도 본체 부착 직전 공용 객체 보호가 있었음을 확인했습니다. 이번 0.2.3은 같은 파일을 버전만 바꾼 것이 아닙니다. 보호를 새 DLL의 Awake 시작으로 앞당기고, 본체를 공용 객체와 분리하며, 관리형 설정 참조와 중복 객체 정리 가드를 추가합니다.

## 실행한 검사

| 검사 | 결과와 정확한 범위 |
|---|---|
| DLL 재생성 | `source/build_bootstrap.py`로 0.2.3 DLL 생성. C# 컴파일러가 아니라 작은 ECMA-335/CIL 생성기입니다. |
| 독립 구조/패키지 검사 | `tests/verify_package.py` 통과. PE/CLI, 메타데이터, 메서드 범위, 버전, 동일 바이트 재현, 입력 스택 높이, 설정/manifest/icon 일치. 상세 체크 269개는 개별 메타데이터 항목을 포함하며 게임 시나리오 개수가 아닙니다. |
| 라이프사이클 회귀 검사 | `tests/test_lifecycle_patch.py` 10개 통과. 소스 순서, 부모 없는 독립 객체, 설정 참조, 중복 정리 가드, 이전 통신 코드 보존, 추가 의존성 없음 등을 검사합니다. |
| 로더 Awake 바이트코드 참고 실행 | 위 10개 중 하나. **실제 배포 DLL에서 읽은 Awake 코드**를 매우 작은 Python 해석기로 처리하며 Unity 객체와 Boot는 가짜 객체/함수로 대체합니다. 플래그 OR/보호 호출이 Boot보다 먼저인지 확인하는 것이며 CLR/Unity 실행은 아닙니다. 초기 hideFlags 0, 2, 61, 64, 128, 1024를 확인했습니다. |
| FK4 참고 모델 | `tests/test_wire_reference.py` 18개 통과. 이전과 같은 Python 참고 구현이며 C# 실행은 아닙니다. |
| 구분자 검사 | C# 주석/문자열을 제외한 중괄호/괄호/대괄호 균형. 구문/타입 검사나 컴파일을 대신하지 않습니다. |

원시 출력은 `lifecycle-test-results.txt`, `wire-reference-results.txt`, `package-verification.json`, `bootstrap-structure.json`, `delimiter-check.json`에 있습니다.

## 이전 코드 보존 확인

0.2.2에서 추출한 WirePacket, WireCodec, NetworkBridge, InputGate, Patches, ChatHooks의 해시를 비교했습니다. NetworkBridge에 포함된 **진단 문구의 버전 문자열**을 정규화한 것 외에는 이 영역을 변경하지 않았습니다. 기본 가중치 합계는 117, 메시지와 설정 경로도 유지합니다. `tests/protocol4-baseline.json`은 이 비교용 해시입니다.

## 실제 확인이 필요한 부분

- BepInEx + ForbiddenKey만 있는 프로필에서 초기화 로그, 첫 Update, 메뉴→로비→출발→귀환→재입장 후 생존.
- BetterSpectate 없이 호스트/게스트 모두 전원 명단 표시와 각자 조작 제한.
- 서로 호스트 역할을 바꾸어 FK4 명단 수신과 ACK, 4인 확장.
- Windows 설치에 포함된 C# 컴파일러와 실제 참조 파일을 통한 본체 빌드.
- 다른 모드와의 객체/입력/채팅 호환. 특정 객체를 직접 Destroy하는 외부 모드에 대한 절대적 보호는 제공하지 않습니다.

작성 환경에 컴파일러와 Unity 실행 환경이 없으므로 실기 해결 보장은 하지 않습니다. 사용자의 기존 BetterSpectate 최소 재현은 원인 수정의 근거이고, **새 코드의 성공 확인**을 대신하지 않습니다.
