# PensilScrapCompare 0.1.7

이 README는 실제 Build.cmd 성공 시 생성되는 설치 ZIP용입니다. 배포 소스에 DLL이 있다는 의미가 아닙니다.
빌드 성공과 실제 Unity/멀티플레이 검증은 다릅니다. 검증 상태는 validation/VALIDATION.md 및 build-info.json을 확인하세요.

## 설치/업데이트

BepInEx 5 + 이 모드만 필요합니다. 본인 클라이언트에만 설치하는 읽기 전용 설계입니다.
게임을 종료한 뒤 BepInEx/plugins/PensilScrapCompare/PensilScrapCompare.dll을 교체합니다.
다른 폴더에 같은 모드 DLL이 있으면 중복본만 제거합니다. 기존 설정 파일은 삭제하지 않습니다.

## 설정

한 번 실행한 뒤 BepInEx/config/pensil.scrapcompare.cfg에서 수정하고 게임을 완전히 다시 실행합니다.

```ini
[Counting]
EnableBasicCounter = true
EnableTeamPickupCounter = false
```

기본만 켜기: 나의 신규 픽업 + 함선 수집 알림.
팀원 기능만 켜기: 나의 신규 픽업 + 팀원 신규 픽업.
둘 다 켜기: 세 관측 경로의 중복 없는 합계. 둘 다 끄기: 집계와 화면 숫자 비활성화.
서로 다른 플레이어가 같은 물건을 주워도 하나로 계산합니다. 팀원 기능은 기본 비활성화입니다.

> 팀원이 주운 아이템 기능은 암기 지원의 영역을 벗어난 사기성 기능입니다. 이 기능을 이용함으로서 발생한 문제에 대해 책임을 지지 않습니다.

설정은 본인에게만 적용하며 호스트에게 강제하지 않습니다.
오른쪽 위 숫자 하나, 다음 날 초기화, 시체/샷건/식칼/벌집/이미 가산한 상자의 내용물 제외 규칙은 유지합니다.
본인 클라이언트에 동기화된 소지품만 관측합니다. 접속 전이나 동기화되지 않은 픽업까지 복원하지 않습니다.
실제 호스트/게스트 재접속/4인 테스트는 별도로 필요합니다.
추가 설명은 validation/CONFIGURATION.md에 있습니다.
