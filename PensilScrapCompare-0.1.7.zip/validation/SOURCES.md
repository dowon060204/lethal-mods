# 참고 자료와 근거의 한계

확인일: 2026-09-23. 참고 자료는 외부 문서이며 사용자 PC에 설치된 바이너리와 동일함을 의미하지 않습니다.

## 공개 게임 참조 패키지

LethalCompany.GameLibs.Steam 81.0.5-ngd.0의 게시 페이지는 netstandard2.1 대상의 stripped/publicised 라이브러리임을 설명합니다. 페이지의 공개 여부와 버전은 확인했지만 이 작성 환경에서는 패키지 바이너리를 확보하지 못했습니다. 실제 게임 버전·메서드 본문·실행 가능성 확인에 대신 사용하지 않았습니다.

```text
https://www.nuget.org/packages/LethalCompany.GameLibs.Steam/81.0.5-ngd.0
```

## Unity 객체 보호와 글꼴

Unity 2022.3 HideFlags 문서는 일부 플래그 변경이 OnDisable/OnEnable을 유발하고 Scene/physics 소속에 영향을 준다고 설명합니다. 이 때문에 UI를 비활성화한 후 보호 플래그를 먼저 적용하고 컴포넌트를 구성하며, 자기 생성 객체를 명시적으로 정리하는 순서를 채택했습니다. 이 설계의 Lethal Company 실증은 별도입니다.

```text
https://docs.unity3d.com/2022.3/Documentation/ScriptReference/HideFlags.html
https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Font.CreateDynamicFontFromOSFont.html
```

## Harmony / HarmonyX

HarmonyX 공식 위키는 원본이 생략돼도 다른 Prefix들이 실행될 수 있는 동작 차이를 설명합니다. Prefix 호출만으로 수집 성공을 가정하지 않고 Postfix의 __runOriginal과 큐 상태를 함께 확인하도록 했습니다. 사용자 환경의 실제 Harmony를 사용한 프로브는 게임 시작 시 실행하도록 작성했으며 여기서는 미실행입니다.

```text
https://github.com/BepInEx/HarmonyX/wiki/Prefix-changes
https://harmony.pardeike.net/articles/patching-injections.html
https://github.com/BepInEx/BepInEx/blob/v5.4.21/BepInEx/Bootstrap/Chainloader.cs
```

## 보조적인 게임 API 명칭 근거

다음 개발자 공개 소스의 검색 결과에서 HUDManager.AddNewScrapFoundToDisplay, itemsToBeDisplayed, isInShipRoom, scrapPersistedThroughRounds 등의 사용 사례를 확인했습니다. 해당 페이지 전체를 다시 여는 요청은 실패했고, 이 자료만으로 v81의 정확한 게임 메서드 본문을 검증한 것이 아닙니다. 그래서 그 명칭들은 설치 DLL에 대조해야 하는 **명시적 잠정 계약**으로 제공했습니다.

```text
https://thunderstore.io/c/lethal-company/p/TheSecretDev/Unlimited_Scan/source/
https://github.com/Exund/ConfigurableWipe/blob/master/Plugin.cs
```


## 0.1.1에서 도입한 다음 날 전환 지점의 근거

OpenLib 개발자가 공개한 코드/배포 소스는 `StartOfRound.PassTimeToNextDay` Postfix를 `NextDayEvent`로 연결합니다. 이 사용례는 일 경계 관측 지점 선정의 근거이며, 우리 모드가 OpenLib를 요구하거나 해당 코드를 로드한다는 뜻은 아닙니다. 현재 설치된 Lethal Company 메서드의 정확한 인자 목록, 본문과 게스트 호출을 이 사용례만으로 검증한 것으로 취급하지 않습니다.

```text
https://github.com/darmuh/OpenLib
https://thunderstore.io/c/lethal-company/p/darmuh/OpenLib/source/
```

조회한 배포 소스의 `NextDayPatch`와 `PassTimeToNextDay` 연결을 확인했습니다. 기본 API 계약에 새 이름을 추가했고, 외부 메타데이터 감사와 런타임 리플렉션에서 **동일 이름의 유일한 비제네릭 instance void 메서드**를 요구합니다. 인자를 사용하지 않는 Postfix이므로 인자 수/타입을 가정하지 않고 실제 설치본의 전체 서명을 기록합니다. 모호한 오버로드나 다른 반환형을 임의 선택하지 않습니다. 이런 검사도 현재 버전에서 정상 동작했다는 실기 증거는 아닙니다.

## 0.1.2 수정 근거와 검증 제한

이번 개인 획득 수정의 직접 근거는 제공된 0.1.1 소스의 `Service.LocalInventoryTick`, `GameApi.HeldBy`, `GameApi.ShipKnownNow`, 로컬 재바인딩의 `ledger.Baseline` 호출입니다. 실행 로그나 게임 메서드 본문을 확보한 것은 아니므로 사용자 증상의 유일한 원인이 확인됐다고 주장하지 않습니다. 다른 모드의 API를 필수 의존성으로 추가하지 않았습니다.

UI 앵커 상대 위치의 의미는 Unity 공식 RectTransform 문서에서 확인했습니다. UI 실행/해상도별 가독성 검증은 별개입니다.

```text
https://docs.unity3d.com/2022.3/Documentation/ScriptReference/RectTransform-anchoredPosition.html
```

공개 API/모드 소스 검색을 시도했지만 현재 사용자 게임 버전의 원본 픽업 로직·필드 갱신 순서를 확정할 수 있는 전체 본문은 확보하지 못했습니다. 새로 읽는 GameNetworkManager 로컬 참조, currentlyHeldObjectServer, isHoldingObject는 명시적 필수 계약으로 로컬 설치본에 대조하도록 했습니다. 이 검사는 성공 전에 게임 호환을 선언하지 않기 위한 장치이며 검증 완료의 대용품이 아닙니다.

## 0.1.3 API 탐색 근거 및 한계 (2026-09-24)

현재 대화의 0.1.2 소스를 직접 읽은 것이 변경의 직접 근거입니다. 공개 모드 배포본의 디컴파일 자료에서 다음 심볼 사용을 확인했습니다. 이 자료는 해당 모드 바이너리의 사용례이지 사용자의 게임 메서드 본문을 확보한 증거가 아닙니다. 외부 모드 소스를 복사하거나 의존성으로 추가하지 않았습니다.

- QuickSell 1.1.10 배포 소스: `GiftBoxItem.OpenGiftBoxClientRpc`, `OpenGiftBoxServerRpc`, 클라이언트의 `waitForGiftPresentToSpawnOnClient` 관측 사례. 생성 지연과 호스트/게스트 경로를 따로 고려하는 근거입니다. 특정 코루틴 번호/로컬 변수 번호를 이 모드에 가져오지 않았습니다.
- BunkbedRevive LegitsFork 2.0.2 배포 소스: 플레이어 시체를 `RagdollGrabbableObject`로 구분하고 그 연결 필드를 사용하는 사례. 여기서는 시체 식별에 연결 필드나 bodyID를 사용하지 않습니다.

```text
https://old.thunderstore.io/c/lethal-company/p/Gafoneo/QuickSell/source/
https://old.thunderstore.io/c/lethal-company/p/LegitGamer1017/BunkbedRevive_LegitsFork/source/
```

Unity 공식 Netcode 문서/소스 원문을 여는 추가 요청은 실패했습니다. 따라서 이번 환경에서 NetworkObjectReference의 설치 버전 문서를 검증 완료했다고 주장하지 않습니다. 새 Netcode 참조 getter/TryGet 서명, 결과 인자 형식 및 시체/선물 상속 구조는 명시적 **설치본 검사 계약**이며 PE 감사와 런타임의 두 경로에서 실제 DLL과 일치해야 합니다. 게임 버전·메서드 본문·RPC 의미와 실기는 여전히 미검증입니다.


## 0.1.6 벌집 내부 이름 (2026-09-25 조회)

ShipSort 개발자 배포 페이지의 Vanilla Items 표 검색 결과는 Hive를 내부 이름 `RedLocustHive`, 타입 `PhysicsProp`으로 표기합니다. 같은 개발자의 `Utils.cs`는 GrabbableObject의 내부 name을 사용하고 끝의 `(Clone)`을 구분하는 사용례를 보여 줍니다. 이 사실을 바탕으로 벌집 타입 전체나 번역 표시명이 아닌 내부 프리팹/루트 이름을 비교합니다. 외부 코드를 모드에 복사하거나 ShipSort를 의존성으로 추가하지 않았습니다.

```text
https://thunderstore.io/c/lethal-company/p/baer1/ShipSort/
https://github.com/baerchen201/LethalShipSort/blob/main/Utils.cs
```

표는 검색 도구가 반환한 원문에서 확인했고 배포 페이지를 직접 다시 열었을 때 표가 본문에 나타나지 않았습니다. GitHub Utils.cs 본문에서는 내부 name과 Clone 접미사 처리 사용례를 확인했습니다. 이 자료는 사용자 설치본의 리소스/바이너리 검사가 아닙니다. 현재 게임의 실제 벌집 프리팹, 메서드 본문, 호스트/게스트 흐름은 미검증입니다. `Item.spawnPrefab : UnityEngine.GameObject` 계약은 로컬 실제 DLL 감사가 별도로 필요합니다.


## 0.1.7 설정/팀원 관측 (2026-09-25)

이번 변경의 직접 기준은 대화의 실제 0.1.6 ZIP입니다. 아래 외부 자료는 API 설계 근거이며 설치 게임 버전/실행 검증을 대신하지 않습니다.

- BepInEx 5.4.21 공식 ConfigFile 소스의 Bind, SaveOnConfigSet, Save, Reload, OrphanedEntries 보존 및 UTF-8 저장 경로를 확인했습니다. 실제 설치된 라이브러리로 런타임 왕복 검사를 별도로 하도록 작성했습니다. 코드를 복사하거나 BepInEx DLL을 동봉하지 않았습니다.
- BepInEx 설정 튜토리얼은 플러그인 Config와 GUID 기반 설정 경로/자동 생성에 대한 참고입니다.
- ImpostorCompany 개발자 배포 소스에는 StartOfRound.allPlayerScripts와 isPlayerControlled/isPlayerDead를 함께 사용해 현재 플레이어 상태를 구분하는 예가 있습니다. 이 심볼은 추가 기능의 잠정 계약으로 분리했고 현재 설치 DLL에 대조해야 합니다. 그 모드를 의존성으로 사용하지 않습니다.
- 현재 게임의 원격 인벤토리 갱신 타이밍이나 멀티플레이 전체 픽업 전달을 입증하는 실제 게임 DLL/실행 결과는 확보하지 못했습니다. 이 한계는 README/CONFIGURATION/VALIDATION에 명시했습니다.

```text
https://raw.githubusercontent.com/BepInEx/BepInEx/v5.4.21/BepInEx/Configuration/ConfigFile.cs
https://docs_new.bepinex.dev/articles/dev_guide/plugin_tutorial/3_configuration.html
https://thunderstore.io/c/lethal-company/p/Vincenzo/ImpostorCompany/source/
```
