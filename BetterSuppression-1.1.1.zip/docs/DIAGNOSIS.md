# 원인 분석과 수정 근거 — BetterSuppression 1.1.1

## 결론의 범위

첨부된 **실제 원본 소스**를 읽고 수정했습니다. 원본과 외부 1차 자료를 연결하면 BetterSpectate가 공용 BepInEx 실행 객체의 보호 플래그를 대신 설정하는 경로가 존재합니다. 원본 BetterSuppression는 그 플래그를 직접 설정하지 않고, 자기 객체가 파괴되면 오디오 패치와 처리기를 정리합니다. 이 경로는 사용자가 보고한 “BetterSpectate가 있어야 작동” 현상을 설명할 수 있는 구체적인 소스 근거입니다.

그러나 이번 ZIP에는 실행 로그, BepInEx.cfg, 게임 어셈블리가 없습니다. **어느 게임 함수가 실제로 언제 객체를 제거했는지, 원인 플래그가 이것 하나인지, 수정으로 실제 재현이 해소됐는지는 확정하지 않았습니다.** 스크린샷은 기존 UI의 증거이지 OnDestroy 발생 로그가 아닙니다. 다른 모드에도 같은 내부 원인이라고 일반화하지 않습니다.

원본 ZIP SHA256: `b0f2c6e2de425d3a7fd772e2cbb1c3d66848aca687ab05aa51c0e7459a60c583`.

## 원본에서 확인한 사실

| 확인한 내용 | 실제 소스 위치 |
|---|---|
| BaseUnityPlugin 본체이며 GUID는 유지 대상 | `BetterSuppressionPlugin.cs:20` |
| Awake에서 이미 DontDestroyOnLoad(gameObject)를 호출 | `BetterSuppressionPlugin.cs:57` |
| MicTestOverlay를 플러그인의 같은 GameObject에 부착 | `BetterSuppressionPlugin.cs:164` |
| OnDestroy가 자기 Harmony를 해제하고 DissonancePatch.Cleanup을 호출 | `BetterSuppressionPlugin.cs:308` |
| 처리기 getter가 필요할 때 새 처리기를 만들고 설정 적용 경로로 들어감 | `DissonancePatch.cs:19` |
| Cleanup이 처리기 Dispose 후 정적 참조를 비움 | `DissonancePatch.cs:45` |
| Dispose와 ProcessAudio 사이에 네이티브 수명 직렬화가 없음 | `VoiceAudioProcessor.cs:332` / `VoiceAudioProcessor.cs:143` |
| 원래 실제 패치 대상은 마이크/재생 콜백 두 개 | `DissonancePatch.cs:66` / `DissonancePatch.cs:84` |

`DontDestroyOnLoad` 한 줄이 빠졌다는 진단은 원본과 맞지 않습니다. 원본에는 별도 런타임 컴파일 로더도 없습니다. 본체는 하나의 플러그인 DLL이며 오버레이가 일반 MonoBehaviour입니다. 입력/HUD/플레이어의 특정 장면 참조나 자체 RPC 등록에 기대는 구조가 아니라 Dissonance의 실제 콜백을 패치합니다.

원본의 익명 설정 이벤트와 getter 지연 생성은 종료 뒤 구독이나 UI 접근이 남아 있을 때 네이티브 처리기를 다시 만들 수 있는 별도 취약점입니다. 이는 최초 객체 파괴의 원인과 구분하며, 반드시 실제로 실행되었다고 단정하지 않습니다.

## BepInEx / BetterSpectate와 연결되는 경로

BepInEx v5.4.21 `Chainloader.Start()`는 `BepInEx_Manager`를 만들고 DDOL을 적용하며 모든 플러그인을 그 객체의 `AddComponent`로 붙입니다. HideAndDontSave 적용은 `HideManagerGameObject` 설정에 달려 있고 그 소스의 기본값은 false입니다. 즉 두 플러그인의 `gameObject`가 같은 객체인 경로를 확인했습니다. 사용자 프로필의 실제 설정은 제공되지 않았으므로 기본값과 같다고 추정하지 않습니다. [BepInEx v5.4.21 Chainloader.cs, 272–276 / 395 / 428–435](https://raw.githubusercontent.com/BepInEx/BepInEx/v5.4.21/BepInEx/Bootstrap/Chainloader.cs).

Fusition BetterSpectate 1.0.0의 배포 바이너리 역컴파일 공개본에서는 `BetterSpectateBase.Awake()`가 자기 `gameObject.hideFlags`에 61을 대입합니다. [해당 배포 소스](https://old.thunderstore.io/c/lethal-company/p/Fusition/BetterSpectate/source/). 이는 관전 기능의 직접 호출을 BetterSuppression가 요구한다는 뜻이 아니라 **공유 실행 객체의 속성 변경이라는 간접 효과**를 확인한 것입니다. 사용자가 사용한 BetterSpectate DLL 자체는 이번 첨부에 없어서 바이너리 동일성까지 확인하지는 못했습니다.

Unity 2022.3 enum에서 HideAndDontSave는 61입니다. [Unity 실제 enum 정의](https://raw.githubusercontent.com/Unity-Technologies/UnityCsReference/2022.3/Runtime/Export/Scripting/UnityEngineObject.bindings.cs). Unity 문서는 관련 hide/save 비트 변경이 내부 장면 상태와 OnDisable/OnEnable에 영향을 줄 수 있다고 설명합니다. [Unity HideFlags](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/HideFlags.html). 따라서 플래그 변경을 초기화 실패/종료로 해석하지 않아야 합니다.

## 구현한 수정

### 1. 본체 진입점에서 객체 보호

`BetterSuppressionPlugin.cs:67` → `RuntimeObjectGuard.cs:14`.

`Awake`는 로거와 중복 상태만 준비한 뒤 보호 함수를 호출합니다. 그 다음에 설정/native/패치/선택적 UI를 다루는 `InitializeCore()`로 들어갑니다. 로더를 새로 만들거나 나중에 로드되는 본체에 보호를 미루지 않았습니다.

보호 대상은 **플러그인이 실제로 붙은 공용 루트**입니다. 기존 비트와 HideAndDontSave를 OR 결합하고 값이 다를 때만 씁니다. 변경 시 DDOL을 뒤에 호출하는 것은 기존 DDOL을 부정해서가 아니라 플래그 변경 뒤의 지속성을 다시 지정하기 위함입니다. 이미 보호되어 있으면 덮어쓰지 않습니다. 루트가 아니라면 공용 객체의 부모를 임의로 바꾸지 않고 구체적인 오류로 중단합니다. DDOL은 루트 객체에 적용해야 한다는 제약도 확인했습니다. [Unity DDOL](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Object.DontDestroyOnLoad.html).

이 선택은 공용 객체의 다른 플러그인에도 영향을 미칩니다. 플래그 보존·1회 적용·진단 로그를 넣었지만 모든 다른 모드와 호환됨을 검증한 것은 아닙니다. 코드가 명시적으로 `Destroy(gameObject)`하는 경우까지 막는 가상의 보호 기능은 주장하지 않습니다. 실제 파괴가 계속되면 추가된 로그와 해당 게임 실행 경로가 필요합니다.

전용 루트를 새로 만들지 않은 이유는 기존 구조에서도 초기 플러그인/오버레이의 공용 객체를 보호하는 작은 수정을 할 수 있기 때문입니다. 새 singleton/코루틴/워치독은 없습니다.

### 2. 일시 비활성화와 실제 정리 구분

`BetterSuppressionPlugin.cs:270`, `BetterSuppressionPlugin.cs:277`, `BetterSuppressionPlugin.cs:326`, `BetterSuppressionPlugin.cs:334`, `BetterSuppressionPlugin.cs:346`.

OnDisable에서는 로깅만 하고 패치와 처리기를 유지합니다. OnEnable에서도 재초기화/재구독하지 않습니다. 실제 종료나 파괴 또는 초기화 예외가 발생하면 Stop을 한 번만 수행합니다. 처리 콜백을 닫고 이벤트를 해제한 뒤 자기 Harmony 소유 패치만 해제하고 네이티브 상태를 정리합니다. 종료 플래그 뒤에 새 객체를 생성하거나 재시도 루프를 돌리지 않습니다. Unexpected OnDestroy는 경고하고 실제 정리하며 무시하지 않습니다.

설정은 개별 익명 이벤트 대신 해당 모드 `Config.SettingChanged`를 한 번 구독하고 해제합니다. 이는 BepInEx의 실제 `ConfigFile` 이벤트를 사용합니다. [ConfigFile.cs](https://raw.githubusercontent.com/BepInEx/BepInEx/v5.4.21/BepInEx/Configuration/ConfigFile.cs).

### 3. 처리기 수명, 스레드, 장면/로비 연결

`DissonancePatch.cs:31`, `DissonancePatch.cs:78`, `DissonancePatch.cs:128`, `VoiceAudioProcessor.cs:90`, `VoiceAudioProcessor.cs:382`.

getter는 순수 참조 조회로 변경했습니다. 처리·설정·폐기를 직렬화하여 사용 중인 RNNoise 포인터를 동시에 폐기하지 않도록 구현했습니다. static 처리기 참조는 정리 시 비우고, 이미 가져간 참조에도 `_disposed`가 있어 늦은 작업을 차단합니다. 종료 후 UI가 네이티브 상태를 다시 만드는 경로를 막았습니다.

플레이어/HUD의 장면 객체는 애초 필요하지 않습니다. 새 마이크 캡처 컴포넌트는 실제 패치 콜백의 `__instance`로 들어오므로 그때 갱신합니다. 메인 메뉴에서 아직 마이크나 NetworkManager가 없으면 초기화 실패라고 하지 않습니다.

`RuntimeDiagnostics.cs:40`는 현재 NetworkManager Singleton을 최대 초당 한 번 읽고 관측 상태가 달라졌을 때만 로그를 씁니다. 호스트/게스트/서버/연결/리스닝을 분리합니다. 관측한 연결 경계나 교체에서 DSP 이력을 비우며 패치를 유지합니다. 이전 로비의 NGO 이벤트를 구독한 적이 없으므로 그런 구독을 다음 로비로 가져가지 않습니다. 장면 이벤트는 명시적으로 해제합니다.

이 관측은 게임 실행으로 검증하지 않았고 폴링 사이에 일어난 매우 짧은 재접속은 놓칠 수 있습니다. 해당 버전에서 반사 대상 타입/프로퍼티를 찾지 못하면 로그를 남기고 오디오 자체를 중단하지 않습니다. 네트워크 패킷 형식이나 다른 플레이어 전송 처리를 수정하지 않았습니다. **로컬 객체 생존과 멀티플레이 음성 전달 성공은 별도 판정**입니다.

### 4. 진단과 최소 UI

`BetterSuppressionPlugin.cs:409`, `RuntimeDiagnostics.cs:12`, `DissonancePatch.cs:143`, `MicTestOverlay.cs:79`.

플러그인 버전과 실제 본체 어셈블리/파일 버전, 로드 위치, BepInEx 버전, 공용 객체의 이름/ID/활성/플래그를 기록합니다. BepInEx의 이미 바인딩된 보호 설정은 읽기만 하며 읽을 수 없으면 unknown으로 기록합니다. 초기화 완료, 최초 Update, 최초 실제 로컬/재생 콜백은 서로 다른 로그입니다. 재생 콜백이 무음일 수 있음을 명시합니다. 모든 예외 기록은 메시지뿐 아니라 전체 예외/스택을 포함하도록 했습니다.

화면은 `Input (Raw)` / `Gate Gain` 두 행입니다. 두 텍스트·값·막대와 배경 외에 제목/설명/하단 UI는 없습니다. 사용되지 않게 된 FFT 저장/복사와 DFT 작업을 제거했습니다. 소스 구조상 두 행인 것은 확인했지만 Unity에서 렌더한 화면은 제공하지 않습니다.

## 보존 범위와 남은 위험

원래 RNNoise → 게이트의 핵심 샘플 연산을 공백/주석을 제외한 텍스트로 비교해 보존 여부를 확인하는 정적 검사를 제공합니다. 이는 실제 음질·속도·파형 회귀 테스트가 아닙니다. 필터 전부 OFF 때 미터를 갱신하는 경로, 설정 전환 시 FIFO 리셋, 새 캡처/세션 경계의 상태 리셋은 명시적인 부수 변경입니다.

원본 단일 remote processor가 여러 재생 소스/채널을 처리하는 설계와 48kHz 가정은 이 작업에서 바꾸지 않았습니다. 본 수정은 그 설계의 정확성이나 네트워크 동기화를 새로 보증하지 않습니다. 실제 RNNoise 라이브러리와 잠금 성능, 게임 업데이트 이후 API, 같은 공용 객체의 다른 플러그인과의 상호작용은 게임 테스트가 필요합니다.

네이티브 원본 SHA256: `12e19bf7a18d13e092a5fbe5a7c5b2081f5e7b56f6d77aeab5837335f44ceedf`. 관리형 구버전 DLL을 새로운 빌드로 이름만 바꾸지 않았습니다. 현재 배포에는 수정 소스·빌드/설치 자료·작성했지만 미실행인 테스트만 있고 새 관리형 DLL은 없습니다.
