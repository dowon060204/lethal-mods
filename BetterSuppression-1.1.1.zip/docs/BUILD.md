# Build

## Normal use

1. Install .NET SDK 8 or newer.
2. Extract this source folder outside `BepInEx/plugins`.
3. Double-click `BUILD.cmd`.

No game/profile path prompt is used.

The script searches, in order:

- `LETHAL_COMPANY_PATH` when already set
- the normal Steam Lethal Company folder
- additional Steam libraries from `steamapps/libraryfolders.vdf`
- a game-local `BepInEx` folder if valid
- Gale profiles in `%APPDATA%\com.kesomannen.gale\lethal-company\profiles`
- the dedicated Gale build profile `빌드용` first, then other valid profiles by recent modification time
- `LethalConfig.dll` in the selected profile and then all Gale Lethal Company profiles

The `빌드용` name is constructed with Unicode code points inside PowerShell rather than stored literally in the build script. `BUILD.cmd` is ASCII with CRLF line endings. This is intentional for Windows PowerShell 5 and Korean profile paths.

The path layer intentionally does not use `Resolve-Path` or `.ProviderPath`. MSBuild intermediate paths are also passed without a trailing slash, avoiding the native argument parsing problem previously seen with spaces/non-ASCII paths.

## Outputs

After a successful fresh C# compile:

- `artifacts\BetterSuppression.dll`
- `dist\BetterSuppression-<version>.zip`
- `artifacts\build-result.json`
- per-run logs under `artifacts\run-*`

An old DLL is never treated as proof that the current source compiled. The install ZIP is deleted before each attempt and recreated only after a successful build.

## Optional overrides

Normal users do not need these. They remain available for unusual installations:

```powershell
.\build.ps1 -GamePath "D:\SteamLibrary\steamapps\common\Lethal Company"
.\build.ps1 -BepInExPath "D:\SomeProfile\BepInEx"
.\build.ps1 -LethalConfigPath "D:\References\LethalConfig.dll"
.\build.ps1 -RunManagedTests
```

`LethalConfig.dll` is a compile-time reference for the existing optional UI integration. The build script does not make LethalConfig a new runtime requirement.

## What the build does not verify

A successful build verifies compilation and packaging only. It does not prove actual Unity lifecycle behavior, RNNoise audio quality, BetterSpectate independence in-game, or multiplayer behavior.
