# 검증 기록과 실행 체크리스트

## 수행 수준 — 배포 작성 시점

| 단계 | 상태 | 실제로 한 것 / 하지 못한 것 |
|---|---|---|
| 1. 소스 정적 점검 | 수행 | 원본 ZIP 전체 소스 읽기, BepInEx/BetterSpectate/Unity 자료 대조, 수명·구독·정리 경로 검토, Python 파일/설정/핵심 계산 비교, native PE 정적 검사 |
| 2. 실제 C# 컴파일 | 미검증 / 미실행 | dotnet/csc/mcs/mono가 없고 실제 참조 DLL 9개도 없음. SDK/참조 다운로드 실패. 새 DLL 없음 |
| 3. 실행 가능한 테스트 | 미검증 / 미실행 | 관리형 테스트 9개를 작성했으나 컴파일·실행하지 않음. Python 정적 검사 결과와 별개 |
| 4. 실제 게임 실행 | 미검증 / 미실행 | Unity 게임 런타임, Lethal Company 게임 설치 및 실행 로그 없음 |
| 5. 실제 멀티플레이 확인 | 미검증 / 미실행 | 두 클라이언트 실행 및 음성 전달 확인 없음 |

`tools/verify_sources.py`와 `docs/static-checks.txt`는 **텍스트/패키징 정적 검사만** 의미합니다. `objdump` 결과도 DLL 실행을 뜻하지 않습니다. `tests/`는 테스트의 소스이지 통과 증거가 아닙니다. 빌드/게임 성공 로그를 만들어 넣지 않았습니다. PowerShell 빌드/설치 스크립트도 작성·정적 검토만 하고 실행하지 않았습니다.

## 최소 실행 환경

수정 소스의 실제 빌드가 먼저 성공해야 합니다. 별도 깨끗한 프로필에 `BepInEx + 빌드된 BetterSuppression.dll + 원본 rnnoise.dll`을 사용합니다. Unity/Dissonance는 설치된 게임의 것을 사용합니다. 선택적 LethalConfig는 빌드 참조만 별도 폴더에 보관할 수 있으므로 첫 실행 최소 프로필에서는 제외합니다. BetterSpectate와 객체 보호를 대신할 수 있는 무관한 모드는 제외합니다.

기존 프로필의 BepInEx.cfg를 복사해 우연히 통과시키지 않습니다. 해당 테스트 프로필의 `[Chainloader] HideManagerGameObject` 실제 값을 보관합니다. BepInEx v5.4.21 소스 기본값은 false이지만 테스트 환경도 false라고 가정하지 않습니다. 테스트 시작 로그의 `[loader]` 관측값과 `[lifetime]` 최초 flags를 함께 확인합니다. 기본 false 상태에서도 모드 스스로 보호 플래그를 적용하는지 보는 것이 목표이며, 사용자에게 보호 cfg 변경을 해결책으로 요구하지 않습니다.

## 실제 게임 체크리스트 — 아래 모두 미실행

| 구성/상황 | 확인할 실제 현상 | 판정 |
|---|---|---|
| 최소 구성 첫 실행 / 메인 메뉴 | 초기 보호, initialized, Plugin과 Overlay 첫 Update, unexpected OnDestroy 없음 | 미검증 |
| 싱글 / 마이크 입력 허용 상태 | 말할 때 Raw 값이 변하고 게이트 이득이 실제 입력/임계값에 반응 | 미검증 |
| 싱글 / RNNoise 단독·게이트 단독·모두 OFF | 각 설정 동작, OFF의 입력 미변조, ON의 실제 소음 억제 효과를 각각 확인 | 미검증 |
| 로딩·장면 전환·라운드 종료·다음 라운드 | 일시 disable 이후 반복 처리/실제 오디오 유지, 영구 unpatch 없음 | 미검증 |
| 로비 이탈 후 새 로비 재참가 | 현재 Singleton/캡처로 다시 관측, 이전 이력/참조 문제 없음 | 미검증 |
| 마이크 장치 변경/캡처 교체 | 새 실제 콜백을 따라 Raw 값 갱신, stale meter 표시가 거짓 성공으로 남지 않음 | 미검증 |
| 2명 모두 수정본: A 호스트/B 게스트 | A/B 각각 Update·로컬 입력·상대 음성 수신/청취/필터 확인 | 미검증 |
| 2명 모두 수정본: B 호스트/A 게스트 | 위 검사를 역할 교환하여 동일하게 확인 | 미검증 |
| BetterSpectate를 다시 추가 | 중복 초기화·중복 구독·불필요한 flag write·충돌 여부 | 미검증 |
| LethalConfig 다시 추가 및 기존 cfg 사용 | 각 기존 값 유지, 실시간 설정 적용, UI 두 행 | 미검증 |
| 정상 게임 종료 | quitting=true, Stop 1회, native state 정리, 재생성/무한 재시도 없음 | 미검증 |

싱글플레이에는 실제 상대에게 전달되는 음성을 확인할 수 없는 한계가 있습니다. Raw/Gain 미터나 local callback 로그만으로 RNNoise 음질/전송까지 성공이라고 하지 않습니다. 원격 콜백이 들어와도 무음 버퍼일 수 있으므로 두 사람이 실제로 말하고 들어야 합니다.

## 로그 해석

로그 접두사는 `[version]`, `[loader]`, `[lifetime]`, `[initialization]`, `[patch]`, `[network]`, `[audio]`, `[native]`, `[cleanup]`입니다. 다음은 **코드가 기록하도록 만든 항목의 의미**이며 실제 실행 로그를 인용한 것이 아닙니다.

- `Awake entry` / `Protection checked`: 초기 객체와 변경 전후 플래그. 기존 비트가 없으면 61, HideInInspector까지 있었으면 63이 될 수 있습니다. 61만 정답이라고 다른 기존 비트를 지우지 않습니다.
- `initialization complete` / `Owner verified`: 해당 코드 단계 도달 또는 패치 메타데이터 확인일 뿐 기능 테스트가 아닙니다.
- `first Update observed`: Unity Update를 실제로 1회 관측. 초기화를 마쳤어도 이 항목이 없으면 실행 객체가 살아 있다고 결론 내리지 않습니다.
- `First local processing callback observed` / `First playback processing callback observed`: 실제 패치 경로로 처리 메서드가 호출됨. 소리 전달/음질/두 사람 테스트 성공과 다릅니다.
- `role=...`, `managerId=...`: 현재 호스트/게스트/리스닝/연결 상태를 읽은 진단이며 패킷을 새로 보내는 기능이 아닙니다.
- `OnDisable (retaining patches/processors)`: 일시 비활성화. hideFlags 변경 때도 가능한 호출이므로 이것만으로 종료라고 판단하지 않습니다.
- `Unexpected destruction outside application quit`: 여전히 실제 파괴가 발생했다는 단서. 오류를 숨기지 않고 자기 자원을 정리하며 새 객체로 무한 복구하지 않습니다.

메인 메뉴에 마이크가 준비되지 않았다면 Raw/Gain 대시는 정상적인 “아직 입력 미관측” 상태일 수 있습니다. 네이티브 로딩 오류는 별도 문제입니다. 해당 스트림 오류는 전체 예외를 기록하고 이후 우회하며 세션 경계/재시작에서 복구 기회를 줍니다.

## 테스트 기록에 함께 보관할 정보

각 실행의 게임 버전, 실제 BepInEx/참조 버전, 수정 DLL SHA256, native SHA256, 설치 모드 목록, HideManagerGameObject 값, 전체 LogOutput.log, 설정 파일을 기록합니다. 양쪽 클라이언트의 기록은 별도로 보관합니다. 원래 파일/설정을 지우는 방식으로 검증하지 않습니다.

객체 생존 성공/실제 로컬 DSP 성공/상대방에게 전달된 음성 성공을 각각 적습니다. 그 중 하나만 확인되면 다른 항목은 미검증으로 남깁니다.
