# 변경 내역

## 0.1.2 — 2026-09-18 — 대상 조작/출발 타이머/Alt+Tab/재바인딩 수정

- 셔플 대상을 이동 4방향, Jump, Sprint, Crouch, Interact, Discard, ActivateItem, ItemSecondaryUse, ItemTertiaryUse, PingScan, Emote1, Emote2, Utility slot으로 제한했습니다.
- `InspectItem` 및 그 밖의 `Movement` 액션을 후보에서 제거했습니다.
- 이동 액션에 기본 보조 바인딩으로 존재하는 Up/Down/Left/Right Arrow를 후보와 표시표에서 제외하고, Set 1 이상에서는 해당 화살표 바인딩을 빈 override로 임시 비활성화해 고정 우회키가 되지 않도록 했습니다. 메뉴/라운드 종료 시 복원합니다.
- 화이트리스트 액션에 사용자가 실제로 배정한 현재 키/마우스 버튼을 기준으로 풀을 만들도록 유지했습니다. 기본 WASD/E/Q 값을 강제로 사용하지 않습니다.
- 과거의 “화이트리스트 밖 액션과 같은 물리 키를 공유하면 후보 제거” 규칙을 폐기했습니다. 이 규칙 때문에 E, LMB, Shift, Ctrl 같은 실제 조작이 빠질 수 있었습니다.
- 유틸리티 슬롯을 액션 이름 또는 원본 Tab 바인딩으로 식별하는 런타임 탐지를 추가했습니다. `OpenMenu`는 명시적으로 제외합니다.
- 타이머 시작점을 로컬 플레이어/로비 연결 시각에서 `StartOfRound.inShipPhase` 종료(함선 출발) 전환으로 옮겼습니다.
- 출발 전 시간은 누적하지 않고, 출발 후에는 실시간 경과량을 사용합니다.
- Alt+Tab/포커스 해제를 pause 사유에서 제거했습니다. 큰 실시간 delta와 여러 overdue interval을 보존해 복귀 시 현재 세대로 따라잡습니다.
- UI 표시 조건을 포커스/일시적 입력 활성 상태와 분리해 복귀 후 사라지는 문제를 수정했습니다.
- 셔플 세대 중 사용자가 키 설정을 변경하면 새 baseline을 받아들이면서 Generation과 경과 타이머를 보존하고 새 키 풀에 셔플을 즉시 재구성합니다.
- 임시 랜덤 override를 사용자 영구 키 설정으로 저장하지 않도록 기존 `SaveBindingOverridesAsJson` guard를 유지했습니다.
- `Build.cmd`를 ASCII-only 한 줄 런처로 바꾸고 `Build.ps1` 기본 경로를 사용하게 했습니다. 한국어 Gale 프로필 경로를 위해 `Build.ps1`을 UTF-8 BOM으로 저장했습니다.
- 버전/manifest/빌드 출력명을 0.1.2로 갱신했습니다.

## 0.1.1 — 2026-09-18 — 실제 전역 게임 입력 자산 적용 수정

- 로그/UI만 바뀌고 실제 조작은 바뀌지 않던 문제를 수정하기 위해 `InputSystem.actions`를 1차 게임플레이 입력 자산으로 연결했습니다.
- 전역 게임 입력 자산의 `effectivePath` read-back을 별도 검증합니다.
- 설정/PlayerControllerB/HUD의 관련 입력 자산도 발견되는 경우 함께 갱신합니다.
- `[Input.GameplayOwner]`, `globalGameplayAssetReadBack=True` 진단 로그를 추가했습니다.

## 0.1.0 — 2026-09-17 — 최초 소스 후보

- 120초 주기 키 셔플, 독립 런타임, 입력 저장/복원, 로그 및 로컬 빌드 구조를 작성했습니다.

> 위 변경 내역은 소스 변경 사항입니다. 이 작업 환경에서는 0.1.2 C# 컴파일/게임 실행/멀티플레이 실기 검증을 수행하지 않았습니다.
