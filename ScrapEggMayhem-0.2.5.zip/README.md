# Scrap Egg Mayhem 0.2.5

원본 이스터에그의 투척/폭발 처리에 상점 아이템·사용 아이템 설정을 추가했습니다. 기본값은 0.2.4와 같습니다.

## 설치 및 업데이트

이 문서는 `build.cmd`가 성공한 설치 패키지용입니다. 게임을 종료하고 이전 `ScrapEggMayhem.dll`을 새 DLL로 교체하세요. 호스트와 모든 참가자가 같은 0.2.5 빌드를 설치해야 합니다. 구버전 DLL 중복 설치는 피하세요.

경로: `BepInEx/plugins/ScrapEggMayhem/ScrapEggMayhem.dll`

기존 설정 파일과 값은 보존합니다. 첫 실행 시 새 항목이 추가됩니다. BetterSpectate나 새 라이브러리는 필요하지 않습니다. 게임 원본 DLL과 BepInEx.cfg는 수정하지 않습니다.

## 설정

`BepInEx/config/local.scrapeggmayhem.cfg`:

```ini
[Explosion]
상점 아이템 폭파 가능 = false
사용 아이템 폭파 가능 = true
```

새 두 옵션은 **게임 재시작 후 적용**하며, 멀티에서는 **호스트 값**을 사용합니다. 두 분류에 겹치는 아이템은 두 옵션이 모두 켜져야 합니다. 샷건/레이저 포인터 등의 좌클릭은 켜거나 꺼도 기존 기능을 유지하며, 좌클릭 투척을 추가하지 않습니다.

`ExcludedItems`는 두 옵션보다 우선합니다. 원래 이스터에그·기절 수류탄 계열의 자체 폭발은 그대로입니다. 이 설정은 모드가 추가하는 폭발만 제어합니다.

## 확인

호스트·게스트 규칙 로그에 `shopExplosions`, `useExplosions`가 표시됩니다. 설치 패키지의 `BUILD_STATUS.json`에 로컬 컴파일 결과가 기록됩니다. 컴파일·순수 규칙 테스트 성공은 실제 Unity/멀티 검증을 의미하지 않습니다. 자세한 구현과 수동 테스트 표는 `docs/CONFIG_OPTIONS_KO.md`에 있습니다.
