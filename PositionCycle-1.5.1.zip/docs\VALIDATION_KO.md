# 검증 보고서 — PositionCycle 1.5.1

## 이번 1.2.0 로그에서 확인된 원인

- 호스트: `API_CONTRACT_OK`, `NETWORK_REGISTER role=HOST`, 게스트 `PEER_HANDSHAKE sessionConfirmed=True` 확인.
- 게스트: `API_CONTRACT_OK`, `NETWORK_REGISTER role=GUEST`, `BASELINE_RECEIVED`, `STATE GUEST_SESSION_BOUND` 확인.
- 호스트 스케줄: `originServerTime=2.700 interval=3600s firstBoundary=3602.700`. 테스트 로그에는 `PREPARE_CREATED`/`COMMIT_DECIDED`/`CYCLE_RESULT`가 없음.
- 따라서 이번 로그에서 보이는 직접 원인은 네트워크 초기화 실패가 아니라 **첫 실행 경계가 1시간 뒤였던 것**입니다.
- 1.5.1 소스에서는 interval을 60초로 변경하고, 전원 모드 Ready + 활성 생존자 2명 이상 시점부터 첫 60초를 계산합니다.


## 이번에 실제 확인한 것

- 사용자 제공 PositionCycle 1.2.0 호스트/게스트 로그 2개를 비교함.
- 양쪽 모두 `API_CONTRACT_OK`까지 도달해 현재 9인수 `DropAllHeldItems` 검사 문제는 재발하지 않았음을 확인함.
- 호스트에서 `PEER_HANDSHAKE client=1 sessionConfirmed=True`, 게스트에서 `STATE GUEST_SESSION_BOUND`를 확인해 전원 설치 핸드셰이크 경로가 성립했음을 확인함.
- 호스트 스케줄이 `interval=3600s`, `firstBoundary=3602.700`으로 설정됐고 테스트 로그에 실제 `CYCLE`/Prepare/Commit 기록이 없음을 확인함.
- 1.5.1 소스에서 주기를 60초로 변경하고, 전원 모드 Ready + 활성 생존 플레이어 2명 이상이 된 시점을 schedule origin으로 변경함.
- Python 정적 파일/문자열/JSON/XML 검사 64개를 패키징 전에 실행함.
- 사용자 제공 실제 `Assembly-CSharp.dll`에서 `ShipTeleporter.beamUpPlayer`의 3초+3초 빌드업, `DropAllHeldItemsAndSync`, `TeleportPlayer`, `shipTeleporterId` 1→-1 흐름을 메타데이터/IL로 확인함.


## 1.5.1 밝기 문제 수정

- 1.4.0이 시설/실외 좌표와 플래그만 변경하고 `AudioReverbTrigger.ChangeAudioReverbForPlayer`를 생략한 점을 수정함.
- 실제 v81 DLL에서 `AudioReverbPresets`, `audioPresets`, `AudioReverbTrigger`, `ChangeAudioReverbForPlayer`, `SetInsideLightingDimness` 멤버 존재를 확인함.
- 시설↔비시설 전환 시 preset 2/3을 PREPARE에서 먼저 검증하고 COMMIT 적용에서 호출하도록 소스를 변경함.
- 실제 게임에서 화면 밝기/날씨/안개가 즉시 정상화되는지는 아직 실기 미검증.

## 아직 미검증

이번 대화에서 사용자가 실제 v81 `Assembly-CSharp.dll`, `Unity.Netcode.Runtime.dll`, `UnityEngine.CoreModule.dll`을 제공했고 메타데이터/IL 검사는 수행했습니다. 다만 이 실행 환경에는 `dotnet` SDK가 없어 아래 C# 빌드/실기 검증은 아직 실행하지 않았습니다.

- PositionCycle 1.5.1 실제 C# 컴파일
- 1.5.1 C# self-test 실행
- 실제 게임에서 API_CONTRACT_OK 확인
- 2인/3인/4인 60초 경계 이동
- A호스트/B게스트와 B호스트/A게스트 역할 교대
- 사망자/관전자 포함 방의 전체 모드 게이트
- 중도 입장/재접속
- 실내↔실외↔함선 구역 이동
- 아이템이 실제 출발 위치에 정상적으로 남는지 화면 검증

사용자 PC에서 `build.cmd`를 실행하면 실제 게임 DLL을 참조한 컴파일, C# 공통 테스트, reference audit이 먼저 수행됩니다. 빌드 성공은 게임 실기 성공과 별개입니다.

## 3인 실제 로그에서 확인한 1.4.0 결함과 1.5.1 수정

- 호스트: client 2 핸드셰이크가 `sessionConfirmed=True`까지 완료됨.
- 호스트: 3명에 대해 `PREPARE_CREATED ... participants=3 roomClients=3` 및 slot 0/1/2 snapshot 생성 성공.
- player 2(client 1): 같은 3인 plan을 `PREPARE_VALIDATED`로 수락.
- 호스트: client 2가 `ROSTER_MISMATCH_OR_MISSING_SELF`를 반환하여 `CYCLE_ABORTED_BEFORE_COMMIT` 발생. 이후 3인 회차에서도 동일 반복.
- 따라서 통신 미설치/60초 타이머/호스트 roster 생성 문제가 아니라 **세 번째 클라이언트의 로컬 원격 roster를 호스트 roster와 완전 동일 비교한 검증 규칙**이 직접 차단 원인이었음.
- 1.5.1은 서버에서만 전체 roster를 authoritative하게 검증하고, 게스트는 자신의 로컬 owner identity를 검증하도록 변경.
- COMMIT 단계에서는 PREPARE에서 이미 검증된 frozen plan을 전체 roster로 다시 재판정하지 않도록 변경해, 한 클라이언트만 뒤늦게 실패하고 나머지만 이동하는 부분 적용 위험을 줄임.
- 이 소스 수정은 정적 점검만 수행했으며, 1.5.1의 실제 C# 컴파일과 3인 게임 재시험은 아직 미검증.
