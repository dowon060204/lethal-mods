# PositionCycle 1.4.0

- Native ShipTeleporter buildup: 3s spin + 3s beam marker before each 60s boundary.
- Uses PlayerControllerB.DropAllHeldItemsAndSync with the exact five transform arguments used by the live game teleporter path.
- Destinations are still captured at the 60s boundary, then rotated 1→2→...→1.
- Protocol 5; every connected room member must run the same build.

# 변경 내역

## 1.4.0 — 60초 주기 수정

- 사용자 제공 1.2.0 호스트/게스트 로그에서 API 검사, 네트워크 등록, 세션/모드 핸드셰이크가 정상 완료된 것을 확인.
- 호스트 로그의 `interval=3600s`, `firstBoundary=3602.700` 때문에 테스트 동안 `CYCLE`이 한 번도 실행되지 않은 직접 원인을 확인.
- 순간이동 주기를 **60초**로 변경.
- 호스트 혼자 있을 때 타이머가 선행하지 않도록 **모든 연결자의 호환 모드 핸드셰이크 완료 + 활성 생존 플레이어 2명 이상**을 첫 기준점 조건으로 변경.
- 이후 경계는 `origin + n × 60초`로 고정하여 처리 지연으로 주기가 밀리지 않게 유지.
- 살아 있는 `isPlayerControlled` 플레이어만 동적 N명 링으로 순환하고, 각 소유 클라이언트가 자기 캐릭터만 아이템 드롭 후 이동하는 구조 유지.
- 방에 연결된 모든 clientId가 같은 호환 모드로 Ready여야 회차를 실행하고, 누락/버전 불일치가 있으면 부분 순환하지 않음.
- protocol을 **4**로 올려 1.2.0 및 이전 빌드와 혼용을 차단.
- `build.cmd` BOM 없는 형식과 1-command 빌드 경로 유지.

## 1.1.0 — 아이템 드롭 추가본

- 이동 전에 아이템을 출발 위치에 내려놓는 동작 추가.
- 전원 드롭 후 이동, DroppedCount, 중복 Commit 방지 테스트 추가.
- 런타임 API 검사에서 과거 2인수 DropAllHeldItems 서명을 고정해 현재 게임에서 초기화 실패하는 문제가 있었음.

## 1.0.0 — 최초 소스 초안

- 호스트가 주기적으로 생존 참가자의 원래 위치를 순환하는 전원 설치 설계.
- 보호된 독립 실행 루트, 자체 메시지, 참가자/세션/버전 검증, 준비 및 적용 확인.
