# API 근거와 수정 이유 — PositionCycle 1.4.0

## 사용자 로그에서 확인한 실제 실패

두 PC 모두 PositionCycle 1.1.0 로드 직후 동일하게 다음 단계에서 중단됐습니다.

`INITIALIZATION_FAILED ... MissingMethodException: PlayerControllerB.DropAllHeldItems(Boolean,Boolean)`

따라서 1.1.0의 타이머/네트워크 코드는 실행 단계까지 도달하지 못했습니다.

## DropAllHeldItems API

Lethal Company v80 이후 계열에서 `PlayerControllerB.DropAllHeldItems`는 과거 `(bool,bool)` 바이너리 서명에서 다음 형태의 확장 서명으로 변경된 사례가 확인됩니다.

`DropAllHeldItems(bool, bool, bool, bool, Vector3, Vector3, Vector3, Vector3, Vector3)`

뒤 인수에는 optional 기본값이 있으므로 최신 어셈블리에 대해 소스의 `DropAllHeldItems(true, false)`를 다시 컴파일하면 확장 메서드에 바인딩될 수 있습니다. 문제는 1.1.0의 런타임 `RequireMethod`가 제거된 2인수 메서드를 별도로 강제 검사했다는 점입니다.

1.4.0은 `RequireMethod`를 실제 9인수 서명으로 변경했습니다. 소스는 사용자의 현재 설치 게임 DLL을 직접 참조해 빌드되므로 서명이 또 바뀌면 컴파일 또는 필수 API 검사에서 명확히 실패하게 합니다.

## TeleportPlayer

1.1.0 로그에서 `DropAllHeldItems` 검사보다 앞선 `TeleportPlayer(Vector3,bool,float,bool,bool)` 검사는 실패하지 않았습니다. 1.4.0도 같은 현재 빌드 대상 서명을 유지합니다.

## 적용 권한

1.4.0은 각 PC에서 원격 플레이어의 `DropAllHeldItems`를 호출하지 않습니다. `GameNetworkManager.localPlayerController`가 plan의 해당 clientId/NetworkObjectId와 일치하고 `IsOwner`일 때만 자기 플레이어를 드롭/이동합니다.


## 1.4.0 — supplied v81 DLL audit

이번 수정에서는 추측 대신 사용자가 제공한 실제 `Assembly-CSharp.dll`을 메타데이터/IL 수준에서 직접 검사했습니다. `ShipTeleporter.beamUpPlayer`의 두 3초 대기, `beamUpParticle`, `SetPlayerTeleporterId(1/-1)`, 로컬 플레이어 분기의 `DropAllHeldItemsAndSync(...)`, `TeleportPlayer(...)` 순서를 확인했습니다. 상세 해시와 확인 항목은 `ACTUAL_GAME_DLL_AUDIT.md`에 기록했습니다.
