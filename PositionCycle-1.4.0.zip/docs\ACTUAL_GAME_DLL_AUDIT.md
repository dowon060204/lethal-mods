# Actual game DLL audit — PositionCycle 1.4.0

Source of truth for this revision: the user's uploaded Lethal Company v81 managed assemblies.

- `Assembly-CSharp.dll` SHA-256: `5f7db5538b78dc408845a3002907619785ac9f9c6b6059d13dc9a602d9b65731`
- `Assembly-CSharp.dll` MVID: `aca1e98d-6f84-4d3f-85cd-22b6f7be2f9b`
- `Unity.Netcode.Runtime.dll` SHA-256: `dd5313b862c66f048139ff8e459d681bee2861c8b39c8dd50cc4d7851b4c32a2`
- `UnityEngine.CoreModule.dll` SHA-256: `80d43e5f8d52964e3ec0ac514076c3e2ee032af8d9c0c3ef511dfdd9067eee8e`

## Verified ShipTeleporter API

Metadata/IL inspection of the supplied `Assembly-CSharp.dll` confirms these relevant members:

- `ShipTeleporter.PressTeleportButtonServerRpc()`
- `ShipTeleporter.PressTeleportButtonClientRpc()`
- private `ShipTeleporter.PressButtonEffects()`
- private coroutine `ShipTeleporter.beamUpPlayer()`
- private `ShipTeleporter.SetPlayerTeleporterId(PlayerControllerB,int)`
- `ShipTeleporter.teleporterSpinSFX : AudioClip`
- `ShipTeleporter.teleporterBeamUpSFX : AudioClip`
- `ShipTeleporter.beamUpPlayerBodySFX : AudioClip`
- `ShipTeleporter.shipTeleporterAudio : AudioSource`

The regular teleporter's `beamUpPlayer` state machine contains two `WaitForSeconds(3.0f)` waits. The observed relevant sequence is:

1. play the teleporter spin SFX;
2. wait 3 seconds;
3. set the target player's ship teleporter id to `1`;
4. play `PlayerControllerB.beamUpParticle` and the teleporter body SFX;
5. wait another 3 seconds;
6. for the local player branch, call `DropAllHeldItemsAndSync(...)`;
7. set elevator/hangar/factory state, zero `averageVelocity` and `velocityLastFrame`;
8. call `PlayerControllerB.TeleportPlayer(...)`;
9. reset the player's ship teleporter id to `-1` and play the beam SFX again.

## Verified PlayerControllerB signatures

- `TeleportPlayer(Vector3, bool, float, bool, bool) : void`
- `DropAllHeldItems(bool, bool, bool, bool, Vector3, Vector3, Vector3, Vector3, Vector3) : void`
- `DropAllHeldItemsAndSync(Vector3, Vector3, Vector3, Vector3, Vector3) : void`
- `DropAllHeldItemsRpc(Vector3, Vector3, Vector3, Vector3, Vector3, bool, bool) : void`

The normal teleporter passes the local player's transform position, local item holder position/rotation, and player eye position/rotation into `DropAllHeldItemsAndSync`. PositionCycle 1.4.0 now uses the same call for the local owner instead of manually emulating the inventory RPC.

## Adaptation required for PositionCycle

The vanilla regular teleporter's final destination is its fixed `teleporterPosition`, so its coroutine cannot be invoked unchanged for a cyclic player-to-player swap. PositionCycle therefore reuses the verified native buildup pieces and native item-drop/sync call, while substituting only the final destination with the next active player's position captured at the 60-second boundary.

If a regular `ShipTeleporter` object exists in the current scene, its original button/animator/audio fields are used for the buildup. If no regular teleporter object is instantiated (for example, it has not been purchased), each player's built-in `beamUpParticle` is still used; teleporter-object-specific audio/animator effects cannot be sourced from a nonexistent scene object.

This audit is metadata/IL inspection, not an in-game multiplayer test.

### Remote-player buildup visibility

Vanilla `PressTeleportButtonClientRpc` starts `beamUpPlayer` on every client, so the targeted player's particle/audio is instantiated locally on each peer rather than relying on a networked ParticleSystem state. PositionCycle mirrors this: each telegraph makes every peer play the built-in beam-up particle on every currently active rotation participant. Dead spectators still run the visual telegraph for living participants.
