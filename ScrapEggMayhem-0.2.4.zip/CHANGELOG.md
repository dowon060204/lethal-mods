# Changelog

## 0.2.4

- 실제 게스트 로그에서 ownership이 정상인데도 `enabled=False`, `shopKeys=0`, `waiting-for-shop-catalog`로 투척이 차단되는 원인을 반영했습니다.
- `CatalogReady`를 항목 수와 분리해 준비된 0개 상점 목록도 유효하게 처리합니다.
- inactive live Terminal까지 찾는 catalog resolver와 guest local fallback을 추가했습니다.
- 네트워크 프로토콜 3, `BuildTag`, top-level enabled/catalog integer flags를 추가해 같은 버전 문자열의 stale/mismatched 빌드와 nested gate 불일치를 구분합니다.
- 새 세션에서 catalog를 초기화하고, 최신 disabled rules와 native result가 모순되면 즉시 rules resync를 요청합니다.
- 빌드 전에 프로젝트 bin/obj를 삭제해 이전 DLL 캐시를 재사용하지 않도록 했습니다.
- 원본 이스터에그 IL 복제와 0.2.3의 제한적 ownership 복구는 유지합니다.

# 변경 이력

## 0.2.3 — 게스트 투척 소유권 경로 수정 (소스 수정, 게임 미검증)

- 호스트는 투척되지만 게스트는 투척되지 않는 경로를 원본 `Assembly-CSharp.dll`과 대조했습니다.
- 원본 `GrabbableObject.UseItemOnClient`와 `StunGrenadeItem.ItemActivate`에는 모두 `NetworkBehaviour.IsOwner` 게이트가 있습니다.
- 반면 실제 투척은 로컬 플레이어의 `PlayerControllerB.DiscardHeldObject -> ThrowObjectServerRpc`를 사용하며, 이 ServerRpc는 플레이어 객체 소유권을 검사합니다.
- 로컬 플레이어가 실제로 들고 있는 아이템인데 prop `NetworkObject` 소유권이 아직 로컬로 동기화되지 않은 경우, 게임 원본 `GrabbableObject.ChangeOwnershipOfProp(actualClientId)`을 요청해 소유권을 복구합니다.
- 같은 동기화 지연 프레임에서 좌클릭이 사라지지 않도록, 복사한 두 원본 메서드의 `IsOwner` 판정만 `item.IsOwner || 정확한 로컬 홀더`로 연결합니다. 이 우회는 `playerHeldBy`, `currentlyHeldObjectServer`, 로컬 `PlayerControllerB.IsOwner`, spawned NetworkObject를 모두 확인합니다.
- 직접 `NetworkObject.ChangeOwnership`을 호출하거나 임의의 새 throw RPC를 만들지 않습니다. 실제 드롭/투척은 여전히 게임의 `DiscardHeldObject`/`ThrowObjectServerRpc` 경로입니다.
- 상점 아이템 제외, 기존 좌클릭 아이템 보존, 호스트 판정/폭발 결과 동기화, 원본 이스터에그 확률/궤적/폭발 코드는 유지합니다.
- 원본 IL 정적 검사: 15개 메서드, 28개 상태 필드, 2309개 assertion 통과. C# 컴파일/Unity/실제 멀티플레이는 이 환경에서 미검증입니다.

# Changelog

## 0.2.2 — 마지막 입장자 로컬 비활성 고정 수정 (소스 수정, 게임 미검증)

- 호스트 `Enabled` 설정과 일시적인 전체-peer 핸드셰이크 준비 상태를 분리했습니다. 새 참가자 접속 중 `enabled=false` 규칙이 배포되어 마지막 게스트 입력이 비활성 상태로 남을 수 있던 경로를 제거했습니다.
- 호스트/기존 호환 참가자의 기능을 새 참가자 한 명의 미완료 핸드셰이크가 전역으로 끄지 않습니다. 호스트는 각 송신자의 호환성을 `peers.Contains(sender)`로 계속 검증합니다.
- 게스트 hello 전송에서 HUD/로컬 플레이어/라운드 객체 준비 조건을 제거했습니다. 연결된 전송 계층과 원본 이스터에그 에셋만 준비되면 호스트 규칙을 요청합니다.
- 게스트가 다른 원격 참가자의 연결 해제 콜백을 받았다는 이유만으로 자기 네트워크 바인딩을 재생성하지 않습니다. 자기 `boundClientId`가 끊긴 경우에만 재바인딩합니다.
- 규칙 적용 시 `enabled`, 상점 키 개수, epoch, 원본 데이터 일치 여부를 한 번의 상태 로그로 남깁니다.
- 원본 이스터에그 IL/확률/투척/폭발 처리 및 상점/좌클릭 예외 규칙은 변경하지 않았습니다.

# 변경 이력

## 0.2.1 — 객체 생존과 게스트 통신 복구 (소스 수정, 게임 미검증)

- Awake 초기에 기존 비트를 보존하는 일회성 HideAndDontSave 보호. BepInEx 기본 DDOL을 확인하고 플래그 변경 시 루트에서 재확인. BepInEx.cfg 수정 없음.
- 임시 OnDisable와 실제 OnDestroy/종료를 분리. 초기화 재진입/중복 플러그인/구독 정리 가드 추가. 자기 Harmony 패치만 정리하고 설치 캐시도 제거.
- 게스트 IsConnectedClient 확인, NetworkManager/CustomMessagingManager/역할 교체 재연결, 이전 인스턴스에서 구독 해제.
- 일시 네트워크 예외를 영구 native failure와 분리하고 로그/재시도 추가.
- 호환성 응답 직후 rules/epoch 전송 및 결과 순서 보호. 아직 생성되지 않은 객체의 유효 메시지 보관, 제한된 만료/재시도.
- 짧은 로딩 정지가 peer 호환성을 만료시키던 고정 시간 lease 제거. 새 참가자/불일치 참가자에 대한 안전 대기 방침 유지.
- 원본 Use/ItemActivate의 IsOwner·쿨다운과 원본 달걀 처리 함수는 유지. 진단용 입력 관찰만 추가.
- 실제 어셈블리/객체/첫 Update/장면/생명주기/네트워크/입력 단계 로그 추가.
- 기존 설정 이름과 기본값, BepInExPack/Harmony 의존성, 아이콘/라이선스 유지.
- 실제 C# 테스트 30개 작성(이 환경에서는 미실행), 원본 IL 및 소스 정적 검사 실행. 새 DLL은 컴파일하지 못해 제공하지 않음.

---

# 변경 이력

## 0.2.0 — 원본 코드 재사용 소스 수정본

- 제공된 `Assembly-CSharp.dll`의 이스터에그 관련 코드를 분석하고 원본 메서드 15개/전용 필드 28개를 기준으로 연결부 작성.
- 런타임에 원본 CIL 명령 복사. 추첨·투척 Raycast·낙하 보간·충돌 대기·폭발 예외·피해·아이템 파괴를 별도 수식으로 재구현하지 않음.
- 실제 이스터에그 프리팹에서 확률 필드·세 가지 낙하 곡선·소리·효과·입력 설정 읽기.
- 장착 시 시드 기반 결과 결정 및 `gotExplodeOnThrowRPC` / `hasCollided` 처리 유지.
- 회사 판매대 예외 유지. 별도 호스트 Despawn 제거.
- 상점 종류 제외, 기존 좌클릭 보존, 기본 사용 경로 유지.
- 네트워크 객체/스크립트 교체 없이 달걀 필드와 RPC 본문 연결. 참가자 버전/프리팹 일치 검사.
- 게임 원본 함수의 해시 검사기를 빌드 단계에 추가. 구버전 수치 설정 제거.
- 검증 상태: 원본 정적 분석 및 소스 구조 검사 수행. 이 버전의 C# 컴파일·런타임 CIL 실행·게임·멀티플레이 미실시.

## 0.1.0

별도 투척 궤적과 착지 후 독립 확률 판정을 사용했던 초기 소스판. 사용자가 로컬 빌드·실기 후 원본 이스터에그와 세부 판정 차이를 보고함.
