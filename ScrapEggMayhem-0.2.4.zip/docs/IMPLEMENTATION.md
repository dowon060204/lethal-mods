# 0.2.2 보충

이번 생명주기/통신 수정은 `DIAGNOSIS_KO.md`에 있습니다. 아래 문서는 0.2.0에서 원본 달걀 처리를 연결한 설계를 설명하며 해당 복사기/원본 함수 목록은 그대로 유지했습니다. 0.2.2의 현재 검증 범위는 `TEST_PLAN_KO.md`와 README가 우선합니다.

---

# 원본 분석과 구현 경계

## 분석한 파일

사용자가 제공한 `Assembly-CSharp.dll`, 2,034,688 bytes.

```text
SHA-256: 5f7db5538b78dc408845a3002907619785ac9f9c6b6059d13dc9a602d9b65731
```

출처는 이 파일의 CLI 메타데이터와 CIL 메서드 본문입니다. 웹의 다른 버전 디컴파일 자료를 원본으로 대신하지 않았습니다. 아래 내용은 런타임 실기 관찰이 아니라 이 파일에서 확인한 동작입니다. 전체 게임 버전 번호를 추측해 붙이지 않았습니다.

## 0.1.0에서 달랐던 부분

| 항목 | 분석한 원본의 처리 | 0.2.0 변경 |
|---|---|---|
| 추첨 시점 | `EquipItem`이 결과 요청. 착지할 때 새 난수를 뽑지 않음 | 장착 훅에서 원본 Equip 명령 사용 |
| 난수와 비교 | `new Random(randomMapSeed + 10 + (int)position.x + (int)position.z).Next(0,100) <= chanceToExplode` | 서버 본문 그대로 복사. 독립 `NextDouble` 삭제 |
| 충돌 | `OnHitGround`가 투척자/충돌형/핀 상태를 확인해 `hasCollided` 기록 | 별도 fallTime/배치 성공 판정으로 대신하지 않음 |
| 결과 지연 | `Update`가 충돌 상태와 `gotExplodeOnThrowRPC`를 함께 확인 | 원본 Update의 추가 부분 사용 |
| 투척 | 12m 전방 Raycast, 막히지 않으면 전방 10m, 지면 검색 30m 및 원본 오프셋 | 원본 목적지 함수 사용 |
| 낙하 | 프리팹의 곡선 3개와 이동 거리/프레임 시간으로 계산 | 자체 포물선/클램프/고정 시간 제거 |
| 판매대 | 충돌형이며 현재 레벨이 `spawnEnemiesAndScrap == false`이고 `parentObject`가 판매대 컨테이너일 때 폭발 취소 경로 | 원본 조건문 보존 |
| 충격파 | 위치 + 위쪽 0.2, `SpawnExplosion` 인자: 효과 기본 생성 false, 0.5, 3, 40, 45, null, 0 | 옛 비치명 피해 20 및 임의 효과 경로 제거 |
| 파괴 | `DestroyObjectInHand(playerThrownBy)` 호출 | 별도 `NetworkObject.Despawn(true)` 제거 |

`chanceToExplode`의 **실제 프리팹 값은 DLL만으로 확인할 수 없습니다.** 생성자의 기본 값은 프리팹 직렬화로 덮어써질 수 있습니다. 따라서 특정 숫자를 실제 달걀 확률이라고 단정하지 않고 실행 시 프리팹 값을 읽습니다. 비교가 `<=`이고 정수 표본이므로 단순히 필드 숫자를 그대로 퍼센트 확률이라고 해석해서도 안 됩니다.

위 판정은 원본 함수의 조건 전체 안에서 실행됩니다. 예를 들어 판매대 예외를 모든 회사 구역의 폭발 금지로 확대하지 않았고, 실제로 지면 충돌이 발생하지 않는 배치 경로에 가짜 충돌을 만들지 않았습니다.

## 함수 연결

`NativeIlCopier`는 `MethodBody.GetILAsByteArray()`와 `Module.Resolve*`로 원본 명령/참조를 읽어 `DynamicMethod`로 옮깁니다. 산술·상수·분기·Unity API 호출을 다시 계산하는 C# 로직은 없습니다. 긴 분기 거리를 위해 짧은 분기 명령만 동등한 긴 형식으로 바꿉니다.

복사하는 원본은 `StunGrenadeItem`의 `ItemActivate`, `DiscardItem`, `EquipItem`, `SetControlTipForGrenade`, `FallWithCurve`, `Start`, `Update`, `OnHitGround`, `ExplodeStunGrenade`, `GetGrenadeThrowDestination`, 두 확률 RPC 본문과 `GrabbableObject`의 `UseItemOnClient`, `RequireCooldown`, `UseItemBatteries`입니다.

`StunGrenadeItem` 전용 필드 접근은 같은 이름/타입의 `EggState` 필드로 연결합니다. `ldflda`도 보존하므로 `RaycastHit`/`Ray`의 참조 접근이 값 복사로 변하지 않습니다. 공통 필드와 `transform`, `NetworkObject`, 보유 플레이어는 실제 원래 아이템을 가리킵니다.

공통 사용 함수 세 개에서 읽는 입력용 `itemProperties`와 `useCooldown`만 실제 달걀 프리팹 데이터를 사용합니다. 원래 아이템의 정의 자체를 교체하지 않으므로 원래 무게·가치·식별자·배치 높이 등은 유지합니다. 기존 좌클릭 사용 아이템에는 이 입력 경로를 적용하지 않습니다.

원래 아이템의 기본 `Start`/`Update`/충돌 처리를 중복 실행하지 않도록 복사한 달걀 함수 안의 해당 기본 호출을 생략합니다. 상속된 메서드끼리 기본 메서드를 호출할 때는 종류별 중첩 카운터로 추가 처리를 한 번만 합니다. 특수 아이템이 기본 낙하/충돌 경로를 전혀 사용하지 않으면 이 연결만으로 같은 결과가 나오는지 별도 확인이 필요합니다.

## 네트워크에서 반드시 다른 부분

원본의 두 RPC 수신기는 수신 대상을 `StunGrenadeItem`으로 캐스팅합니다. 기존 샷건/손전등 스크립트에 해당 RPC를 그대로 보내면 타입·RPC 테이블 문제가 생깁니다. 이를 피하려고 NetworkBehaviour를 추가하거나 프리팹 스크립트를 교체하지 않았습니다.

서버 RPC의 생성된 전송/실행 단계 코드를 제외한 본문은 IL offset `0xC6`에서 시작합니다. 클라이언트 결과 본문은 `0xE1`에서 시작합니다. 해당 경계 및 전체 메서드 해시는 제공된 DLL에서 검사했습니다. 전송부만 명명된 메시지로 바꾸고 두 본문은 복사합니다. 서버 RPC의 `RequireOwnership=false`도 파일의 사용자 지정 특성에서 확인했습니다. 정상 장착 중 소유권 변경을 임의의 추가 검사로 막지 않습니다.

추첨 결과만 공유하고, 각 클라이언트의 충돌/폭발 실행은 원본처럼 로컬 상태와 수신 결과가 만나도록 둡니다. 호스트가 중앙에서 별도 폭발을 판정하거나 따로 Despawn하지 않습니다. RPC 방식이 다르므로 메시지 타이밍까지 비트 단위로 동등하다고 보장하지 않습니다. 후발 참가, 지연, 연결 해제, 다른 네트워크 모드 조합의 실기 검증이 필요합니다.

## 보존하는 것과 적용하지 않는 것

원래 이스터에그 및 이미 `StunGrenadeItem`인 물건에는 중복 적용하지 않습니다. 상점 품목 제외는 종류 단위이며 실제 구매 이력이 아닙니다. 원래 좌클릭을 갖는 아이템의 사용 코드를 건너뛰지 않습니다.

달걀의 핀 없는 경로만 대상으로 프리팹을 검증합니다. 기존 수류탄의 핀 뽑기 코루틴을 다른 아이템으로 재구현하지 않습니다. 예상과 달리 핀 코루틴 경로에 들어가면 오류를 기록하고 추가 동작을 비활성화합니다.

자동 키 입력, 임의 지면 충돌 합성, 독립 난수, 사용자 지정 피해/확률, 아이템별 강제 NetworkBehaviour 교체, 게임 DLL 덮어쓰기는 없습니다.

## 검증 수준

제작 환경에서 원본 메서드 해시 15개, 전용 필드 28개, 남긴 명령의 분기 대상/평가 스택 높이와 소스 구조를 검사했습니다. 이는 C# 컴파일, CLI 타입 검증, 실제 동적 메서드 생성, Unity 프리팹 발견, 시각 효과 또는 네트워크 테스트가 아닙니다. 정확한 항목과 수치는 `VALIDATION_REPORT.json`에 있습니다.

빌드 PC에서는 `NativeAudit`가 메타데이터만 읽어 동일 메서드 해시를 확인한 뒤 모드 컴파일로 진행합니다. 해시 검사를 통과해도 런타임 복사 함수 생성 및 실행 오류가 없다는 뜻은 아닙니다. 최초 로그와 실제 플레이 결과를 확인해야 합니다.

## 참고 API 문서

아래 자료는 연결 기법/API의 설명이며 게임 판정 출처가 아닙니다.

- Microsoft DynamicMethod: https://learn.microsoft.com/en-us/dotnet/api/system.reflection.emit.dynamicmethod?view=net-8.0
- Harmony 패치와 호출 경계: https://harmony.pardeike.net/articles/patching.html
- Harmony의 원본 메서드 복사 개념 비교: https://harmony.pardeike.net/articles/reverse-patching.html
- Thunderstore 패키지 규격: https://wiki.thunderstore.io/mods/creating-a-package

이 구현은 Harmony ReversePatch 스텁이 아니라 자체의 제한된 CIL 복사기를 사용합니다. Harmony는 원래 아이템 메서드에 진입/종료/대체 훅을 연결하는 역할입니다.
