# 0.2.4 게스트 로그 기반 수정

## 실제 0.2.3 게스트 로그에서 확인된 상태

제공된 게스트 `LogOutput (1).log`에서는 다음이 동시에 확인됐다.

- `Rules applied; guest=1; enabled=False; shopKeys=0; ... nativeMatch=True`
- `state=waiting-for-shop-catalog`
- 좌클릭 시 `playerIsOwner=True`, `itemIsOwner=True`, `localHolderAuthority=True`
- 같은 좌클릭 로그에서 `throwEligible=False`
- 이후 `Pending native result expired ...`가 기록됨

따라서 이 재현에서 게스트 투척 실패의 직접 원인은 **아이템 NetworkObject ownership이 아니다.** 게스트는 이미 아이템과 플레이어 모두 정상 소유 상태였다. 입력도 `UseItemOnClient`까지 도달했다. 하지만 세션이 `waiting-for-shop-catalog`에 머물렀고 호스트 규칙도 `enabled=False`로 수신되어 `Patches.Eligible()`가 원본 이스터에그 경로를 실행하지 않았다.

## 0.2.3 코드에서 확인된 두 문제

### 1. 상점 목록의 “비어 있음”과 “아직 모름”을 같은 상태로 취급

0.2.3 `ItemPolicy.HasCatalog`는 `shop.Count != 0`이었다. 따라서 네트워크에서 `shopKeys=0`을 받으면 그 값이 실제로 빈 상점 목록인지, 터미널이 아직 준비되지 않아 목록을 못 읽은 것인지 구분할 수 없었다. 이후 게스트는 계속 `waiting-for-shop-catalog`가 되어 모든 대상 아이템을 거부했다.

### 2. 핵심 전역 게이트가 중첩 Rules bool 하나에 의존

0.2.3은 `Rules.enabled` 하나를 중첩 JSON 객체 안에서 전달했다. 제공 로그에서는 호스트가 같은 epoch에서 `enabled=False` 규칙을 반복 전송했다. 게스트 로그만으로 호스트의 실제 `ConfigEntry<bool>` 값인지, 같은 버전 문자열을 가진 오래된 빌드/직렬화 상태인지까지 단정할 수는 없다. 따라서 0.2.4는 같은 버전 문자열만으로 호환성을 인정하지 않고, 프로토콜과 build tag를 함께 검사한다.

## 0.2.4 수정

1. 네트워크 프로토콜을 3으로 올리고 채널도 `native-v3`로 분리했다.
2. `Plugin.BuildTag = rules-v3-catalog-ready-20260918`을 추가했다. 버전이 같아도 다른 소스 빌드는 handshake에서 거부한다.
3. `Enabled`와 `catalogReady`를 `Rules` 안의 bool만 믿지 않고 **top-level integer flag**로 중복 전송한다. 게스트는 protocol 3에서 이 top-level 값을 실제 게이트 값으로 사용하고 nested 값도 로그에 함께 남긴다.
4. 상점 목록은 `CatalogReady`와 `shop.Count`를 분리했다. **ready=true + 0개**는 정상적인 빈 상점 목록으로 처리한다.
5. `FindObjectOfType<Terminal>()`가 아직 비활성화된 ship Terminal을 놓칠 수 있으므로, 실패 시 `Resources.FindObjectsOfTypeAll<Terminal>()`에서 **현재 로드된 scene에 속하는 Terminal만** 찾는다.
6. 게스트는 호스트 rules를 먼저 받아도 로컬 Terminal이 준비되는 즉시 정확한 `buyableItemsList`를 다시 읽는다. 호스트가 아직 catalog-ready가 아니라고 보낸 빈 목록으로 이미 찾은 로컬 목록을 지우지 않는다.
7. 새 네트워크 세션에서는 catalog를 명시적으로 초기화해 이전 로비 목록이 다음 로비에 섞이지 않게 했다.
8. 호스트에서 `configuredEnabled`, top-level enabled flag, catalogReady, shop key 수를 상태가 바뀔 때만 기록한다. 게스트에서는 top-level/nested enabled와 catalog 상태를 한 줄로 비교할 수 있다.
9. 최신 rules가 disabled인데 같은 host/epoch에서 native result가 오면 ownership 문제로 오판하지 않고 불일치 경고를 남기고 즉시 rules resync를 요청한다.
10. build.ps1은 컴파일 전에 `src/bin`, `src/obj`, 테스트/감사 도구의 bin/obj를 삭제해 이전 빌드 산출물을 재사용하지 않는다.

## 유지한 동작

- 상점 판매 품목 제외
- 일반 대상 아이템 좌클릭 투척
- 샷건/레이저 포인터 등 기존 좌클릭 기능이 있는 아이템은 좌클릭 유지
- 내려놓기 쪽 원본 이스터에그 처리
- 원본 이스터에그의 투척 목적지, 낙하, 충돌, 폭발 확률/피해/효과 코드 재사용
- 호스트 판정 및 결과 전달 구조
- 0.2.3의 제한적 소유권 복구 경로

## 다음 테스트에서 정상으로 기대하는 로그

호스트:

```text
[lifetime] Plugin=0.2.4; buildTag=rules-v3-catalog-ready-20260918; ...
[net] Host rules snapshot; configuredEnabled=True; enabled=1; catalogReady=1; shopKeys=...;
```

게스트:

```text
[lifetime] Plugin=0.2.4; buildTag=rules-v3-catalog-ready-20260918; ...
[net] Rules applied; ... enabled=True; topEnabled=1; ... localCatalogReady=True; ...
[net] role=guest/...; state=ready; ...
[input] Game UseItemOnClient reached; ... throwEligible=True
[input] Native UseItemOnClient returned; ...
```

`shopKeys=0` 자체는 더 이상 실패 조건이 아니다. 중요한 것은 `catalogReady=True`다.

## 검증 한계

현재 작업 환경에는 .NET SDK와 게임의 Unity/Netcode/BepInEx 참조 DLL 전체가 없으므로 0.2.4를 실제 C# 컴파일하지 못했다. 따라서 이 문서의 “수정됨”은 소스 변경과 정적 점검을 의미하며 실제 게임/멀티플레이 성공을 의미하지 않는다.
