# 0.2.2 마지막 입장자 비활성 문제 분석

## 관찰된 증상

마지막으로 들어온 플레이어만 자기 아이템의 새 좌클릭 투척/폭발이 작동하지 않지만, 다른 참가자의 투척 결과와 폭발은 수신하고 아이템도 주울 수 있다는 보고를 기준으로 점검했습니다. 이는 전체 수신 통신이 끊긴 증상과는 다릅니다.

## 소스에서 확인한 위험 경로

0.2.1 `Session.PublishRules()`는 `Settings.Snapshot(catalog, ready)`를 호출했고, `Settings.Snapshot`은 `Rules.enabled = configuredEnabled && ready`로 직렬화했습니다. 여기서 `ready`는 **현재 연결된 모든 원격 클라이언트가 호환 hello를 보냈는가**까지 포함했습니다. 즉 새 참가자가 접속하는 순간의 일시적인 핸드셰이크 상태를 영속적인 호스트 설정인 `Rules.enabled`와 같은 필드에 넣었습니다.

클라이언트의 `Patches.Eligible()`는 `Session.Active`를 요구하고, `Session.Active`는 `current.enabled`가 false이면 새 투척/이스터에그 동작을 적용하지 않습니다. 반면 이미 호스트가 보낸 `result`는 `CanExecuteNative` 경로로 적용될 수 있으므로, **자기 투척은 막혀 있는데 다른 사람의 폭발은 보이는** 상태가 코드상 가능합니다.

또한 0.2.1 게스트는 hello를 보내기 전에 `WorldReady`(StartOfRound, RoundManager, local player, HUD)까지 요구했습니다. 늦게 들어오는 플레이어의 로컬 객체 준비가 지연되면 규칙 요청 자체가 늦어질 수 있습니다. 네트워크 핸드셰이크에는 이 객체들이 필요하지 않습니다.

`OnDisconnected`는 게스트에서 어떤 원격 ID가 끊겨도 `!boundServer` 조건 때문에 자기 세션 전체 재바인딩을 요청했습니다. 이는 다른 플레이어의 출입이 게스트 자신의 규칙/epoch 상태를 불필요하게 초기화할 수 있는 경로였습니다.

## 0.2.2 수정

1. `Rules.enabled`에는 호스트의 실제 `General.Enabled` 설정만 넣습니다. transient readiness는 직렬화하지 않습니다.
2. 호스트의 `Session.Active`는 새 참가자 한 명의 hello 미완료로 전역 중단되지 않습니다. 서버는 여전히 `roll` 요청을 `peers.Contains(sender)`로 개별 검증합니다.
3. 게스트 hello는 연결된 전송과 원본 에셋이 준비되면 전송합니다. HUD/플레이어/라운드 객체는 실제 게임 동작 실행 단계에서만 `WorldReady`로 검사합니다.
4. 게스트는 자기 client ID가 끊긴 경우에만 세션 재바인딩을 요청합니다. 다른 참가자의 퇴장은 peer 상태만 갱신합니다.
5. 규칙 수신 로그를 추가해 마지막 참가자에서 `enabled=true`, `shopKeys>0`, `nativeMatch=true`, `state=ready`가 되는지 확인할 수 있습니다.

## 변경하지 않은 부분

- 원본 `StunGrenadeItem` 함수 본문 복사/브리지
- 원본 맵 시드/좌표 기반 폭발 판정
- 원본 투척 목적지, 낙하 곡선, 충돌·폭발 피해/효과
- 상점 품목 제외
- 샷건/레이저 포인터 등 기존 좌클릭 기능 보존
- 원본 `GrabbableObject.UseItemOnClient`의 `IsOwner` 검사

마지막 항목 때문에 0.2.2에서도 로그에 `itemIsOwner=false`가 반복된다면 그것은 별도의 소유권 문제입니다. 이번 수정은 소유권을 강제로 빼앗거나 원본 검사를 우회하지 않습니다.

## 검증 상태

이 환경에서는 .NET SDK 및 Unity/BepInEx 전체 참조가 없어 C# 컴파일과 게임/멀티플레이 실행을 수행하지 못했습니다. 소스 구조 검사는 별도로 수행합니다.
