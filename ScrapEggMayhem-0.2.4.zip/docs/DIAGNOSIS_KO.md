# 0.2.1 원인 분석과 수정 근거

## 입력 자료와 판정 수준

대상 소스: 대화에 첨부된 `ScrapEggMayhem-0.2.0-source.zip` 전체. 원본 게임: 사용자가 제공한 `Assembly-CSharp.dll` (2,034,688 bytes, SHA-256은 README 참고).
이번 요청에서 호스트·게스트의 실제 재현 로그나 해당 PC의 BetterSpectate DLL은 제공되지 않았습니다. 따라서 아래의 **소스에서 확인된 경로**와 **사용자 실행에서 직접 관찰한 원인**을 구분합니다. 전자는 분석했고 후자는 아직 로그/실기로 확인하지 못했습니다.

## 1. BetterSpectate가 영향을 줄 수 있는 구체적인 경로

BepInEx 5.4.21의 `BepInEx/Bootstrap/Chainloader.cs`, `Start()`는 `BepInEx_Manager` GameObject를 생성하고, 그 객체에 `DontDestroyOnLoad`를 적용합니다. 플러그인을 붙일 때도 같은 `ManagerObject.AddComponent(...)`를 사용합니다. `HideManagerGameObject` 설정이 true일 때만 별도로 `HideAndDontSave`를 지정합니다. 즉, **DontDestroyOnLoad가 빠져 있어서 생긴 문제라고 설명할 근거는 없습니다.**

Thunderstore에 공개된 Fusition/BetterSpectate v1.0.0의 `BetterSpectateBase.Awake()`는 자기 `gameObject.hideFlags`에 `(HideFlags)61`을 지정합니다. 이 GameObject는 위 로딩 구조에서 다른 플러그인도 붙어 있는 공용 객체입니다. 따라서 BetterSpectate를 추가하면 그 객체에 있는 이 모드의 실행 환경도 바뀔 수 있다는 경로는 확인됩니다. 확인한 버전은 공개 배포 v1.0.0이며 사용자가 실제로 실행한 BetterSpectate 파일과 동일하다고 단정하지 않습니다.

0.2.0 `src/Plugin.cs`는 별도 런타임이 아닌 `BaseUnityPlugin` 자체의 `Update()`에 에셋 검색과 세션 처리를 의존합니다. 보호 플래그 처리는 없고, `OnDestroy()`에서 세션 해제/자기 Harmony 패치 해제/상태 제거를 수행합니다. 공용 객체가 제거되면 반복 실행이 끊기고 패치도 해제되는 구조입니다. 하지만 **사용자 실행에서 OnDestroy가 어느 순간 실행됐는지, 어떤 게임/모드 코드가 실제로 제거했는지는 확인되지 않았습니다.** BetterSpectate의 존재와 기능 성공이라는 A/B 결과만으로 그 호출자를 만들어 내지는 않았습니다.

### 수정

`src/Plugin.cs: Awake()` → `src/LifetimeDiagnostics.cs: ProtectEarly()`가 로거와 재진입 방지 상태를 만든 직후, 네이티브 IL 어댑터/설정/통신 초기화보다 앞서 필요한 플래그를 적용합니다. 현재 비트에 `HideAndDontSave`를 OR하므로 다른 비트를 덮어쓰지 않습니다. 이미 보호되어 있으면 변경하지 않으며, 매 프레임 재설정하지 않습니다. 플래그를 실제로 변경한 경우에 한해 루트 객체에 DDOL을 재확인합니다. BepInEx가 원래 DDOL을 적용했다는 사실은 코드 주석과 로그 안내에 명시했습니다.

Unity 문서상 관련 hideFlags 변경은 `OnDisable`/`OnEnable`을 다시 부를 수 있으므로, 아직 Awake 중인 경우를 로그와 가드로 구분합니다. OnEnable에서 본체를 중복 초기화하거나 다시 패치하지 않습니다. 임시 비활성화는 관찰 상태만 정리하고 실제 패치·통신 자원은 보존합니다. OnDestroy/OnApplicationQuit에서는 종료 여부를 기록하고 정리를 한 번만 수행합니다. 게임 종료 중 재생성/무한 재시도는 없습니다.

공용 객체의 플래그 변경이 다른 플러그인에도 영향을 준다는 점은 숨기지 않습니다. 기존 구조에서 더 작은 수정으로 직접 보호가 가능하므로 별도 GameObject/로더/코루틴을 새로 만들지 않았습니다. BetterSpectate 관전 기능은 가져오지 않았고, 해당 DLL 호출/의존성도 없습니다. BepInEx 설정 파일은 진단 목적으로 읽기만 합니다.

## 2. 멀티플레이 소스에서 확인된 별도 결함

| 기존 위치 | 확인된 경로 | 0.2.1 수정 |
|---|---|---|
| `Plugin.Update` / `Fault` | 에셋/통신을 한 try 안에 넣고 예외를 영구 `Healthy=false`로 바꿈 | 일시 통신 오류는 스택 로그·1초 backoff·바인딩 재시도. 실제 원본 코드 불일치는 여전히 중단 |
| `Session.Tick` | `IsListening`만으로 게스트 통신 시작. 연결 승인·동기화 완료 확인 없음 | `HandshakeState.CanBind`가 게스트의 `IsConnectedClient`까지 확인 |
| `Session.Tick` / `Dispose` | NetworkManager 참조 변경만 확인. 같은 매니저 안의 CustomMessagingManager 교체/역할 변경 미감지 | 매니저·메시징·역할·클라이언트 ID를 비교해 재바인딩. 이전 객체에서 구독 해제 |
| `Session.Receive(hello)` | 호환된 참가자 등록 후 rules 송신을 다음 Update로 미룸. 그 사이 결과가 먼저 나갈 수 있음 | 같은 수신 경로에서 rules 송신, 실제 송신된 epoch가 있는 대상에게만 결과 송신. 실패 결과는 보관 |
| `Session.Receive(result/roll)` | 전역 Active가 잠깐 false이면 유효한 요청/결과까지 버림 | 정상 송신자·버전·세션을 확인한 이미 진행 중인 메시지를 별도로 처리 |
| `Session.TryItem` 경로 | 아이템이 아직 로컬 SpawnManager에 없으면 결과를 버림 | 제한된 보관 큐에서 준비 후 처리. 세션 변경/시간 초과 시 원인을 기록하고 폐기 |
| `Session.Active` | 호스트 12초, 게스트 8초 고정 시간 유효기간으로 로딩 정지가 호환성 상실처럼 작용 | 호환성 확인을 실제 연결 수명에 연결. 재접속/버전·데이터 불일치/세션 교체 때 초기화 |
| `Patches.installed` | UnpatchSelf 후 정적 설치 캐시가 남아 재초기화 시 패치를 건너뛸 수 있음 | 자기 소유 패치 정리 시 설치 캐시도 정리 |

새 참가자의 모드 확인이 끝나기 전에는 새 입력을 잠깐 멈추는 기존 안전 방침을 유지했습니다. 다른 버전이나 미설치 참가자를 억지로 호환 처리하지 않습니다. 따라서 실제 미설치/혼합 버전 상태에서 계속 기다리는 것은 수정 실패와 별도로 구분해야 합니다. 새 로그는 대기 중인 peer와 원본 데이터 불일치를 표시합니다.

연결 확인과 메시지 처리는 호스트와 게스트 모두 같은 플러그인의 Update에서 실행됩니다. 메인 메뉴에서 없는 플레이어/HUD/라운드를 치명적 실패로 처리하지 않습니다. 프리팹 검색은 새 StartOfRound가 생성되면 해당 로비의 자료로 다시 연결합니다. 정리 과정에서는 이전 로비의 원본 달걀 상태/보관 메시지/구독을 제거합니다.

보관 큐는 종류별 최대 512개, 최대 12초로 제한했습니다. 같은 객체의 아직 적용하지 않은 결과는 최신 값만 보관합니다. 재전송할 때 이미 받은 결과를 사용하며 새 난수를 만들어 대체하지 않습니다. 실제 Netcode 송신 자체가 성공한 후의 도착은 원래 사용하던 ReliableFragmentedSequenced에 맡깁니다. 이 변경은 v2 Packet의 필드나 새 투척 RPC를 추가하지 않습니다. 아주 긴 지연, 로비 교체 중 투척, 새로운 참가자에게 이미 바닥에 놓인 과거 물체 상태를 복원하는 모든 경우까지 검증한 것은 아닙니다.

## 3. 게스트 소유권 경로를 확인하고 유지한 이유

제공된 게임 DLL의 `PlayerControllerB.GrabObjectServerRpc`에는 IL offset `0x18A`의 `NetworkObject.ChangeOwnership(actualClientId)` 호출이 있습니다. 따라서 모든 아이템의 소유권이 영구적으로 호스트에만 있다고 가정할 수 없습니다.

또한 원본 `GrabbableObject.UseItemOnClient`의 시작 부분과 `StunGrenadeItem.ItemActivate`의 `0x42`에는 실제 `IsOwner` 검사가 있습니다. 복사 대상 함수와 이 검사를 수정하지 않았습니다. 원본의 쿨다운/입력 의미를 보존하기 위해 가짜 소유권을 반환하거나 지연된 클릭을 임의로 재생하거나 새 강제 투척 RPC를 넣지 않았습니다.

`src/NativeInput.cs`는 기존 게임 입력 훅에서 진짜 로컬 플레이어/아이템 소유권/준비 상태를 로그로 관찰하고 원본 Use 함수에 그대로 연결합니다. 별도의 키 바인딩이나 입력 코루틴은 없습니다. 실제 게스트 로그가 여전히 `itemIsOwner=false`를 보인다면 이번에 수정한 객체 생존/통신 준비와 별개로 해당 실행의 소유권 전파를 추가 분석해야 합니다. 그 결과를 이번에 확인했다고 주장하지 않습니다.

## 4. 변경하지 않은 코드

`NativeEgg.cs`, `NativeIlCopier.cs`, `NativeManifest.cs`, `EggState.cs`, `Rules.cs`, `native-methods.json`, 라이선스, 아이콘은 0.2.0과 동일합니다. `BASELINE_HASHES.json`으로 비교했습니다. 실제 달걀 프리팹 값 사용, 기존 아이템 클래스 유지, 상점 종류 제외, 기존 좌클릭 상호작용 보존도 유지합니다. 원본 게임 DLL은 읽었으며 수정/재배포하지 않습니다.

## 5. 근거 자료

소스 분석 날짜: 2026-09-17 (한국 시간).

- BepInEx 5.4.21 Chainloader: https://raw.githubusercontent.com/BepInEx/BepInEx/v5.4.21/BepInEx/Bootstrap/Chainloader.cs — Start의 manager 생성/조건부 플래그/DDOL/플러그인 AddComponent, ConfigHideBepInExGOs.
- 공개 BetterSpectate v1.0.0: https://old.thunderstore.io/c/lethal-company/p/Fusition/BetterSpectate/source/ — BetterSpectateBase.Awake의 hideFlags 지정. 관전 게임 기능을 복제하는 용도로 사용하지 않음.
- Unity 2022.3 HideFlags: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/HideFlags.html — 플래그 변경과 생명주기 콜백 영향.
- Netcode 1.7 IsConnectedClient: https://docs.unity3d.com/Packages/com.unity.netcode.gameobjects@1.7/api/Unity.Netcode.NetworkManager.IsConnectedClient.html — 연결·승인·동기화 완료 의미.
- Netcode 1.7 NetworkManager: https://docs.unity3d.com/Packages/com.unity.netcode.gameobjects@1.7/api/Unity.Netcode.NetworkManager.html — 연결/해제 이벤트와 매니저 API.

이 자료는 API/타 모드의 공개 코드 근거입니다. 사용자의 실제 실행 로그나 실기 테스트를 대신하지 않습니다.
