# 로그로 구분해야 할 단계

`BepInEx/LogOutput.log`의 해당 실행 전체를 확인합니다. 다른 사람의 로그도 같은 재현 실행과 연결 역할이 확인되어야 합니다. `General.DebugLogging`은 선택적인 추가 관찰용이며 켜야만 기능이 살아나는 설정이 아닙니다.

| 로그 | 확인되는 사실 | 이 로그만으로 확인되지 않는 것 |
|---|---|---|
| `[lifetime] Plugin=0.2.2; actual assembly=...; file=...` | 실제 로드 파일, 어셈블리 버전/MVID | 게임 기능 실행 |
| `HideManagerGameObject=...` | 실행 시 읽힌 BepInEx 값 또는 파일 관찰값. 읽기 실패/기본값 불명도 표시 | 직접 호출자나 파괴 원인 |
| `Protecting shared plugin object once` | 이번 Awake에서 플래그 변경 경로 실행 | 이후 생존 보장 |
| `Existing protection already present` | 진입 시 이미 필요한 비트가 있음 | 누가 먼저 바꿨는지, BetterSpectate 없이 재현됐는지 |
| `Initialization completed` | 어댑터/패치 등록 반환 | 첫 Update 실행, 네트워크나 투척 성공 |
| `First Update executed` | 플러그인 Update 실제 진입 | 그 후 모든 프레임·라운드 유지 |
| `Update still executing after startup` | 초기 시점 이후 반복 실행 관찰 | 미래 장면/라운드 생존 |
| `OnDisable` / `OnEnable` | 임시 활성 상태 변화. initializing=true면 초기 플래그 변경 중일 수 있음 | 실제 파괴 |
| `OnDestroy` / `OnApplicationQuit` | 실제 파괴/종료 콜백. quitting 값으로 구분 | 파괴를 호출한 외부 코드의 정확한 이름 |
| `[net] Bound role=...` | 연결이 준비된 매니저/메시징에 구독 연결 | 상대 모드 호환 또는 투척 성공 |
| `Compatible hello accepted` | 해당 peer의 버전/프리팹 자료 일치 | 그 사람의 입력 실행 |
| `Host epoch received` | 게스트가 호스트 세션 정보를 받음 | 아이템 결과/투척 확인 |
| `state=ready` | 코드가 판단한 현재 준비 조건 충족 | 멀티 실기 통과 |
| `peer-state=awaiting-compatible-hello:...` | 아직 호환 hello가 없는 참가자 식별자 | 0.2.2에서는 이 상태가 이미 호환된 참가자의 Enabled를 끄지 않음 |
| `host-native-data-mismatch` 또는 version mismatch | 원본 프리팹 자료/버전 불일치 | 강제 호환해도 안전하다는 의미 아님 |
| `[input] Game UseItemOnClient reached` | 실제 로컬 입력 경로 진입, 소유권·대상·준비 상태 관찰 | 실제 손에서 떠났는지/폭발했는지 |
| `Native UseItemOnClient returned` (최초 1회, 이후 Debug) | 원본 사용 함수가 반환했고 반환 시 held/owner 상태를 읽음 | 자동 판정한 게임 테스트 결과 아님 |
| `Native result object=...` (Debug) | 원본 추첨 본문에서 결과가 나옴 | 실제 충돌·소리·피해 동기화 |

같은 로그의 반복된 예외는 키별 10초 간격으로 제한하며, 기록할 때 예외 타입/메시지와 스택을 함께 남깁니다. pending 메시지 만료는 종류별 최초 경고로 표시됩니다. 전체 게임에서 동일 예외가 발생하지 않았다는 증거로 로그 생략을 해석하면 안 됩니다.

핵심 구분: First Update가 없거나 OnDestroy가 먼저 나오면 생명주기 문제를 우선 봅니다. 호스트/게스트의 First Update가 모두 계속 나오는데 ready로 가지 않으면 연결/호환성 단계의 문제입니다. ready이고 게스트 입력 훅도 들어오는데 `itemIsOwner=false`이면 실제 소유권 흐름을 별도로 봅니다. throwEligible=false라면 상점 제외/원래 좌클릭 기능/설정 목록을 구분합니다. 원본 소유권과 쿨다운을 제거해 이를 숨기지 않았습니다.

| `[net] Rules applied; guest=...; enabled=True; shopKeys=...; nativeMatch=True` | 게스트가 호스트 규칙/카탈로그/원본 데이터를 실제 적용 | 마지막 입장자에서 `state=ready`로 이어지는지 확인 |
