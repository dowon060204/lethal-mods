# 0.2.2 검증 계획 및 현재 결과

## 수행 수준

1. **소스 정적 점검: 수행.** 실제 0.2.0과 수정 소스 비교, 소유권 관련 원본 IL 확인, 원본 함수 15개·필드 28개 메타데이터/스택 높이/분기 검사. Python 정적 검사 결과는 JSON에 기록했습니다. C# 타입 검사와 런타임 IL 실행이 아닙니다.
2. **실제 C# 컴파일: 미실행.** dotnet build 실행 요청에서 `FileNotFoundError`가 발생했습니다. .NET SDK/C# 컴파일러뿐 아니라 Unity/Netcode/BepInEx 참조 파일도 제공되지 않았습니다. `docs/BUILD_ENVIRONMENT.json`에 구체적인 상태가 있습니다.
3. **실행 가능한 C# 테스트: 미실행.** `tests/Program.cs`에 기존 규칙 6개와 통신 상태 조건 24개, 총 30개 조건을 검사하는 콘솔 테스트를 추가했습니다. 실제 production `Rules.cs`, `HandshakeState.cs`를 링크합니다. Unity 객체/실제 전송/동적 IL 어댑터 실행을 흉내 내는 테스트가 아닙니다. 여기서는 .NET이 없어 실행하지 못했습니다.
4. **실제 게임 실행: 미검증.**
5. **실제 멀티플레이: 미검증.**

이전에 사용자가 0.2.0에서 빌드/싱글 성공을 확인한 사실을 0.2.2 검증 결과로 전용하지 않습니다.

## 최소 실기 프로필

BepInExPack 5 + 이번 빌드의 ScrapEggMayhem 0.2.2만 설치합니다. 추가 필수 라이브러리는 BepInExPack의 Harmony이며 manifest를 그대로 유지합니다. BetterSpectate/다른 객체 보호 모드는 제외합니다. 호스트와 게스트 양쪽에서 이전 DLL 중복이 없는지, 실제 로드 경로/버전이 같은지 로그로 확인합니다.

첫 실행 로그의 `HideManagerGameObject` 관찰값과 보호 전·후 플래그를 기록합니다. 기존 프로필에서 이미 보호된 상태만 시험하고 단독 동작을 검증했다고 하지 않습니다. 설정값을 몰래 바꾸거나 테스트 통과를 위해 사용자에게 필수 수동 변경을 요구하지 않습니다.

## 실제 실행 체크리스트 — 전부 현재 미검증

| 항목 | 관찰할 결과 |
|---|---|
| 깨끗한 프로필 첫 메인 메뉴 | 첫 Update와 초기 시점 이후 Update가 기록됨. 게임 객체가 없어도 native failure로 중단되지 않음 |
| 혼자 방 생성 후 일반 아이템 | 좌클릭 투척, 원본 달걀 판정/충돌/피해 효과 확인 |
| 샷건/레이저 포인터 | 기존 좌클릭 유지, 강제 투척 없음, 내려놓기 관련 처리 확인 |
| 상점 아이템 | 좌클릭/내려놓기에 추가 규칙 없음 |
| 지상→궤도→다음 라운드 | 반복 처리 유지, 중복 native equip/효과/코루틴 없음 |
| 로비 이탈→새 로비 | old manager/handler 정리, 새 역할/epoch/플레이어 연결, 옛 메시지 적용 없음 |
| A 호스트/B 게스트 | 양쪽 ready 후 둘 다 일반 아이템을 각각 투척. 게스트 입력/소유권/결과 로그 확인 |
| B 호스트/A 게스트 | 같은 기준으로 역할 교환 확인 |
| 다른 사람이 들어오는 순간 | 대기 상태 후 자동 복구. 기존 아이템의 떨어짐/충돌/결과가 누락되는지도 별도 확인 |
| 게스트 지연 접속/나갔다 재접속 | 새 hello, epoch, 객체 준비 후 동작. 영구 Healthy=false로 바뀌지 않음 |
| BetterSpectate를 다시 함께 설치 | 보호 이미 적용 처리, 중복 초기화/패치 없음. 다른 플러그인의 재활성화 영향 확인 |
| 설정 유지 | 기존 Enabled/제외/기존 사용 보호 목록과 기본값 유지 |
| 버전 또는 모드 없는 peer | 이유 로그와 안전 대기. 자동 추방/강제 소유권/가짜 원본 동작 없음 |
| 종료 | quitting=true 이후 재시도/객체 재생성 없음, 자기 패치와 구독만 정리 |

최초 Update/ready 로그만으로 위 표를 통과로 체크하지 않습니다. 객체 생존과 네트워크 동기화를 별도 결과로 기록하세요. 늦게 참가한 사람의 과거 바닥 아이템, 비정상적으로 긴 메시지 지연, 다른 모드가 기본 낙하/입력 전체를 교체하는 경우는 호환성 추가 시험 대상입니다.

## PC에서 실행할 검사

정상 경로는 `build.cmd`이며 원본 IL 감사 → C# 순수 상태 테스트 → 모드 컴파일 → 설치용 ZIP 생성 순서입니다. 순수 테스트만 실행하려면 .NET SDK 8에서:

```powershell
dotnet restore .\tests\Rules.Tests.csproj --configfile .\NuGet.Config
dotnet run --project .\tests\Rules.Tests.csproj --configuration Release --no-restore
```

다른 SDK major만 설치되어 있을 때는 일반 `build.cmd`를 사용하면 테스트 TargetFramework를 해당 SDK에 맞춥니다.

Python 3 정적 검사를 별도로 반복하려면:

```powershell
python .\tools\verify_native.py "D:\SteamLibrary\steamapps\common\Lethal Company\Lethal Company_Data\Managed\Assembly-CSharp.dll"
python .\tools\verify_repair.py
```

Python 검사 결과는 정적 결과일 뿐 실행 가능한 모드 테스트가 아닙니다.
