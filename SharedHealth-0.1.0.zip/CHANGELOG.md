# 변경 내역

- Build fix: support the current six-argument `PlayerControllerB.KillPlayer(Vector3, bool, CauseOfDeath, int, Vector3, bool)` signature in both runtime selection and ApiAudit.

## 0.1.0 — 소스 초안

- 최대 100의 호스트 권한 공유 체력 모델, 실제 피해/회복 관찰, 사망 공유, 원래 라운드 부활 기준 세대 초기화 작성.
- 전원 설치 확인, 게임 MVID 및 모드/프로토콜 버전 비교, 전체 명단 스냅숏, 사건 순서/중복/세션 구분 작성.
- 별도 보호 루트, 네트워크 교체 재연결, 동일 연결의 플레이어 객체 교체, 자신의 구독/패치 정리 작성.
- 원본 처리를 생략하지 않는 관찰 패치, 원래 부활 메서드가 생략된 경우 세대를 초기화하지 않는 처리 작성.
- 설치된 Harmony의 정상/원본 생략/예외 경로 시작 검사 및 생산용 전체 상태 C# 왕복 시작 검사 작성.
- 생산용 C# 핵심 코드 연결 테스트, 참조 메타데이터 감사 도구, 새 출력만 패키징하는 Windows 빌드 스크립트 작성.
- 실제 C# 컴파일·C# 테스트·게임 실행·멀티플레이 검증 미완료. 설치 가능한 DLL 배포본이 아님.

## 0.1.0 buildfix1
- Accept both 4-argument and 5-argument `PlayerControllerB.KillPlayer` signatures and invoke the detected form.
- ApiAudit now validates either supported KillPlayer signature instead of requiring only the older 5-argument form.
- Rewrote both CMD launchers without UTF-8 BOM and with CRLF line endings.

## 0.1.0 buildfix2
- Fixed PowerShell 5/native `dotnet` argument corruption when the source path contains spaces or Korean text.
- Removed the trailing backslash from `BaseIntermediateOutputPath` MSBuild arguments; a quoted Windows path ending in `\` could swallow the closing quote and merge subsequent arguments.
- This specifically fixes builds from paths such as `Downloads\새 폴더\...`.

## 0.1.0 buildfix3
- Restored the MSBuild-required trailing separator using `/` instead of `\`, avoiding PowerShell 5 native argument quoting corruption while satisfying `BaseIntermediateOutputPath`.
- Kept one-command `build.cmd` behavior for paths containing spaces/Korean text.

## 0.1.0 buildfix4
- Root cause from the latest local reference audit: the installed game exposes a `KillPlayer` form outside the previous 4/5-argument allow-list.
- Added the 6-argument `KillPlayer(Vector3, bool, CauseOfDeath, int, Vector3, bool)` signature used by current game/mod call sites.
- Runtime invocation uses the installed method metadata's default value for the trailing Boolean when available, otherwise `false`.
- ApiAudit accepts the same 4/5/6 signature set so a successful audit and runtime target selection stay consistent.
