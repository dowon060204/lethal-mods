﻿# Local build verification

This package contains a freshly compiled SharedHealth 0.1.0 DLL.
C# core tests and actual reference metadata audit completed in build run 20260918-130516-aa227809.
See docs/core-tests.json and docs/reference-audit.json for exact results and hashes.

NOT performed by this build script: Unity startup, the runtime Harmony probe, actual game health/HUD,
A-host/B-guest, reverse roles, four-player play, reconnect, late join, scene transitions, BetterSpectate compatibility.
A successful C# build is not proof of game compatibility. Use a disposable test profile first.
