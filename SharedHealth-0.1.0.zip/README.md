# Build on the configured PC

Run:

```bat
build.cmd
```

Configured paths:
- Game: `C:\Program Files (x86)\Steam\steamapps\common\Lethal Company`
- BepInEx: `C:\Users\kmh04\AppData\Roaming\com.kesomannen.gale\lethal-company\profiles\빌드용\BepInEx`

Successful output: `dist\SharedHealth-0.1.0.zip`

# SharedHealth 0.1.0

리썰 컴퍼니 전원 설치형 공유 체력 모드입니다. 이 README는 **build.ps1이 실제 C# 컴파일에 성공했을 때 생성하는 설치용 ZIP**에 들어갑니다. 소스 배포 ZIP에 이 문서가 들어 있다는 사실만으로 빌드 성공을 의미하지 않습니다.

## 동작 의도

생존 플레이어들이 최대 100의 공동 체력을 사용합니다. 한 사람의 실제 피해와 회복을 호스트가 반영하여 모두에게 전송합니다. 공동 체력이 0이 되거나 한 명의 실제 사망이 보고되면 다른 생존자도 원래 사망 메서드로 사망합니다. 원래 게임의 ReviveDeadPlayers가 정상 실행되면 다음 세대의 체력은 100으로 초기화됩니다.

최대 체력 합산, 새로운 회복 타이머, 채팅 명령, 설정 메뉴, 새 키 바인딩은 없습니다.

## 설치

모두가 동일한 SharedHealth 0.1.0과 같은 게임 어셈블리를 사용해야 합니다. 최소 목표 구성은 BepInEx 5 + SharedHealth이며 BetterSpectate는 필요하지 않습니다. 단독 실행은 실기 검증이 남아 있습니다.

패키지의 `BepInEx` 폴더를 사용 중인 프로필의 같은 위치에 병합합니다. 교체 대상은 다음 DLL 하나입니다.

```text
BepInEx/plugins/PensilSharedHealth/SharedHealth.dll
```

다른 위치에 남아 있는 같은 모드의 구버전 DLL을 중복 설치하지 마세요. 다른 모드나 설정 파일은 삭제하지 않습니다. 호스트만 설치하는 모드가 아닙니다.

## 검증 수준

빌드 실행 결과·SDK·참조 경로·DLL 해시는 `BUILD_STATUS.json`을 확인하세요. C# 핵심 로직 테스트와 참조 어셈블리 정적 검사는 `docs/core-tests.json`, `docs/reference-audit.json`에 있습니다.

**컴파일 성공은 실제 게임·멀티플레이 성공을 의미하지 않습니다.** 이 빌드 스크립트는 Unity나 리썰 컴퍼니를 실행하지 않습니다. A호스트/B게스트와 반대 역할, 기본 4인, 재접속, 장면 전환, 다음 라운드, BetterSpectate 동시 설치는 별도 확인해야 합니다. 먼저 세이브에 영향이 없어도 되는 새 테스트 프로필에서 확인하세요.

최대 체력 변경·사망 취소·다른 공유 체력 모드와의 호환성은 보장하지 않습니다. 여러 플레이어에게 원래 회복이 각각 발생하면 실제 증가량을 합산합니다. 중상/출혈/애니메이션 적용과 원래 HUD의 시각적 표시도 실기 검증 대상입니다. 중도 입장 자체를 가능하게 만드는 기능은 포함하지 않습니다.

진단 로그는 `BepInEx/LogOutput.log`입니다. `[load]`에서 실제 로딩한 DLL 경로와 버전을, `[net/waiting]`에서 준비 지연을, `[fatal/init]` 또는 `[fatal/session]`에서 핵심 오류를 확인합니다. 시작 자체 검사, 패치 설치, ACK 로그를 전체 게임 성공으로 해석하지 않습니다.
