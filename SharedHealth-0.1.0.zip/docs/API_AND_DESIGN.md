# API 근거 및 설계 — 0.1.0 소스 초안

## 근거 수준

사용자가 실행한 참조 감사에서 현재 설치본의 `DamagePlayer` 등은 일치했지만, 기존 소스가 고정한 5인자 `KillPlayer` 서명은 일치하지 않았습니다. 이 수정본은 4인자/5인자/6인자 형태를 모두 허용하고 실제 설치본에서 존재하는 하나를 런타임에 선택합니다. 실제 Unity/멀티플레이 동작 검증은 여전히 별도입니다. 이전 프로젝트 자료에 기록된 게임 해시를 이번 모드의 검증 증거로 사용하지 않았습니다.

아래 API는 공개 자료에서 확인한 후보와 공식 라이브러리 API를 이용해 작성했습니다. 후보 사용 사례는 현재 설치본의 증거가 아닙니다. `tools/ApiAudit`는 사용자가 빌드할 때 실제 설치본을 열어 정확한 메서드와 필드 형식을 검사하도록 작성한 도구이며, 작성 환경에서는 실행하지 못했습니다.

### 요구하는 게임 API

| 대상 | 서명 / 형식 | 분류 |
| --- | --- | --- |
| PlayerControllerB.DamagePlayer | instance void (Int32, Boolean, Boolean, CauseOfDeath, Int32, Boolean, UnityEngine.Vector3) | 필수 관찰 패치 |
| PlayerControllerB.KillPlayer | instance void `(UnityEngine.Vector3, Boolean, CauseOfDeath, Int32)` **또는** `(UnityEngine.Vector3, Boolean, CauseOfDeath, Int32, UnityEngine.Vector3)` **또는** `(UnityEngine.Vector3, Boolean, CauseOfDeath, Int32, UnityEngine.Vector3, Boolean)` | 필수 사망 관찰/실행; 실제 설치본에 존재하는 오버로드 선택 |
| PlayerControllerB.Update | instance void () | 필드 직접 변경 보조 관찰 |
| StartOfRound.ReviveDeadPlayers | instance void () | 정상 라운드 체력 초기화 경계 |
| StartOfRound.Update | instance void () | 런타임 객체 비활성화/파괴 복구 보조 |
| HUDManager.UpdateHealthUI | instance void (Int32, Boolean) | 선택적 원래 HUD 호출 |
| PlayerControllerB.health | Int32 | 필수 |
| actualClientId | UInt64 | 필수, OwnerClientId와 대응 확인 |
| isPlayerDead / isPlayerControlled | Boolean | 필수 |
| criticallyInjured / bleedingHeavily | Boolean | 필수 |
| causeOfDeath | CauseOfDeath | 필수 |
| playerBodyAnimator | UnityEngine.Animator | 필수 필드; 실제 객체 준비는 지연 가능 |

이외에 `GameNetworkManager.Instance.localPlayerController`, `StartOfRound.Instance.allPlayerScripts`, Unity의 기본 객체·장면·시간 API, Netcode 소유권·메시징 API를 사용합니다. 이 직접 참조 부분의 타입/접근성은 실제 전체 C# 컴파일에서도 확인해야 합니다.

`GameApi.Validate`는 런타임에도 필수 패치 대상을 다시 확인합니다. 필수 API 또는 패치 설치가 실패하면 정상 준비 로그를 남기지 않고 초기화를 중단합니다. 선택적인 HUD 실패는 핵심 체력/통신 처리를 중단시키지 않습니다.

중상 기준 `0 < health < 20`, 출혈 필드, Animator `Limp` 적용은 소스에서 명시적으로 보이는 가정입니다. 현재 사용자 게임 원본의 중상/출혈/회복 의미와 일치하는지는 미검증입니다. 실제 서명 검사만으로 이 가정까지 검증한 것으로 간주하지 않습니다.

## 공개 참조 자료

다음은 구현 시 읽은 자료입니다. 링크된 소스 코드를 모드에 복사하거나 해당 게임/라이브러리 바이너리를 동봉하지 않았습니다. 브랜치 문서는 향후 변경될 수 있으며 사용자 설치본 버전을 의미하지 않습니다.

- BepInEx v5-lts Chainloader: 공용 ManagerObject, ConfigHideBepInExGOs/HideManagerGameObject 및 플러그인 AddComponent 경로.
  https://raw.githubusercontent.com/BepInEx/BepInEx/v5-lts/BepInEx/Bootstrap/Chainloader.cs
- Unity HideFlags 공식 문서: 플래그의 의미와 객체 수명 관련 주의점.
  https://docs.unity3d.com/ScriptReference/HideFlags.html
- Unity Netcode FastBufferWriter / FastBufferReader 공식 소스: WriteBytesSafe, ReadBytesSafe 및 버퍼 경계.
  https://raw.githubusercontent.com/Unity-Technologies/com.unity.netcode.gameobjects/develop/com.unity.netcode.gameobjects/Runtime/Serialization/FastBufferWriter.cs
  https://raw.githubusercontent.com/Unity-Technologies/com.unity.netcode.gameobjects/develop/com.unity.netcode.gameobjects/Runtime/Serialization/FastBufferReader.cs
- HarmonyX Patch parameters / Prefix changes: __state, __runOriginal, __exception 및 원본 생략 시 prefix 동작 차이.
  https://github.com/BepInEx/HarmonyX/wiki/Patch-parameters
  https://github.com/BepInEx/HarmonyX/wiki/Prefix-changes
- HarmonyX v2.9.0 HarmonyManipulator 실제 소스: prefix/postfix/finalizer 생성 순서, finalizer 재진입 가능성 및 원본 실행 상태 전달.
  https://raw.githubusercontent.com/BepInEx/HarmonyX/v2.9.0/Harmony/Public/Patching/HarmonyManipulator.cs
- 공개 모드의 게임 API 사용 사례. 실제 설치본 대체 증거가 아니며, 해당 모드를 필수 의존성으로 삼지 않습니다.
  https://old.thunderstore.io/c/lethal-company/p/V2rtua1/DamageMonitor/source/
  https://thunderstore.io/c/lethal-company/p/VypicusTingz/Vanoce_se_blizi/source/
  https://old.thunderstore.io/c/lethal-company/p/OpJosMods/GhostMode/source/

일부 공개 모드 페이지는 재열기 요청에서 캐시 오류가 발생했습니다. 최종적인 호환성 확인은 사용자의 실제 참조 파일 및 게임 테스트로 해야 합니다.

## 실행 구조

플러그인 껍데기는 BepInEx 공용 객체에 붙습니다. 지속 실행 로직은 독립 루트의 `Driver`가 소유합니다. 보호 순서는 루트 생성 → 비활성화 → 소유 루트에 HideAndDontSave → DontDestroyOnLoad → API/시작 검사/패치 → Driver 추가 → 활성화입니다. 장면 객체의 자식으로 만들지 않습니다.

공용 객체 플래그나 사용자 전역 설정은 수정하지 않습니다. `HideManagerGameObject`는 읽을 수 있는 구성 줄과 실제 BepInEx 내부 ConfigEntry의 값을 각각 진단합니다. 내부 필드 이름이 다른 로더는 실제 값을 `unknown`으로 남기며 기본값을 추정하지 않습니다.

`OnDisable`는 해제/영구 중단으로 취급하지 않습니다. 장면 및 StartOfRound.Update heartbeat로 자기 Driver만 복구합니다. 실제 파괴 시 세션을 정리하고 정적 참조를 비웁니다. 파괴된 Unity 객체의 관리 참조가 남은 경우에도 새 메시지 핸들러를 등록하기 전에 이전 세션부터 해제합니다. 게임 종료 플래그가 먼저 설정되면 재생성하지 않습니다.

필수 Harmony 패치는 자기 ID로만 관리합니다. 시작 자체 검사는 프로젝트 내부의 별도 더미 메서드에 일시적 패치를 걸어 설치된 Harmony에서 정상 실행, 원본 생략, 원본 예외 유지, ref __state 정리를 확인합니다. 그 패치는 즉시 자기 ID로 제거합니다. 이 검사는 게임 메서드 실행이나 Unity 수명 검증을 대신하지 않습니다.

피해/사망 관찰 prefix는 원본을 생략하지 않습니다. Finalizer는 실제 결과를 관찰하고 원래 예외를 그대로 반환합니다. ref bool 상태를 먼저 소비하여 finalizer가 다시 실행되어도 capture/reset을 두 번 정리하지 않습니다. 원래 부활 메서드가 다른 패치에 의해 생략되면 공유 체력과 사건 큐를 초기화하지 않습니다.

## 권한과 통신

호스트가 가진 HostPool만 공동 체력, 사망 확정, 사건 승인, 상태 번호를 변경합니다. 각 소유 클라이언트는 자기 플레이어의 실제 변화만 보고하고 자기 사망 처리와 HUD 갱신을 수행합니다. 원격 플레이어에게 직접 KillPlayer를 호출하지 않습니다.

게스트는 ConnectedClientsIds 같은 서버 명단 API를 사용하지 않도록 호출 위치를 분리했습니다. 배열 인덱스를 ClientId로 사용하지 않습니다. 실제 연결 ClientId = 객체 OwnerClientId = 게임 actualClientId를 확인한 뒤 NetworkObjectId를 별도로 기록합니다. Steam ID는 이 프로토콜의 키로 사용하지 않습니다.

Unity CustomMessagingManager의 한 채널에 수신자를 등록합니다. 별도 NetworkBehaviour나 RPC 코드 생성기가 없습니다. 호스트 자신의 메시지도 동일한 C# 바이트 직렬화·복원·Dispatch 경로를 사용하지만, 실제 전송 계층은 내부 큐이므로 원격 전송 성공과 동일시하지 않습니다.

### 패킷

- Header: magic, protocol ushort, kind byte, UTF-8 mod version.
- Hello: 연결 난수 ID, 게임 MVID, 실제 소유 객체 ID, 마지막 세션/세대, 로컬 부활 경계, 준비 상태/진단 문자열.
- Snapshot: 세션 난수, 수신 연결 난수, 세대, 상태 번호, 라운드 초기화 번호, Waiting/Active, 체력, 사망 원인, 진단 이유, 전체 참가자 명단.
- Change: 세션/연결/세대, 순차 사건 번호, 소유 객체 ID, 실제 체력 변화 또는 실제 사망.
- Applied: 동일 세션/세대/상태 번호, 본인 객체, 전체 스냅숏 SHA-256, 본인 적용 체력/사망 여부, 명단 수.

한 패킷은 최대 8192바이트, 참가자 64명, 진단 문자열 최대 256 UTF-8바이트입니다. 명단의 ClientId/ObjectId/Peer가 중복되거나 활성 명단이 비면 거부합니다. 현재 연결과 다른 세션 또는 수신 연결 난수의 상태를 적용하지 않습니다. 명단은 인간 이름 대신 실제 ID를 전송합니다. 한국어는 진단 이유와 초기화 상태에서 왕복 검사합니다.

서버가 실제 연결을 확인하고 소유 객체를 대조한 뒤 보고를 받습니다. 게스트는 서버 송신 스냅숏만 받습니다. 호스트 연결당 초당 128패킷, 수신 큐 1024개, 미승인 로컬 사건 128개, 틱당 최대 128개 처리로 경계를 둡니다. 송신자가 소유한 게임 결과를 보고하는 구조이므로 **악성 클라이언트의 자기 체력 조작을 막는 안티치트는 아닙니다.** SHA-256은 상태 일치 검사이며 비밀키 인증 기능이 아닙니다.

같은 사건 번호 재전송은 피해를 중복 적용하지 않습니다. 순서가 빠지면 뒤 사건을 먼저 적용하지 않고 원래 번호로 재시도합니다. 세대가 바뀌면 이전 사건은 폐기됩니다. 동일 연결 내 객체 교체는 사건 번호를 보존하고 새 객체로 재전송합니다. 실제 연결 해제나 새 Peer로 바뀐 연결은 이전 사건을 재사용하지 않습니다.

Snapshot을 받기 직전에 발생한 로컬 변화를 먼저 보존합니다. 공유 적용 중 생긴 변경은 관찰에서 제외하며 미승인 로컬 변화는 최신 호스트 체력에 재계산합니다. 예측만 0일 때는 다른 사람을 먼저 죽이지 않습니다. 호스트가 승인한 0에서만 사망을 호출합니다.

로컬 체력/사망 값, 본인 ID, 전체 참가자 객체가 확인되고 미승인 사건이 없을 때만 Applied를 전송합니다. 호스트는 자신의 해당 수신자용 전체 상태와 지문/상태 번호/명단 수/본인 값을 비교합니다. 이 확인은 원래 HUD가 실제로 그려졌거나 게임 사망 절차 전체가 끝났다는 인증이 아닙니다.

## 초기화/복구의 의미

메뉴에서 null인 플레이어/HUD/NetworkManager는 준비 대기입니다. 네트워크 바인딩은 0.5초 간격, Hello와 전체 상태는 통상 1초 간격, 사건 재전송은 0.75초 간격입니다. 일시적인 Hello 누락은 로그와 Waiting으로 구분합니다. 로컬 핵심 오류는 해당 세션을 중단하고 진단하며, HUD 오류는 재시도합니다.

네트워크 객체/역할 변경 시 다시 연결합니다. 중도 입장자에게 최신 전체 상태를 보내는 절차를 작성했지만, 게임의 입장 허용 규칙을 변경하지 않습니다. 원래 부활 콜백의 호스트/게스트 호출 횟수 및 순서가 다르면 세대 정합 대기에 머무를 수 있습니다. 실제 버전에서의 callback 순서가 확인되지 않았으므로 이 항목은 주요 실기 검증 대상입니다.

## 설정/입력/채팅 비적용 범위

사용자 설정 항목, 명령어, 채팅 표시, 키 입력은 만들지 않았습니다. 따라서 사용자 설정 직렬화 왕복, 키 재설정, 채팅 기록 대기열은 적용할 기능이 없습니다. 게임의 다른 설정은 수정하지 않습니다. 현재 버전에는 구성 파일 마이그레이션도 없습니다.
