# Changelog

## 0.2.4 — 2026-09-18

- 함선 출발 전 궤도를 포함해 플레이어가 준비된 모든 round/ship phase에서 체인을 Active로 유지.
- `GameView.MissionActive`와 `inShipPhase`/`shipHasLanded`/`shipIsLeaving` 기반 활성 제한 제거.
- 빌드/런타임 API audit에서도 더 이상 사용하지 않는 세 phase 필드를 요구하지 않음.
- 살아 있는 플레이어 2명 이상 + 완전한 호환 roster가 Active의 핵심 조건.
- 0.2.3 장력 가속도/매달림/낙하 물리는 그대로 유지.
- protocol 데이터 형식은 동일하여 v4 유지; 플러그인 버전 0.2.4 핸드셰이크로 구버전 혼용 차단.

## 0.2.4 — 2026-09-18

- 매달림 중 `fallValue`/`fallValueUncapped`를 계속 0으로 만드는 처리와 grace window 제거.
- hard rope가 실제로 제거한 **상대 방사 방향 수직 속도 성분**만 fall state에서 제거.
- anchor와 함께 아래로 떨어지는 공통 하강 속도 보존.
- 위쪽 네트워크 속도 추정을 fallValue에 주입하지 않아 비정상적인 상향 발사 방지.
- 위치 기반 soft pull을 장력 가속도 + 누적 `ropeVelocity` 방식으로 교체.
- 공중에 매달린 아래 endpoint의 하중을 거의 팽팽한 줄을 통해 위 endpoint에 전달.
- 장력 해제 시 ropeVelocity 감쇠 및 지상 잔류 속도 빠른 제거.
- 사망자/시체 분리는 0.2.2 동작 유지.
- protocol v4 / `pensil.chainedcrew.wire.v4`.

# ChainedCrew 변경 이력

## 0.2.2 — 2026-09-18

- 밸런스 조정: 죽은 플레이어와 시체를 체인 endpoint에서 즉시 제거.
- 중간 플레이어가 죽으면 남은 생존자끼리 슬롯 순서로 재연결 (`A—B—C` → B 사망 → `A—C`).
- 사망 프레임에 이전 endpoint sample도 즉시 삭제하여 시체에 1~2프레임 체인이 남는 경로 제거.
- 살아 있는 플레이어가 2명 미만이면 Active 체인 비활성.
- `PlayerControllerB.deadBody` 런타임/API audit 의존성 제거.
- 의미 호환을 막기 위해 protocol v3 / `pensil.chainedcrew.wire.v3`로 변경.
- 0.2.1의 매달림 hard constraint 및 낙하 상태 초기화 수정은 유지.
- 한 줄 `Build.cmd` 기본 경로 유지.

# 변경 이력

## 0.2.1 — 2026-09-18

사슬 매달림 뒤 착지 즉사 문제를 수정한 소스 수정본입니다. 실제 게임 실기 검증 전 단계입니다.

- hard chain constraint가 실제로 **위쪽 방향** 보정을 제공할 때만 로컬 플레이어의 `fallValue`, `fallValueUncapped`, `takingFallDamage`를 0/false로 중화.
- hard projection 직후 정확히 LinkLength에 맞아 다음 프레임 excess가 0이 되는 경우를 덮기 위해 약 30~100ms의 짧은 안전 구간 추가.
- 수평/아래 방향 hard constraint, 일반 free-fall, slack 상태에서는 fall state를 건드리지 않아 원래 낙사 피해를 유지하도록 범위 제한.
- 런타임 API 검증과 build-time ApiAudit에 `fallValue`, `fallValueUncapped`, `takingFallDamage` 공개 필드 검사를 추가.
- 순수 C# 테스트 정의를 72개로 확대. 위쪽/수평/아래 방향 지원 판정과 slack/비정상 입력 검사를 추가.
- `hanging-fall-reset` 단계 로그 추가.
- 프로토콜 데이터 형식은 변경하지 않아 v2 채널을 유지하되, 플러그인 버전은 0.2.1로 올려 혼합 설치를 막음.
- 기존 한 줄 `Build.cmd` 기본 경로와 시체 체인 동작 유지.

C# 컴파일, 자동 테스트 실행, 실제 장시간 매달림 후 착지, 일반 낙사 회귀, 호스트·게스트 검증은 제작 환경에서 미실행입니다.

## 0.2.0 — 2026-09-18

낙하 hard constraint와 시체 체인을 추가한 소스 수정본입니다. 실제 게임 실기 검증 전 단계입니다.

- 죽은 플레이어를 체인 topology에서 제거하지 않고 기존 슬롯 순서에 유지.
- `PlayerControllerB.deadBody : DeadBodyInfo`를 실제 설치본 API audit 대상으로 추가하고, 생성된 시체 root transform을 chain endpoint로 사용.
- 시체 Rigidbody/NetworkObject를 직접 이동시키지 않음. 살아 있는 플레이어가 시체를 버리고 멀리 갈 수 없게 하여 기본 시체 들기/운반을 gameplay로 유지.
- 아래로 떨어지는 살아 있는 플레이어가 LinkLength를 넘으면 초과 방사 거리만 즉시 제거하는 hard constraint 추가. 접선 방향 이동은 남겨 매달림/흔들림을 목표로 함.
- hard constraint는 빠른 낙하 중 길이 초과를 막기 위해 MaxPullSpeed 제한을 사용하지 않음. 충돌은 CharacterController.Move로 유지.
- 중간 플레이어 양쪽 constraint를 최대 3회 순차 투영하고, 충돌로 0.12m 이상 초과가 남으면 진단 로그 추가.
- Active 규칙을 2명 이상 chain member + 최소 1명 living으로 변경하여 살아 있는 1명과 시체들의 체인 유지.
- 프로토콜을 v2 / `pensil.chainedcrew.wire.v2`로 변경하여 0.1.0과 의미 호환을 차단.
- C# 테스트 정의를 67개로 확대. 사망자 topology 유지, one-live+corpse Active, hard excess/hanging/corpse constraint 선택을 추가.
- 기존 사용자의 한 줄 `Build.cmd` 기본 경로와 config 보존 구조 유지.

C# 컴파일, 자동 테스트 실행, 실제 낙하/시체 들기/호스트·게스트 검증은 제작 환경에서 미실행입니다.

## 0.1.0 — 2026-09-17

최초 소스 구현입니다. 실제 컴파일된 DLL 릴리스가 아닙니다.

- 생존 플레이어 순서에 따른 선형 사슬 명단과 로컬 소유자 전용 soft tether 작성.
- 자체 생성 타원형 고리 메시 및 렌더 실패 분리 작성.
- 독립 루트 실행 객체, 초기 보호, 중복 방지, 종료/비활성/파괴 처리 작성.
- nonce/challenge/session/revision 기반 전체 상태 프로토콜, 실제 객체 바인딩 후 확인, 크기/권한/중복 검증 작성.
- 실내외·급격한 위치 변화·특수 상호작용 중 연결 중단 및 과도한 보정 상한 작성.
- 원본 게임 참조 신원 생성/검사 도구, C# 테스트, 실제 NGO 및 BepInEx 설정 런타임 프로브 작성.
- 새 실행 디렉터리와 실패 상태 기록을 사용하는 개발용 빌드/패키징 스크립트 작성.
- 사용자가 제공한 게임/BepInEx 경로를 기본값으로 추가해 `Build.cmd` 한 줄로 빌드할 수 있게 수정. 한글 `빌드용` 프로필 이름은 PowerShell 파일 인코딩에 의존하지 않도록 Unicode 코드포인트로 조합.
- BetterSpectate, Harmony 패치, 채팅/명령/키 변경, 런타임 소스 컴파일러, 공유 사망/추가 아이템 규칙 없음.

컴파일·자동 C# 테스트·실제 게임·역할 교대 멀티플레이는 제작 환경에서 미실행입니다. 알려진 제한과 세부 상태는 README/VALIDATION 참조.
