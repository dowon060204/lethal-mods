using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;

namespace CruiserLineup.Core
{
    public sealed class Moon
    {
        public readonly string Key, Korean, English;
        public readonly string[] Aliases;
        public Moon(string key, string ko, string en, params string[] aliases)
        { Key = key; Korean = ko; English = en; Aliases = aliases; }
    }

    public static class Moons
    {
        public const int SlotsPerMoon = 8;
        public static readonly Moon[] All = {
            new Moon("experimentation", "익스페리멘테이션", "Experimentation", "익스페리멘테이션"),
            new Moon("assurance", "어슈어런스", "Assurance", "어슈어런스", "어슈런스"),
            new Moon("vow", "보우", "Vow", "보우"),
            new Moon("offense", "오펜스", "Offense", "오펜스"),
            new Moon("march", "머치", "March", "머치", "마치"),
            new Moon("adamance", "애더먼스", "Adamance", "애더먼스", "어드먼스", "아다먼스"),
            new Moon("rend", "렌드", "Rend", "렌드"),
            new Moon("dine", "다인", "Dine", "다인"),
            new Moon("titan", "타이탄", "Titan", "타이탄"),
            new Moon("artifice", "아티피스", "Artifice", "아티피스"),
            new Moon("embrion", "엠브리온", "Embrion", "엠브리온"),
            new Moon("company", "회사 건물", "The Company Building", "gordion", "companybuilding", "thecompanybuilding", "회사", "회사건물", "고르디온"),
            new Moon("liquidation", "리퀴데이션", "Liquidation", "리퀴데이션")
        };
        public static Moon Get(string key) => All.FirstOrDefault(m => m.Key == key);
        private static string Normalize(string s)
        {
            s = Regex.Replace((s ?? "").ToLowerInvariant(), @"^\s*(?:level\s*)?\d*\s*", "");
            return Regex.Replace(s, @"[^a-z가-힣]", "");
        }
        public static Moon Resolve(string scene, string planet)
        {
            // Scene identity takes precedence over a localized display label. No numeric level-ID guesses.
            foreach (var candidate in new[] { scene, planet })
            {
                var n = Normalize(candidate);
                foreach (var m in All)
                    if (n == m.Key || n == Normalize(m.English) || m.Aliases.Any(a => n == Normalize(a))) return m;
            }
            return null;
        }
    }

    [DataContract]
    public sealed class Vec3
    {
        [DataMember(Name="x", Order=0, IsRequired=true)] public float X;
        [DataMember(Name="y", Order=1, IsRequired=true)] public float Y;
        [DataMember(Name="z", Order=2, IsRequired=true)] public float Z;
        public Vec3() { }
        public Vec3(float x, float y, float z) { X=x; Y=y; Z=z; }
    }
    [DataContract]
    public sealed class PoseData
    {
        [DataMember(Name="position", Order=0, IsRequired=true)] public Vec3 Position;
        [DataMember(Name="rotationEuler", Order=1, IsRequired=true)] public Vec3 RotationEuler;
        [DataMember(Name="scale", Order=2, IsRequired=true)] public Vec3 Scale;
    }
    [DataContract]
    public sealed class Lineup
    {
        [DataMember(Name="name", Order=0, IsRequired=true)] public string Name = "";
        [DataMember(Name="pose", Order=1, IsRequired=true)] public PoseData Pose;
        [DataMember(Name="jumpTimesMs", Order=2, IsRequired=true)] public List<int> JumpTimesMs = new List<int>();
        [DataMember(Name="instructions", Order=3, IsRequired=true)] public string Instructions = "";
    }
    [DataContract]
    public sealed class SlotEntry
    {
        // inherit = packaged default; empty = explicit deletion; value = user's override.
        [DataMember(Name="state", Order=0, IsRequired=true)] public string State = "inherit";
        [DataMember(Name="data", Order=1, IsRequired=true)] public Lineup Data;
    }
    [DataContract]
    public sealed class MoonEntries
    {
        [DataMember(Name="moon", Order=0, IsRequired=true)] public string Moon;
        [DataMember(Name="slots", Order=1, IsRequired=true)] public List<SlotEntry> Slots;
        // Optional, so schema-1 files from 0.1.0/0.1.1 retain their original identity order.
        // Values are stable slot IDs, NOT replacements for the slots/drafts themselves.
        [DataMember(Name="slotOrder", Order=2, EmitDefaultValue=false)] public List<int> SlotOrder;
    }
    [DataContract]
    public sealed class LineupBook
    {
        [DataMember(Name="schemaVersion", Order=0, IsRequired=true)] public int SchemaVersion = 1;
        [DataMember(Name="moons", Order=1, IsRequired=true)] public List<MoonEntries> Maps;
        public static LineupBook Empty(string state)
        {
            return new LineupBook { Maps = Moons.All.Select(m => new MoonEntries {
                Moon=m.Key, Slots=Enumerable.Range(0, Moons.SlotsPerMoon)
                    .Select(_ => new SlotEntry { State=state }).ToList()
            }).ToList() };
        }
        public SlotEntry Entry(string moon, int slot)
        {
            Guard.Index(moon, slot);
            return Maps.Single(m => m.Moon == moon).Slots[slot];
        }
    }
    [DataContract]
    public sealed class Draft
    {
        [DataMember(Name="moon", Order=0, IsRequired=true)] public string Moon;
        [DataMember(Name="slot", Order=1, IsRequired=true)] public int Slot;
        [DataMember(Name="step", Order=2, IsRequired=true)] public int Step;
        [DataMember(Name="baseline", Order=3, IsRequired=true)] public string Baseline;
        [DataMember(Name="data", Order=4, IsRequired=true)] public Lineup Data = new Lineup();
        [DataMember(Name="timingComplete", Order=5, IsRequired=true)] public bool TimingComplete;
    }
    [DataContract]
    public sealed class ViewState
    {
        [DataMember(Name="moon", Order=0, IsRequired=true)] public string Moon;
        [DataMember(Name="activeDraftSlot", Order=1, IsRequired=true)] public int ActiveDraftSlot=-1;
    }
    [DataContract]
    public sealed class Workspace
    {
        [DataMember(Name="schemaVersion", Order=0, IsRequired=true)] public int SchemaVersion=1;
        [DataMember(Name="drafts", Order=1, IsRequired=true)] public List<Draft> Drafts=new List<Draft>();
        [DataMember(Name="views", Order=2, IsRequired=true)] public List<ViewState> Views=Moons.All.Select(m=>new ViewState{Moon=m.Key}).ToList();
        public ViewState View(string moon) => Views.Single(v=>v.Moon==moon);
        public Draft Find(string moon,int slot) => Drafts.FirstOrDefault(d=>d.Moon==moon&&d.Slot==slot);
    }
    public static class Guard
    {
        public const int MaxEvents=512, MaxTimeMs=600000, MaxName=64, MaxInstructions=4096;
        public static void Require(bool value,string message) { if (!value) throw new InvalidDataException(message); }
        public static void Index(string moon,int slot)
        { Require(Moons.Get(moon)!=null,"Unknown moon: "+moon); Require(slot>=0 && slot<Moons.SlotsPerMoon,"Invalid slot index"); }
        public static void Vector(Vec3 v,bool positive=false)
        {
            Require(v!=null,"Missing vector");
            foreach (var n in new[]{v.X,v.Y,v.Z})
                Require(!float.IsNaN(n)&&!float.IsInfinity(n)&&Math.Abs(n)<=1000000f&&(!positive||n>0f),"Invalid vector value");
        }
        public static void Pose(PoseData p)
        { Require(p!=null,"Missing pose"); Vector(p.Position); Vector(p.RotationEuler); Vector(p.Scale,true); }
        public static void Times(List<int> times,bool allowEmpty)
        {
            Require(times!=null,"Missing jumpTimesMs");
            Require(times.Count<=MaxEvents && (allowEmpty||times.Count>0),"Invalid timing count");
            if(times.Count==0) return;
            Require(times[0]==0,"First timestamp must be 0 ms");
            var previous=-1;
            foreach(var t in times) { Require(t>=0&&t<=MaxTimeMs&&t>=previous,"Invalid or descending timestamp"); previous=t; }
        }
        public static void Data(Lineup d,bool draft=false)
        {
            Require(d!=null,"Missing lineup data");
            Require(d.Name!=null&&d.Name.Length<=MaxName&&(draft||!string.IsNullOrWhiteSpace(d.Name)),"Invalid name");
            Require(d.Instructions!=null&&d.Instructions.Length<=MaxInstructions,"Invalid instructions");
            if(!draft||d.Pose!=null) Pose(d.Pose);
            Times(d.JumpTimesMs,draft);
        }
        public static void Book(LineupBook b,bool defaults=false)
        {
            Require(b!=null&&b.SchemaVersion==1,"Unsupported or missing schemaVersion");
            Require(b.Maps!=null&&b.Maps.Count==Moons.All.Length,"Expected all 13 moon records");
            Require(b.Maps.All(m=>m!=null)&&b.Maps.Select(m=>m.Moon).Distinct().Count()==Moons.All.Length,"Duplicate or missing moon records");
            foreach(var m in b.Maps)
            {
                Require(Moons.Get(m.Moon)!=null,"Unknown moon record");
                Require(m.Slots!=null&&m.Slots.Count==8,"Each moon must contain exactly 8 slots");
                if(m.SlotOrder!=null) SlotOrdering.Validate(m.SlotOrder);
                foreach(var s in m.Slots)
                {
                    Require(s!=null,"Null slot entry");
                    Require(s.State=="empty"||s.State=="value"||(!defaults&&s.State=="inherit"),"Invalid slot state");
                    if(s.State=="value") Data(s.Data); else Require(s.Data==null,"Only value slots may have data");
                }
            }
        }
        public static void Drafts(Workspace w)
        {
            Require(w!=null&&w.SchemaVersion==1,"Unsupported workspace version");
            Require(w.Drafts!=null&&w.Drafts.Count<=104,"Invalid drafts");
            var keys=new HashSet<string>();
            foreach(var d in w.Drafts)
            {
                Require(d!=null,"Null draft"); Index(d.Moon,d.Slot);
                Require(keys.Add(d.Moon+":"+d.Slot),"Duplicate draft");
                Require(d.Step>=0&&d.Step<=3,"Invalid editor step");
                Require(d.Baseline!=null&&d.Baseline.Length==64,"Invalid baseline fingerprint");
                Data(d.Data,true);
                if(d.TimingComplete) Times(d.Data.JumpTimesMs,false);
            }
            Require(w.Views!=null&&w.Views.Count==13,"Missing views");
            Require(w.Views.All(v=>v!=null)&&w.Views.Select(v=>v.Moon).Distinct().Count()==13,"Duplicate views");
            foreach(var v in w.Views)
            {
                Require(Moons.Get(v.Moon)!=null&&v.ActiveDraftSlot>=-1&&v.ActiveDraftSlot<8,"Invalid view");
                Require(v.ActiveDraftSlot<0||w.Find(v.Moon,v.ActiveDraftSlot)!=null,"Active draft missing");
            }
        }
    }
    public sealed class InvalidDataException : Exception
    { public InvalidDataException(string message) : base(message) { } }
}
