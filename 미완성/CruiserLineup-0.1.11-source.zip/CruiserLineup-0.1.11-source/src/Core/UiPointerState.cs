using System;
namespace CruiserLineup.Core
{
    // Pure coordinates. Raw Input System delta already represents pixels per update;
    // multiplying it by deltaTime would make clicking depend on the frame rate.
    public sealed class UiPointerState
    {
        public float X { get; private set; }
        public float Y { get; private set; }
        private int lastFrame = -1;
        private bool initialized;
        public void Open(float width, float height)
        {
            if (!initialized) { X = width * 0.5f; Y = height * 0.5f; initialized = true; }
            X = Clamp(X, width); Y = Clamp(Y, height); lastFrame = -1;
        }
        public void Step(int frame, bool locked, float dx, float dy, float absoluteX, float absoluteY, float width, float height)
        {
            if (!initialized) Open(width, height);
            if (frame == lastFrame) return;
            lastFrame = frame;
            if (locked) { X += Finite(dx) ? dx : 0; Y += Finite(dy) ? dy : 0; }
            else { if (Finite(absoluteX)) X = absoluteX; if (Finite(absoluteY)) Y = absoluteY; }
            X = Clamp(X, width); Y = Clamp(Y, height);
        }
        private static bool Finite(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        private static float Clamp(float x, float limit)
        { if (!Finite(limit) || limit < 1) limit = 1; if (!Finite(x)) x = limit * 0.5f; return Math.Max(0, Math.Min(limit - 1, x)); }
    }
}
