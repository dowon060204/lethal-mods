using System;
using System.Collections.Generic;
using System.Linq;

namespace CruiserLineup.Core
{
    public sealed class TimingRecorder
    {
        private readonly List<int> times=new List<int>();
        private double first=double.NaN,last=double.NaN;
        public bool Recording { get; private set; }
        public int Count => times.Count;
        public IReadOnlyList<int> Times => times;
        public void Start() { times.Clear(); first=last=double.NaN; Recording=true; }
        public bool Press(double inputEventTime)
        {
            if(!Recording||double.IsNaN(inputEventTime)||double.IsInfinity(inputEventTime)) return false;
            // Same callback time can be presented twice by another patch. Do not double-record it.
            if(!double.IsNaN(last)&&inputEventTime<=last) return false;
            if(double.IsNaN(first)) first=inputEventTime;
            var ms=(inputEventTime-first)*1000.0;
            if(ms>Guard.MaxTimeMs||times.Count>=Guard.MaxEvents) { Recording=false; return false; }
            times.Add((int)Math.Round(ms,MidpointRounding.AwayFromZero)); last=inputEventTime; return true;
        }
        public List<int> Stop() { Recording=false; return new List<int>(times); }
    }
    public static class TimingPlan
    {
        public static double[] Schedule(List<int> times,double startDsp)
        {
            Guard.Times(times,false);
            Guard.Require(!double.IsNaN(startDsp)&&!double.IsInfinity(startDsp),"Invalid DSP start time");
            return times.Select(t=>startDsp+t/1000.0).ToArray();
        }
        public static int PeakOverlap(List<int> times,double clipSeconds)
        {
            Guard.Times(times,false);
            var left=0; var peak=0;
            for(var right=0;right<times.Count;right++)
            {
                while(left<right&&(times[right]-times[left])/1000.0>=clipSeconds) left++;
                peak=Math.Max(peak,right-left+1);
            }
            return peak;
        }
    }
    public static class ChatLines
    {
        public static List<string> Split(string name,string instructions,int maximum=180)
        {
            Guard.Require(maximum>=2,"Chat chunk size must be at least 2");
            var result=new List<string>();
            var text=("[CruiserLineup] "+name+"\n"+instructions).Replace("\0","\\0").Replace("\r","").Replace("<","‹").Replace(">","›");
            foreach(var raw in text.Split('\n'))
            {
                var line=raw;
                while(line.Length>maximum)
                {
                    var n=maximum; if(char.IsHighSurrogate(line[n-1])) n--;
                    result.Add(line.Substring(0,n)); line=line.Substring(n);
                }
                if(line.Length>0) result.Add(line);
            }
            return result;
        }
    }
}
