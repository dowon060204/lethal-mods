using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

namespace CruiserLineup.Core
{
    public static class JsonStore
    {
        public const int MaxBytes=4*1024*1024;
        public static byte[] Encode<T>(T value)
        {
            var ser=new DataContractJsonSerializer(typeof(T),new DataContractJsonSerializerSettings { MaxItemsInObjectGraph=1000000 });
            using(var stream=new MemoryStream())
            {
                using(var writer=JsonReaderWriterFactory.CreateJsonWriter(stream,new UTF8Encoding(false),false,true,"  "))
                { ser.WriteObject(writer,value); writer.Flush(); }
                return stream.ToArray();
            }
        }
        public static T Decode<T>(byte[] bytes)
        {
            Guard.Require(bytes!=null&&bytes.Length>0&&bytes.Length<=MaxBytes,"Empty or oversized JSON file");
            using(var stream=new MemoryStream(bytes))
            {
                var ser=new DataContractJsonSerializer(typeof(T),new DataContractJsonSerializerSettings { MaxItemsInObjectGraph=1000000 });
                using(var reader=JsonReaderWriterFactory.CreateJsonReader(stream,XmlDictionaryReaderQuotas.Max))
                { var result=(T)ser.ReadObject(reader); if(reader.Read()) throw new InvalidDataException("Trailing JSON content"); return result; }
            }
        }
        public static T Clone<T>(T value) => Decode<T>(Encode(value));
        public static string Hash<T>(T value)
        {
            using(var sha=SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encode(value))).Replace("-","").ToLowerInvariant();
        }
        public static byte[] ReadBounded(string path)
        {
            using(var f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read))
            {
                Guard.Require(f.Length>0&&f.Length<=MaxBytes,"Empty or oversized JSON file");
                using(var ms=new MemoryStream()) { f.CopyTo(ms); return ms.ToArray(); }
            }
        }
        public static T Read<T>(string path,Action<T> validate)
        { var value=Decode<T>(ReadBounded(path)); validate(value); return value; }
        public static void WriteAtomic<T>(string path,T value,Action<T> validate)
        {
            validate(value);
            var bytes=Encode(value);
            Guard.Require(bytes.Length<=MaxBytes,"JSON exceeds size limit");
            var roundTrip=Decode<T>(bytes); validate(roundTrip);
            Guard.Require(Hash(value)==Hash(roundTrip),"C# serialization round-trip mismatch");
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
            string temp=path+".tmp-"+Guid.NewGuid().ToString("N");
            try
            {
                using(var fs=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None))
                { fs.Write(bytes,0,bytes.Length); fs.Flush(true); }
                var disk=Read<T>(temp,validate);
                Guard.Require(Hash(disk)==Hash(value),"JSON disk read-back mismatch");
                // Never delete the original as a fallback when atomic replacement fails.
                if(File.Exists(path)) File.Replace(temp,path,path+".bak",true); else File.Move(temp,path);
            }
            finally { if(File.Exists(temp)) File.Delete(temp); }
        }
    }

    public sealed class LineupRepository
    {
        private readonly string path;
        private readonly LineupBook defaults;
        private LineupBook user;
        public bool ReadOnly { get; private set; }
        public string Error { get; private set; }="";
        public LineupRepository(string path,LineupBook defaults)
        {
            Guard.Book(defaults,true); this.defaults=JsonStore.Clone(defaults); this.path=path;
            user=LineupBook.Empty("inherit"); Reload();
        }
        public bool Reload()
        {
            try
            {
                user=File.Exists(path)?JsonStore.Read<LineupBook>(path,b=>Guard.Book(b)):LineupBook.Empty("inherit");
                ReadOnly=false; Error=""; return true;
            }
            catch(Exception e) { ReadOnly=true; Error=e.Message; return false; }
        }
        private Lineup Resolve(LineupBook book,string moon,int slot)
        {
            var entry=book.Entry(moon,slot);
            if(entry.State=="inherit") entry=defaults.Entry(moon,slot);
            return entry.State=="value"?entry.Data:null;
        }
        public Lineup Get(string moon,int slot) => JsonStore.Clone(Resolve(user,moon,slot));
        public string Signature(string moon,int slot) => JsonStore.Hash(Resolve(user,moon,slot));
        public System.Collections.Generic.List<int> GetOrder(string moon)
        {
            Guard.Index(moon,0);
            return SlotOrdering.Effective(user.Maps.Single(m=>m.Moon==moon).SlotOrder);
        }
        public string OrderSignature(string moon) => JsonStore.Hash(GetOrder(moon));
        public void Reorder(string moon,System.Collections.Generic.IReadOnlyList<int> order,string baseline)
        {
            Guard.Index(moon,0); SlotOrdering.Validate(order);
            Guard.Require(!ReadOnly,"Config is read-only after a load error. Repair it and reopen the UI.");
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
            using(var fileLock=new FileStream(path+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None))
            {
                var latest=File.Exists(path)?JsonStore.Read<LineupBook>(path,b=>Guard.Book(b)):LineupBook.Empty("inherit");
                var map=latest.Maps.Single(m=>m.Moon==moon);
                Guard.Require(JsonStore.Hash(SlotOrdering.Effective(map.SlotOrder))==baseline,
                    "This moon's order changed on disk. Close and reopen the UI before reordering.");
                map.SlotOrder=order.ToList();
                JsonStore.WriteAtomic(path,latest,b=>Guard.Book(b)); user=latest;
            }
        }
        public void Commit(string moon,int slot,Lineup value,string baseline)
        {
            Guard.Index(moon,slot); if(value!=null) Guard.Data(value);
            Guard.Require(!ReadOnly,"Config is read-only after a load error. Repair it and reopen the UI.");
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
            using(var guard=new FileStream(path+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None))
            {
                // Read the latest full document so an external edit to a different slot is retained.
                var latest=File.Exists(path)?JsonStore.Read<LineupBook>(path,b=>Guard.Book(b)):LineupBook.Empty("inherit");
                Guard.Require(JsonStore.Hash(Resolve(latest,moon,slot))==baseline,
                    "This slot changed on disk. Reopen the slot before overwriting it.");
                var target=latest.Entry(moon,slot); target.State=value==null?"empty":"value";
                target.Data=value==null?null:JsonStore.Clone(value);
                JsonStore.WriteAtomic(path,latest,b=>Guard.Book(b)); user=latest;
            }
        }
    }
}
