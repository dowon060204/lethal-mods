namespace CruiserLineup.Core
{
    // Pure flag policy. No registry, process, console or Unity calls.
    public static class ConsoleModePolicy
    {
        public const uint QuickEdit=0x0040, Extended=0x0080, Mask=QuickEdit|Extended;
        public static uint WithoutQuickEdit(uint original) => (original|Extended)&~QuickEdit;
        public static bool CanRestore(uint current,uint applied) => (current&Mask)==(applied&Mask);
        public static uint RestoreOwnBits(uint current,uint original) => (current&~Mask)|(original&Mask);
    }
}
