using System;

namespace CruiserLineup.Core
{
    // One click = one intent. Never execute application work in a Unity UI event callback.
    // A view/session epoch rejects clicks belonging to a previous page or lobby.
    public sealed class UiCommandQueue
    {
        private Action pending;
        private long epoch, pendingEpoch;
        private string name;
        public long Epoch => epoch;
        public bool Pending => pending != null;
        public void Invalidate() { epoch++; pending=null; name=null; }
        public bool Enqueue(string label, Action action)
        {
            if(action==null) throw new ArgumentNullException(nameof(action));
            if(pending!=null) return false; // no accumulation during a slow frame / double click
            pending=action; name=label; pendingEpoch=epoch; return true;
        }
        public bool TryTake(out string label,out Action action)
        {
            label=name; action=pending; pending=null; name=null;
            if(action==null||pendingEpoch!=epoch) { action=null; label=null; return false; }
            return true;
        }
    }
}
