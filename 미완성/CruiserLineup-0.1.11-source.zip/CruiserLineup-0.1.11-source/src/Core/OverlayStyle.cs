using System;

namespace CruiserLineup.Core
{
    // Opacity is the visible fraction, not the fraction removed from the image.
    // Existing valid personal settings are never migrated or overwritten.
    public static class OverlayStyle
    {
        public const float DefaultOpacity = 0.25f;
        public const float MinimumOpacity = 0.05f;
        public const float MaximumOpacity = 1f;

        public static float NormalizeOpacity(float value)
        {
            if (float.IsNaN(value) || float.IsInfinity(value)) return DefaultOpacity;
            return Math.Max(MinimumOpacity, Math.Min(MaximumOpacity, value));
        }
    }
}
