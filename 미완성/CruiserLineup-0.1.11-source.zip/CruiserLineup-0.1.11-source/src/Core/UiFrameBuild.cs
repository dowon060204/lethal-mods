using System;
using System.Collections;

namespace CruiserLineup.Core
{
    // Executes at most one explicitly yielded construction step per game frame.
    // It cannot preempt a blocking Unity native call; it bounds our own managed work.
    public sealed class UiFrameBuild : IDisposable
    {
        private IEnumerator routine;
        private int lastFrame=int.MinValue,steps;
        private readonly int maximumSteps;
        public bool Running => routine!=null;
        public bool Completed {get; private set;}
        public Exception Error {get; private set;}
        public int Steps => steps;
        public UiFrameBuild(int maximumSteps=64)
        { if(maximumSteps<1) throw new ArgumentOutOfRangeException(nameof(maximumSteps)); this.maximumSteps=maximumSteps; }
        public void Begin(IEnumerator work)
        {
            if(work==null) throw new ArgumentNullException(nameof(work));
            if(Running) throw new InvalidOperationException("UI construction is already running.");
            routine=work; lastFrame=int.MinValue; steps=0; Completed=false; Error=null;
        }
        public void Tick(int frame)
        {
            if(routine==null||frame==lastFrame) return;
            lastFrame=frame;
            try
            {
                if(++steps>maximumSteps) throw new InvalidOperationException("UI construction exceeded its bounded step count.");
                if(routine.MoveNext()) return;
                var finished=routine; routine=null;
                (finished as IDisposable)?.Dispose(); Completed=true;
            }
            catch(Exception e)
            {
                Error=e; Completed=false;
                var failed=routine; routine=null;
                try { (failed as IDisposable)?.Dispose(); } catch { }
            }
        }
        public void Cancel()
        {
            var old=routine; routine=null; Completed=false;
            try { (old as IDisposable)?.Dispose(); }
            catch(Exception e) { Error=e; }
        }
        public void Dispose() => Cancel();
    }
}
