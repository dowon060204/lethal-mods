using System;
using System.Collections.Generic;
using System.Threading;

namespace CruiserLineup.Core
{
    // One immutable copy of the real jump sound, plus sample-frame offsets. No Unity dependency.
    // The PCM reader runs on Unity's audio thread: no Unity calls, logging, allocation or locks there.
    public sealed class PcmTimeline
    {
        public const int MaximumSourceSamples = 4 * 1024 * 1024;
        private readonly float[] source;
        private readonly int[] starts;
        private readonly int sourceFrames;
        private long position, readCalls, nonSilentBuffers, maximumReadFrame, malformedBuffers;
        public int Channels { get; }
        public int Frequency { get; }
        public int TotalFrames { get; }
        public int EventCount => starts.Length;
        public float SourcePeak { get; }
        public float Gain { get; }
        public int PeakOverlap { get; }
        public long ReadCalls => Interlocked.Read(ref readCalls);
        public long NonSilentBuffers => Interlocked.Read(ref nonSilentBuffers);
        public long MaximumReadFrame => Interlocked.Read(ref maximumReadFrame);
        public long MalformedBuffers => Interlocked.Read(ref malformedBuffers);
        public long Position => Interlocked.Read(ref position);
        public long StorageBytes => (long)source.Length * sizeof(float) + (long)starts.Length * sizeof(int);

        public PcmTimeline(float[] samples, int channels, int frequency, List<int> times)
        {
            Guard.Times(times, false);
            Guard.Require(channels >= 1 && channels <= 8, "Unsupported Cruiser channel count.");
            Guard.Require(frequency >= 8000 && frequency <= 192000, "Unsupported Cruiser sample rate.");
            Guard.Require(samples != null && samples.Length > 0 && samples.Length <= MaximumSourceSamples &&
                samples.Length % channels == 0, "Invalid or oversized Cruiser PCM data.");
            Channels = channels; Frequency = frequency; sourceFrames = samples.Length / channels;
            source = (float[])samples.Clone(); starts = new int[times.Count];
            float peak = 0;
            for (int i = 0; i < source.Length; i++)
            {
                float value = source[i];
                Guard.Require(!float.IsNaN(value) && !float.IsInfinity(value), "Nonfinite Cruiser PCM data.");
                peak = Math.Max(peak, Math.Abs(value));
            }
            Guard.Require(peak > 0, "The Cruiser sound contains only zero samples. Refusing a silent preview.");
            SourcePeak = peak;
            for (int i = 0; i < starts.Length; i++)
                starts[i] = MillisecondsToFrames(times[i], frequency);
            long total = (long)starts[starts.Length - 1] + sourceFrames;
            Guard.Require(total > 0 && total <= int.MaxValue, "Timing audio exceeds Unity's sample-frame limit.");
            TotalFrames = (int)total;
            int left = 0, overlap = 0;
            for (int right = 0; right < starts.Length; right++)
            {
                while (left < right && (long)starts[left] + sourceFrames <= starts[right]) left++;
                overlap = Math.Max(overlap, right - left + 1);
            }
            PeakOverlap = overlap;
            // A uniform gain bounds even worst-case overlapping samples. Never changes pitch, time or event count.
            // No gain reduction at all when the source peak * overlap is already <= 1.
            Gain = (float)Math.Min(1.0, 1.0 / ((double)SourcePeak * PeakOverlap));
        }

        public static int MillisecondsToFrames(int milliseconds, int frequency)
        {
            Guard.Require(milliseconds >= 0 && milliseconds <= Guard.MaxTimeMs, "Invalid timing offset.");
            Guard.Require(frequency >= 8000 && frequency <= 192000, "Invalid sample rate.");
            return checked((int)(((long)milliseconds * frequency + 500L) / 1000L));
        }

        // Public for actual C# tests. Offsets are sample FRAMES, not interleaved float indices.
        // Returns whether any nonzero PCM was written. Does not move the stream cursor.
        public bool RenderAt(long firstFrame, float[] destination)
        {
            if (destination == null) throw new ArgumentNullException(nameof(destination));
            if (firstFrame < 0 || destination.Length % Channels != 0)
                throw new ArgumentException("Invalid frame position or PCM buffer channel alignment.");
            Array.Clear(destination, 0, destination.Length);
            if (firstFrame >= TotalFrames || destination.Length == 0) return false;
            long lastFrame = Math.Min((long)TotalFrames, firstFrame + destination.Length / Channels);
            // Skip all events whose complete source waveform ends before this buffer.
            int lo = 0, hi = starts.Length;
            while (lo < hi)
            {
                int mid = lo + (hi - lo) / 2;
                if ((long)starts[mid] + sourceFrames <= firstFrame) lo = mid + 1; else hi = mid;
            }
            for (int i = lo; i < starts.Length && starts[i] < lastFrame; i++)
            {
                long begin = Math.Max(firstFrame, starts[i]);
                long end = Math.Min(lastFrame, (long)starts[i] + sourceFrames);
                int count = checked((int)(end - begin) * Channels);
                int input = checked((int)(begin - starts[i]) * Channels);
                int output = checked((int)(begin - firstFrame) * Channels);
                for (int n = 0; n < count; n++) destination[output + n] += source[input + n] * Gain;
            }
            bool nonzero = false;
            for (int i = 0; i < destination.Length; i++)
            {
                // The bound above prevents clipping; this clamp only also bounds float rounding at +/-1.
                float value = destination[i];
                if (value > 1f) value = 1f; else if (value < -1f) value = -1f;
                destination[i] = value; nonzero |= value != 0f;
            }
            return nonzero;
        }

        public void Read(float[] data)
        {
            // Unity supplies the callback array. Never allocate or invoke Unity/logging from here.
            if (data == null) { Interlocked.Increment(ref malformedBuffers); return; }
            if (data.Length % Channels != 0)
            {
                Array.Clear(data, 0, data.Length); Interlocked.Increment(ref malformedBuffers); return;
            }
            long first = Interlocked.Read(ref position);
            bool nonzero = RenderAt(first, data);
            long end = Math.Min((long)TotalFrames, first + data.Length / Channels);
            // Do not overwrite a concurrent seek. Unity normally serializes a clip's callbacks.
            Interlocked.CompareExchange(ref position, end, first);
            long previous = Interlocked.Read(ref maximumReadFrame);
            while (end > previous)
            {
                long observed = Interlocked.CompareExchange(ref maximumReadFrame, end, previous);
                if (observed == previous) break;
                previous = observed;
            }
            Interlocked.Increment(ref readCalls);
            if (nonzero) Interlocked.Increment(ref nonSilentBuffers);
        }

        public void Seek(int sampleFrame)
        {
            Interlocked.Exchange(ref position, Math.Max(0, Math.Min(TotalFrames, sampleFrame)));
        }
    }
}
