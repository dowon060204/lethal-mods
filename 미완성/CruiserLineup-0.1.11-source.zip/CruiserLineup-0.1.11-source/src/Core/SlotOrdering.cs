using System;
using System.Collections.Generic;
using System.Linq;

namespace CruiserLineup.Core
{
    public static class SlotOrdering
    {
        public static List<int> Identity() => Enumerable.Range(0,Moons.SlotsPerMoon).ToList();
        public static void Validate(IReadOnlyList<int> order)
        {
            Guard.Require(order!=null&&order.Count==Moons.SlotsPerMoon,"slotOrder must contain exactly 8 IDs.");
            Guard.Require(order.All(i=>i>=0&&i<Moons.SlotsPerMoon)&&order.Distinct().Count()==Moons.SlotsPerMoon,
                "slotOrder must be a permutation of 0 through 7 (no missing or duplicate IDs).");
        }
        public static List<int> Effective(IReadOnlyList<int> order)
        {
            if(order==null) return Identity();
            Validate(order); return order.ToList();
        }
        // Insertion: moving displayed position 1 to 4 shifts positions 2..4 left.
        // No lineup, pose, timing, tombstone, inherited default or draft is copied/reassigned.
        public static List<int> Move(IReadOnlyList<int> order,int from,int to)
        {
            Validate(order);
            Guard.Require(from>=0&&from<Moons.SlotsPerMoon&&to>=0&&to<Moons.SlotsPerMoon,"Invalid reorder position.");
            var result=order.ToList(); var id=result[from]; result.RemoveAt(from); result.Insert(to,id);
            Validate(result); return result;
        }
    }
}
