using System;

namespace CruiserLineup.Core
{
    // A render fault latches until explicit reopen. Never keep rebuilding the same
    // failing/infinite text tree every Update. Budget belongs to our UI only.
    public sealed class UiRenderBudget
    {
        private readonly int maxCalls;
        private int frame=int.MinValue,calls;
        public string Fault {get;private set;}
        public UiRenderBudget(int maxCalls=512)
        { if(maxCalls<1) throw new ArgumentOutOfRangeException(nameof(maxCalls)); this.maxCalls=maxCalls; }
        public bool Enter(int currentFrame)
        {
            if(Fault!=null) return false;
            if(frame!=currentFrame) { frame=currentFrame; calls=0; }
            if(++calls<=maxCalls) return true;
            Fail("Our UI exceeded the text-mesh rebuild budget in one frame."); return false;
        }
        public void Fail(string message) { if(Fault==null) Fault=message??"UI text rendering failed."; }
        public void Reset() { Fault=null; frame=int.MinValue; calls=0; }
    }
}
