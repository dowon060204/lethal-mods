using System;
using System.Diagnostics;
using CruiserLineup.Core;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace CruiserLineup
{
    // Private UI module. Never changes Cursor.lockState/visible, warps the mouse,
    // disables another module, or enumerates other mods' Graphic/PhysicsRaycasters.
    // Native InputField still receives updateSelected events and normal text/IME events.
    public sealed class UiPointerModule : BaseInputModule
    {
        private readonly UiPointerState position = new UiPointerState();
        private GraphicRaycaster raycaster;
        private RectTransform visual;
        private PointerEventData pointer;
        private GameObject lastClick;
        private float lastClickAt;
        private bool activeView, waitForRelease, hadFocus, firstProcess, slowReported;
        private int lastFrame = -1;
        public void Begin(GraphicRaycaster ownRaycaster, RectTransform cursor)
        {
            raycaster = ownRaycaster; visual = cursor; activeView = true;
            position.Open(Screen.width, Screen.height);
            waitForRelease = true; firstProcess = false; slowReported = false; lastFrame = -1;
            hadFocus = Application.isFocused;
        }
        public override bool ShouldActivateModule() => activeView && base.ShouldActivateModule();
        public override bool IsModuleSupported() => true;
        public override bool IsPointerOverGameObject(int pointerId) => activeView && pointer != null && pointer.pointerEnter != null;
        public override void DeactivateModule()
        {
            activeView = false;
            try { ResetPointer(); }
            finally { if (visual != null) visual.gameObject.SetActive(false); }
        }
        public override void Process()
        {
            if (!activeView || raycaster == null || lastFrame == Time.frameCount) return;
            lastFrame = Time.frameCount;
            var start = Stopwatch.GetTimestamp();
            HangTrace.Stage("ui/pointer/begin");
            try
            {
                bool focus = Application.isFocused;
                if (!focus) { if (hadFocus) ResetPointer(); hadFocus = false; waitForRelease = true; return; }
                if (!hadFocus) { waitForRelease = true; hadFocus = true; }
                var mouse = Mouse.current;
                if (mouse == null || !mouse.added) { ResetPointer(); waitForRelease = true; return; }
                if (pointer == null) pointer = new PointerEventData(eventSystem) { pointerId = -1, button = PointerEventData.InputButton.Left };
                pointer.Reset();
                var delta = mouse.delta.ReadValue(); var absolute = mouse.position.ReadValue();
                bool locked = Cursor.lockState == CursorLockMode.Locked;
                var old = new Vector2(position.X, position.Y);
                position.Step(Time.frameCount, locked, delta.x, delta.y, absolute.x, absolute.y, Screen.width, Screen.height);
                pointer.position = new Vector2(position.X, position.Y);
                pointer.delta = pointer.position - old;
                pointer.scrollDelta = mouse.scroll.ReadValue() / 120f;
                if (visual != null)
                {
                    // Use the real pointer when it is already available; never hide or unlock it.
                    visual.gameObject.SetActive(locked || !Cursor.visible);
                    visual.position = new Vector3(position.X, position.Y, 0);
                }
                m_RaycastResultCache.Clear();
                HangTrace.Stage("ui/pointer/own-raycast");
                raycaster.Raycast(pointer, m_RaycastResultCache);
                pointer.pointerCurrentRaycast = FindFirstRaycast(m_RaycastResultCache);
                m_RaycastResultCache.Clear();
                var over = pointer.pointerCurrentRaycast.gameObject;
                HandlePointerExitAndEnter(pointer, over);
                bool held = mouse.leftButton != null && mouse.leftButton.isPressed;
                if (waitForRelease) { if (!held) waitForRelease = false; }
                else
                {
                    if (mouse.leftButton != null && mouse.leftButton.wasPressedThisFrame) Press(over);
                    if (held) Drag();
                    if (mouse.leftButton != null && mouse.leftButton.wasReleasedThisFrame) Release(over, true);
                    if (pointer.scrollDelta.sqrMagnitude > 0)
                        ExecuteEvents.ExecuteHierarchy(over, pointer, ExecuteEvents.scrollHandler);
                }
                HangTrace.Stage("ui/pointer/text-update");
                var selected = eventSystem.currentSelectedGameObject;
                if (selected != null && selected.transform.IsChildOf(raycaster.transform))
                    ExecuteEvents.Execute(selected, GetBaseEventData(), ExecuteEvents.updateSelectedHandler);
                if (!firstProcess) { firstProcess = true; HangTrace.Note("UI/POINTER-FIRST virtual=" + locked + "; nativeCursorWrites=0; raycaster=own-canvas"); }
            }
            catch (Exception error)
            {
                activeView = false;
                LineupRuntime.Current?.RequestUiSafetyClose("Pointer module: " + error.GetType().Name + ": " + error.Message);
            }
            finally
            {
                var ms = (Stopwatch.GetTimestamp() - start) * 1000.0 / Stopwatch.Frequency;
                if (ms > 50 && !slowReported) { slowReported = true; HangTrace.Note("UI/POINTER-SLOW ms=" + ms.ToString("F1", System.Globalization.CultureInfo.InvariantCulture)); }
                HangTrace.FramePhase(2, Time.frameCount);
                HangTrace.Stage("ui/pointer/end");
            }
        }
        private void Press(GameObject over)
        {
            pointer.eligibleForClick = true; pointer.dragging = false;
            pointer.useDragThreshold = true; pointer.pressPosition = pointer.position;
            pointer.pointerPressRaycast = pointer.pointerCurrentRaycast;
            var selectable = ExecuteEvents.GetEventHandler<ISelectHandler>(over);
            if (eventSystem.currentSelectedGameObject != selectable) eventSystem.SetSelectedGameObject(null, pointer);
            var press = ExecuteEvents.ExecuteHierarchy(over, pointer, ExecuteEvents.pointerDownHandler);
            if (press == null) press = ExecuteEvents.GetEventHandler<IPointerClickHandler>(over);
            var now = Time.unscaledTime;
            pointer.clickCount = press == lastClick && now - lastClickAt < 0.3f ? pointer.clickCount + 1 : 1;
            pointer.clickTime = now; lastClick = press; lastClickAt = now;
            pointer.pointerPress = press; pointer.rawPointerPress = over;
            pointer.pointerDrag = ExecuteEvents.GetEventHandler<IDragHandler>(over);
            if (pointer.pointerDrag != null)
                ExecuteEvents.Execute(pointer.pointerDrag, pointer, ExecuteEvents.initializePotentialDrag);
        }
        private void Drag()
        {
            if (pointer.pointerDrag == null || pointer.delta.sqrMagnitude == 0) return;
            if (!pointer.dragging && (!pointer.useDragThreshold ||
                (pointer.position - pointer.pressPosition).sqrMagnitude >= eventSystem.pixelDragThreshold * eventSystem.pixelDragThreshold))
            {
                ExecuteEvents.Execute(pointer.pointerDrag, pointer, ExecuteEvents.beginDragHandler);
                pointer.dragging = true;
            }
            if (!pointer.dragging) return;
            if (pointer.pointerPress != pointer.pointerDrag)
            {
                if (pointer.pointerPress != null) ExecuteEvents.Execute(pointer.pointerPress, pointer, ExecuteEvents.pointerUpHandler);
                pointer.eligibleForClick = false; pointer.pointerPress = null; pointer.rawPointerPress = null;
            }
            ExecuteEvents.Execute(pointer.pointerDrag, pointer, ExecuteEvents.dragHandler);
        }
        private void Release(GameObject over, bool allowClick)
        {
            if (pointer == null) return;
            if (pointer.pointerPress != null) ExecuteEvents.Execute(pointer.pointerPress, pointer, ExecuteEvents.pointerUpHandler);
            var click = ExecuteEvents.GetEventHandler<IPointerClickHandler>(over);
            if (allowClick && pointer.eligibleForClick && pointer.pointerPress != null && pointer.pointerPress == click)
                ExecuteEvents.Execute(pointer.pointerPress, pointer, ExecuteEvents.pointerClickHandler);
            else if (allowClick && pointer.dragging && pointer.pointerDrag != null)
                ExecuteEvents.ExecuteHierarchy(over, pointer, ExecuteEvents.dropHandler);
            if (pointer.dragging && pointer.pointerDrag != null) ExecuteEvents.Execute(pointer.pointerDrag, pointer, ExecuteEvents.endDragHandler);
            pointer.eligibleForClick = false; pointer.dragging = false;
            pointer.pointerPress = pointer.rawPointerPress = pointer.pointerDrag = null;
        }
        private void ResetPointer()
        {
            try { Release(null, false); if (pointer != null) HandlePointerExitAndEnter(pointer, null); }
            finally { pointer = null; lastClick = null; }
        }
    }
}
