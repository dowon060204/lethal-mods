using System;
using BepInEx.Logging;
using UnityEngine;
using Object=UnityEngine.Object;

namespace CruiserLineup
{
    // Local OS default-text rendering, not a font patch. No file downloads, font
    // installation, TMP assets or changes to the HUD / other mods' shared fonts.
    public sealed class SystemUiText : IDisposable
    {
        private readonly ManualLogSource log;
        private Font cached;
        private bool attempted,disposed;
        private Exception failure;
        private const string Sample="한글이름위치불러오기점프타이밍";
        public bool KoreanSampleSupported {get;private set;}
        public bool Attempted => attempted;
        public SystemUiText(ManualLogSource log) {this.log=log;}
        public Font Get()
        {
            if(disposed) throw new ObjectDisposedException(nameof(SystemUiText));
            if(cached!=null) return cached;
            if(attempted) throw new InvalidOperationException("The OS text renderer could not initialize; repeated native retries were suppressed.",failure);
            attempted=true;
            try
            {
                // Same ordinary OS fallback families that made 0.1.5 readable when
                // neither optional designer font was installed. Never enumerate
                // all font files or generate a full 11,172-character Hangul atlas.
                cached=Font.CreateDynamicFontFromOSFont(new[]{
                    "Malgun Gothic","맑은 고딕","Apple SD Gothic Neo",
                    "Noto Sans CJK KR","Noto Sans KR","NanumGothic","Arial","DejaVu Sans"},24);
                if(cached==null) throw new InvalidOperationException("No OS UI font could be created.");
                cached.name="CruiserLineup.LocalSystemText";
                cached.hideFlags=HideFlags.HideAndDontSave;
                // A short probe before any Text component is attached. One call,
                // not a per-frame scan or a font-texture-rebuilt event handler.
                cached.RequestCharactersInTexture(Sample+"ABC0123",24,FontStyle.Normal);
                KoreanSampleSupported=true;
                foreach(char c in Sample) if(!cached.HasCharacter(c)) {KoreanSampleSupported=false;break;}
                log?.LogInfo("[UI/TEXT] Native OS font cached once; Korean sample="+KoreanSampleSupported+
                    "; no TTF files, TMP font creation or shared font mutation.");
                if(!KoreanSampleSupported) log?.LogWarning("[UI/TEXT] The OS default chain lacks the Korean probe. UI help will use English for this run; Language config and saved data are unchanged.");
                return cached;
            }
            catch(Exception e)
            {
                failure=e;
                if(cached!=null) Object.Destroy(cached);
                cached=null; throw;
            }
        }
        public void Dispose()
        {
            if(disposed) return; disposed=true;
            if(cached!=null) Object.Destroy(cached); cached=null;
        }
    }
}
