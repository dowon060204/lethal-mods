using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;

namespace CruiserLineup
{
    public sealed class PatchSet : IDisposable
    {
        private readonly Harmony harmony=new Harmony(Plugin.Guid);
        private readonly ManualLogSource log;
        public bool RecordingPatched { get; private set; }
        public bool ModalPatched { get; private set; }
        private bool disposed,installed;
        public PatchSet(ManualLogSource log) { this.log=log; }
        private bool Prefix(MethodInfo method,string hook)
        {
            harmony.Patch(method,prefix:new HarmonyMethod(typeof(Hooks),hook){priority=Priority.First});
            return Harmony.GetPatchInfo(method)?.Prefixes.Any(p=>p.owner==Plugin.Guid&&p.PatchMethod.Name==hook)==true;
        }
        public void Install(GameBridge bridge)
        {
            if(installed||disposed) return; installed=true;
            if(bridge.JumpMethod!=null)
            {
                try { RecordingPatched=Prefix(bridge.JumpMethod,nameof(Hooks.JumpInput)); }
                catch(Exception e) { log.LogError("[PATCH/RECORDING] "+e); }
            }
            var guarded=0; var failures=0;
            foreach(var type in bridge.InputOwnerTypes())
            {
                foreach(var method in type.GetMethods(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly))
                {
                    var parameters=method.GetParameters();
                    if(method==bridge.JumpMethod||method.ReturnType!=typeof(void)||parameters.Length!=1||parameters[0].ParameterType!=typeof(InputAction.CallbackContext)) continue;
                    try
                    {
                        if(Prefix(method,nameof(Hooks.GuardInput))) guarded++; else failures++;
                    }
                    catch(Exception e) { failures++; log.LogError("[PATCH/MODAL-CALLBACK] "+type.Name+"."+method.Name+": "+e); }
                }
            }
            bool vehicleGuard=false,playerGuard=false;
            try
            {
                if(bridge.VehicleInputMethod==null) throw new MissingMethodException("VehicleController.GetVehicleInput():void");
                vehicleGuard=Prefix(bridge.VehicleInputMethod,nameof(Hooks.VehicleInput));
                harmony.Patch(bridge.VehicleInputMethod,postfix:new HarmonyMethod(typeof(Hooks),nameof(Hooks.VehicleInputAfter)){priority=Priority.Last});
                vehicleGuard=vehicleGuard&&Harmony.GetPatchInfo(bridge.VehicleInputMethod)?.Postfixes.Any(p=>p.owner==Plugin.Guid)==true;
                var update=bridge.PlayerType.GetMethod("Update",BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic,null,Type.EmptyTypes,null);
                if(update==null||update.ReturnType!=typeof(void)) throw new MissingMethodException("PlayerControllerB.Update():void");
                playerGuard=Prefix(update,nameof(Hooks.PlayerUpdate));
            }
            catch(Exception e) { log.LogError("[PATCH/MODAL-POLLING] "+e); }
            ModalPatched=RecordingPatched&&guarded>0&&failures==0&&vehicleGuard&&playerGuard&&bridge.ModalFieldsBound;
            log.LogInfo("[PATCH] Recording="+RecordingPatched+"; Modal="+ModalPatched+"; callback guards="+guarded+"; failed="+failures+
                "; vehicle input reader="+vehicleGuard+"; player flag guard="+playerGuard+". Not a gameplay test.");
        }
        public void Dispose()
        { if(disposed) return; disposed=true; harmony.UnpatchSelf(); RecordingPatched=false; ModalPatched=false; }
    }
    public static class Hooks
    {
        public static bool GuardInput(object __instance,InputAction.CallbackContext __0)
        {
            // Let genuine canceled callbacks clean up existing game action state. No action-map mutation is used.
            if(__0.canceled) return true;
            var runtime=LineupRuntime.Current;
            return runtime==null||!runtime.isActiveAndEnabled||!runtime.BlockGameInput||!runtime.Bridge.IsLocalInputOwner(__instance);
        }
        public static void PlayerUpdate(object __instance)
        {
            var runtime=LineupRuntime.Current;
            if(runtime!=null&&runtime.isActiveAndEnabled&&runtime.BlockGameInput&&runtime.Bridge.IsLocalPlayer(__instance))
                runtime.EnforceModalInput(); // NEVER skip Update/physics/networking.
        }
        public static bool VehicleInput(object __instance)
        {
            var runtime=LineupRuntime.Current;
            if(runtime==null||!runtime.isActiveAndEnabled||!runtime.BlockGameInput||!runtime.Bridge.IsLocalVehicle(__instance)) return true;
            try
            {
                runtime.Bridge.NeutralizeVehicleInput(__instance);
                return false; // Only the input-reading method; gravity/vehicle physics still run.
            }
            catch(Exception e) { runtime.ModalInputFault(e); return true; }
        }
        public static void VehicleInputAfter(object __instance)
        {
            var runtime=LineupRuntime.Current;
            if(runtime!=null&&runtime.isActiveAndEnabled&&runtime.BlockGameInput&&runtime.Bridge.IsLocalVehicle(__instance))
            {
                try { runtime.Bridge.NeutralizeVehicleInput(__instance); }
                catch(Exception e) { runtime.ModalInputFault(e); }
            }
        }
        public static bool JumpInput(object __instance,InputAction.CallbackContext __0)
        {
            var runtime=LineupRuntime.Current;
            if(runtime==null||!runtime.isActiveAndEnabled) return true;
            if(!__0.canceled&&runtime.BlockGameInput&&runtime.Bridge.IsLocalVehicle(__instance)) return false;
            try
            {
                if(__0.performed&&__0.ReadValueAsButton()&&runtime.Bridge.IsLocalVehicle(__instance))
                    runtime.OnJumpInput(__instance,__0.time);
            }
            catch(Exception e) { runtime.RecordingFault(e); }
            return true;
        }
    }
}
