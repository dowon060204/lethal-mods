using System;
using CruiserLineup.Core;
using UnityEngine;
using UnityEngine.UI;

namespace CruiserLineup
{
    // Engine text on our own canvas. No TMP rebuild callbacks or SDF assets.
    // Errors are deferred: disabling a canvas inside its mesh callback is unsafe.
    public sealed class LineupUiText : Text
    {
        private static readonly UiRenderBudget budget=new UiRenderBudget();
        private bool populating;
        public static void ResetFault() => budget.Reset();
        private static void Fail(string message)
        {
            budget.Fail(message);
            LineupRuntime.Current?.RequestUiSafetyClose(budget.Fault);
        }
        protected override void OnPopulateMesh(VertexHelper mesh)
        {
            if(!budget.Enter(Time.frameCount)) { mesh.Clear(); Fail(budget.Fault); return; }
            if(populating) { mesh.Clear(); Fail("Reentrant text mesh generation was stopped."); return; }
            populating=true; HangTrace.Stage("ui/text-mesh/begin");
            try { base.OnPopulateMesh(mesh); }
            catch(Exception e) { mesh.Clear(); Fail("UI text mesh exception: "+e.GetType().Name+": "+e.Message); }
            finally {populating=false;HangTrace.Stage("ui/text-mesh/end");}
        }
    }
}
