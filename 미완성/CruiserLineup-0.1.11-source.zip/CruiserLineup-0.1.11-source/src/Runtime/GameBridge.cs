using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using CruiserLineup.Core;
using UnityEngine;
using UnityEngine.InputSystem;
using Object=UnityEngine.Object;

namespace CruiserLineup
{
    public sealed class GameBridge
    {
        private const BindingFlags Any=BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic;
        private readonly Dictionary<string,MemberInfo> members=new Dictionary<string,MemberInfo>();
        private readonly ManualLogSource log;
        public Type VehicleType { get; private set; }
        public Type PlayerType { get; private set; }
        public Type RoundType { get; private set; }
        public Type HudType { get; private set; }
        private Type networkType;
        public MethodInfo JumpMethod { get; private set; }
        public MethodInfo VehicleInputMethod { get; private set; }
        public bool ModalFieldsBound { get; private set; }
        private FieldInfo[] vehicleInputFields=Array.Empty<FieldInfo>();
        private AudioClip cachedJumpClip;
        public MethodInfo ChatMethod { get; private set; }
        public bool CoreBound { get; private set; }
        public bool Pending { get; private set; }
        public string Error { get; private set; }="";
        public GameBridge(ManualLogSource log) { this.log=log; }
        public object Member(object target,string name)
        {
            if(target==null) return null;
            if(target is Object unity && !unity) return null;
            Type type=target as Type??target.GetType(); var key=type.AssemblyQualifiedName+"|"+name;
            if(!members.TryGetValue(key,out var member))
            {
                for(var t=type;t!=null&&member==null;t=t.BaseType)
                {
                    member=t.GetField(name,Any|BindingFlags.DeclaredOnly);
                    if(member==null)
                    {
                        var prop=t.GetProperty(name,Any|BindingFlags.DeclaredOnly);
                        if(prop!=null&&prop.GetIndexParameters().Length==0) member=prop;
                    }
                }
                members[key]=member;
            }
            var instance=target is Type?null:target;
            if(member is FieldInfo f) return f.GetValue(instance);
            if(member is PropertyInfo p) return p.GetValue(instance,null);
            return null;
        }
        private static bool Bool(object value) => value is bool b&&b;
        public object Singleton(Type t) => t==null?null:Member(t,"Instance");
        public object Round => Singleton(RoundType);
        public object Hud => Singleton(HudType);
        public object Network => Singleton(networkType);
        public Component LocalPlayer => Member(Network,"localPlayerController") as Component;
        public Camera LocalCamera => Member(LocalPlayer,"gameplayCamera") as Camera;
        public bool Alive => LocalPlayer!=null&&!Bool(Member(LocalPlayer,"isPlayerDead"));
        public bool Typing => Bool(Member(LocalPlayer,"isTypingChat"));
        public bool GameMenuOpen => Bool(Member(Member(LocalPlayer,"quickMenuManager"),"isMenuOpen"));
        public bool Landed => Round!=null&&!Bool(Member(Round,"inShipPhase"))&&Bool(Member(Round,"shipHasLanded"));
        public bool IsLocalVehicle(object vehicle) => vehicle!=null&&VehicleType!=null&&
            VehicleType.IsInstanceOfType(vehicle)&&Bool(Member(vehicle,"localPlayerInControl"));
        public bool IsLocalPlayer(object player) => player is Component c&&LocalPlayer!=null&&c==LocalPlayer;
        public string Role => Bool(Member(Network,"isHostingGame"))?"HOST":"GUEST/LOCAL";
        public Moon CurrentMoon
        {
            get
            {
                var level=Member(Round,"currentLevel");
                return Moons.Resolve(Member(level,"sceneName") as string,Member(level,"PlanetName") as string);
            }
        }
        public string RawMoon
        {
            get { var level=Member(Round,"currentLevel"); return (Member(level,"sceneName")??"?")+" / "+(Member(level,"PlanetName")??"?"); }
        }
        public Type[] InputOwnerTypes() => new[]{PlayerType,VehicleType,HudType,
            AccessTools.TypeByName("QuickMenuManager"),AccessTools.TypeByName("ShipBuildModeManager")}.Where(t=>t!=null).Distinct().ToArray();
        public bool IsLocalInputOwner(object owner) => IsLocalPlayer(owner)||IsLocalVehicle(owner)||
            (owner!=null&&(ReferenceEquals(owner,Hud)||ReferenceEquals(owner,Member(LocalPlayer,"quickMenuManager"))||
            ReferenceEquals(owner,Singleton(AccessTools.TypeByName("ShipBuildModeManager")))));
        private void BindModalFields()
        {
            ModalFieldsBound=false;
            try
            {
                RequireField(PlayerType,"disableMoveInput",typeof(bool));
                RequireField(PlayerType,"disableLookInput",typeof(bool));
                RequireField(PlayerType,"moveInputVector",typeof(Vector2));
                VehicleInputMethod=VehicleType.GetMethod("GetVehicleInput",Any,null,Type.EmptyTypes,null);
                if(VehicleInputMethod==null||VehicleInputMethod.ReturnType!=typeof(void))
                    throw new MissingMethodException("VehicleController.GetVehicleInput():void");
                // Discover actual numeric input-state fields, never arbitrary vehicle state.
                // Names/types are logged and also present in the installed-DLL API audit report.
                vehicleInputFields=VehicleType.GetFields(Any).Where(f=>!f.IsStatic&&!f.IsInitOnly&&
                    (f.FieldType==typeof(float)||f.FieldType==typeof(Vector2))&&
                    (f.Name.EndsWith("Input",StringComparison.OrdinalIgnoreCase)||
                     f.Name.EndsWith("InputVector",StringComparison.OrdinalIgnoreCase)||
                     f.Name.EndsWith("InputAxis",StringComparison.OrdinalIgnoreCase))).ToArray();
                if(!vehicleInputFields.Any(f=>f.Name=="steeringInput"&&f.FieldType==typeof(float)))
                    throw new MissingFieldException("VehicleController.steeringInput:float");
                ModalFieldsBound=true;
                log.LogInfo("[API/MODAL] Local movement/look flags verified; vehicle inputs: "+
                    string.Join(", ",vehicleInputFields.Select(f=>f.Name+":"+f.FieldType.Name)));
            }
            catch(Exception e) { log.LogError("[API/MODAL] Modal disabled (input safety): "+e.Message); }
        }
        public void NeutralizeVehicleInput(object vehicle)
        {
            foreach(var field in vehicleInputFields)
                field.SetValue(vehicle,field.FieldType==typeof(Vector2)?(object)Vector2.zero:0f);
        }
        private void RequireField(Type type,string name,Type expected=null)
        {
            var field=AccessTools.Field(type,name);
            if(field==null||(expected!=null&&field.FieldType!=expected))
                throw new MissingFieldException(type.FullName,name+" expected "+expected);
        }
        public void Bind()
        {
            Pending=false;
            try
            {
                VehicleType=AccessTools.TypeByName("VehicleController")??throw new TypeLoadException("VehicleController");
                PlayerType=AccessTools.TypeByName("GameNetcodeStuff.PlayerControllerB")??throw new TypeLoadException("PlayerControllerB");
                RoundType=AccessTools.TypeByName("StartOfRound")??throw new TypeLoadException("StartOfRound");
                HudType=AccessTools.TypeByName("HUDManager")??throw new TypeLoadException("HUDManager");
                networkType=AccessTools.TypeByName("GameNetworkManager")??throw new TypeLoadException("GameNetworkManager");
                RequireField(VehicleType,"localPlayerInControl",typeof(bool));
                RequireField(VehicleType,"carDestroyed",typeof(bool));
                RequireField(VehicleType,"vehicleID",typeof(int));
                RequireField(VehicleType,"jumpInCarSFX",typeof(AudioClip));
                RequireField(RoundType,"currentLevel");
                RequireField(RoundType,"inShipPhase",typeof(bool));
                RequireField(RoundType,"shipHasLanded",typeof(bool));
                RequireField(PlayerType,"isPlayerDead",typeof(bool));
                RequireField(PlayerType,"isTypingChat",typeof(bool));
                RequireField(PlayerType,"gameplayCamera",typeof(Camera));
                RequireField(networkType,"localPlayerController");
                var level=AccessTools.TypeByName("SelectableLevel");
                if(level==null) throw new TypeLoadException("SelectableLevel");
                RequireField(level,"sceneName",typeof(string)); RequireField(level,"PlanetName",typeof(string));
                JumpMethod=VehicleType.GetMethod("DoTurboBoost",Any,null,new[]{typeof(InputAction.CallbackContext)},null);
                if(JumpMethod==null||JumpMethod.ReturnType!=typeof(void))
                { JumpMethod=null; log.LogError("[API/RECORDING] DoTurboBoost(CallbackContext):void not found. Recording stays disabled; no Space-key guessing."); }
                // Select an actual local overload; additional arguments must carry primitive defaults in metadata.
                // Never confuse AddChatMessage with AddTextToChatOnServer / a network RPC.
                ChatMethod=HudType.GetMethods(Any).Where(m=>m.Name=="AddChatMessage"&&!m.IsStatic&&m.ReturnType==typeof(void))
                    .Where(m=>m.GetParameters().Length>=1&&m.GetParameters().Length<=8&&m.GetParameters()[0].ParameterType==typeof(string))
                    .Where(m=>m.GetParameters().Skip(1).All(p=>p.IsOptional&&p.HasDefaultValue&&
                        (p.ParameterType==typeof(string)||p.ParameterType==typeof(int)||p.ParameterType==typeof(bool))))
                    .OrderBy(m=>m.GetParameters().Length).FirstOrDefault();
                if(ChatMethod==null) log.LogError("[API/CHAT] Supported local AddChatMessage(string, optional primitive defaults) missing; chat unavailable. No server/RPC fallback.");
                else log.LogInfo("[API/CHAT] Actual local overload: "+ChatMethod);
                BindModalFields();
                CoreBound=true; log.LogInfo("[API] Core bindings verified against loaded assemblies. Jump="+(JumpMethod!=null)+", Chat="+(ChatMethod!=null));
                foreach(var asm in new[]{typeof(Plugin).Assembly,VehicleType.Assembly,typeof(BaseUnityPlugin).Assembly,typeof(Harmony).Assembly,typeof(Transform).Assembly,typeof(InputAction).Assembly})
                    LogAssembly(asm);
                var netcode=AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a=>a.GetName().Name=="Unity.Netcode.Runtime");
                if(netcode!=null) LogAssembly(netcode);
                log.LogInfo("[VERSION] Unity="+Application.unityVersion+"; plugin target=netstandard2.1");
                var cfg=Path.Combine(Paths.ConfigPath,"BepInEx.cfg");
                if(File.Exists(cfg))
                    foreach(var line in File.ReadLines(cfg).Where(l=>l.TrimStart().StartsWith("HideManagerGameObject",StringComparison.Ordinal)))
                        log.LogInfo("[ENV] BepInEx.cfg "+line.Trim()+" (not modified)");
            }
            catch(TypeLoadException e) { CoreBound=false; Pending=true; Error=e.Message; log.LogWarning("[API/WAIT] Game type not yet available: "+e.Message); }
            catch(Exception e) { CoreBound=false; Error=e.Message; log.LogError("[FATAL/API] "+e); }
        }
        public void PrintLocalChat(string text)
        {
            if(ChatMethod==null||Hud==null) throw new InvalidOperationException("Local chat API / HUD unavailable.");
            var parameters=ChatMethod.GetParameters(); var args=new object[parameters.Length]; args[0]=text;
            for(int i=1;i<args.Length;i++) args[i]=parameters[i].DefaultValue;
            ChatMethod.Invoke(Hud,args);
        }
        private void LogAssembly(Assembly asm)
        {
            var hash="unavailable";
            try { using(var file=File.OpenRead(asm.Location)) using(var sha=SHA256.Create()) hash=BitConverter.ToString(sha.ComputeHash(file)).Replace("-",""); }
            catch(Exception e) { log.LogWarning("[VERSION/HASH] "+e.Message); }
            log.LogInfo("[VERSION] "+asm.GetName().Name+"="+asm.GetName().Version+"; path="+asm.Location+"; SHA256="+hash);
        }
        public Component FindVehicle(bool inScene)
        {
            if(VehicleType==null) return null;
            var candidates=Resources.FindObjectsOfTypeAll(VehicleType).OfType<Component>()
                .Where(c=>c!=null&&!(Member(c,"carDestroyed") is bool destroyed&&destroyed))
                .Where(c=>Member(c,"vehicleID") is int id&&id==0).ToList();
            if(inScene)
                candidates=candidates.Where(c=>c.gameObject.scene.IsValid()&&c.gameObject.activeInHierarchy).ToList();
            var local=candidates.FirstOrDefault(c=>IsLocalVehicle(c));
            if(local!=null) return local;
            if(inScene)
            {
                var p=LocalPlayer; if(p==null) return null;
                return candidates.Where(c=>(c.transform.position-p.transform.position).sqrMagnitude<=900f)
                    .OrderBy(c=>(c.transform.position-p.transform.position).sqrMagnitude).FirstOrDefault();
            }
            return candidates.OrderByDescending(c=>c.gameObject.scene.IsValid()).FirstOrDefault();
        }
        public AudioClip JumpClip()
        {
            // Do not let the first (possibly destroyed or partially initialized) scene Cruiser
            // mask a valid loaded prefab. Previewing a saved rhythm does not need a live car.
            if(ValidClip(cachedJumpClip)) return cachedJumpClip;
            cachedJumpClip=null;
            if(VehicleType==null) return null;
            var candidates=Resources.FindObjectsOfTypeAll(VehicleType).OfType<Component>()
                .Where(c=>c!=null&&Member(c,"vehicleID") is int id&&id==0)
                .OrderByDescending(c=>IsLocalVehicle(c)).ThenByDescending(c=>c.gameObject.scene.IsValid());
            foreach(var vehicle in candidates)
            {
                var clip=Member(vehicle,"jumpInCarSFX") as AudioClip;
                if(!ValidClip(clip)) continue;
                cachedJumpClip=clip;
                log.LogInfo("[AUDIO/CLIP] Actual VehicleController.jumpInCarSFX; clip="+clip.name+
                    "; source="+vehicle.name+"; samples="+clip.samples+"; channels="+clip.channels+
                    "; frequency="+clip.frequency+"; length="+clip.length+"; load="+clip.loadState);
                return clip;
            }
            return null;
        }
        private static bool ValidClip(AudioClip clip) => clip!=null&&clip.samples>0&&clip.channels>0&&
            clip.frequency>0&&clip.loadState!=AudioDataLoadState.Failed;
        public void ForgetJumpClip() { cachedJumpClip=null; }
        public PoseData Pose(Component vehicle)
        {
            var t=vehicle.transform;
            return new PoseData { Position=ToData(t.position),RotationEuler=ToData(t.eulerAngles),Scale=ToData(t.lossyScale) };
        }
        public static Vec3 ToData(Vector3 v)=>new Vec3(v.x,v.y,v.z);
        public static Vector3 ToUnity(Vec3 v)=>new Vector3(v.X,v.Y,v.Z);
        public GameInputTargets GameInputs()
        {
            var targets=new GameInputTargets(); var assets=targets.Assets;
            Action<object> collect=value=> {
                if(value is InputActionAsset asset) assets.Add(asset);
                else if(value is PlayerInput playerInput&&playerInput.actions!=null) assets.Add(playerInput.actions);
                else if(value is InputAction action)
                { if(action.actionMap?.asset!=null) assets.Add(action.actionMap.asset); else targets.Standalone.Add(action); }
                else if(value is InputActionReference reference&&reference.action!=null)
                { if(reference.action.actionMap?.asset!=null) assets.Add(reference.action.actionMap.asset); else targets.Standalone.Add(reference.action); }
                else if(value!=null&&value.GetType().GetProperty("asset") is PropertyInfo prop&&prop.PropertyType==typeof(InputActionAsset))
                { var a=prop.GetValue(value,null) as InputActionAsset; if(a!=null) assets.Add(a); }
            };
            var player=LocalPlayer;
            var settings=Singleton(AccessTools.TypeByName("IngamePlayerSettings"));
            foreach(var owner in new object[]{player,settings,Round,Hud,Member(player,"quickMenuManager"),Singleton(AccessTools.TypeByName("ShipBuildModeManager")),FindVehicle(true)})
            {
                if(owner==null) continue;
                if(owner is Component component)
                    foreach(var input in component.GetComponents<PlayerInput>()) collect(input);
                for(var t=owner.GetType();t!=null&&t!=typeof(MonoBehaviour);t=t.BaseType)
                    foreach(var f in t.GetFields(Any|BindingFlags.DeclaredOnly))
                    {
                        if(f.FieldType==typeof(InputActionAsset)||f.FieldType==typeof(PlayerInput)||f.FieldType==typeof(InputAction)||
                           f.FieldType==typeof(InputActionReference)||typeof(IInputActionCollection).IsAssignableFrom(f.FieldType))
                            collect(f.GetValue(f.IsStatic?null:owner));
                    }
            }
            // Newer game versions consume InputSystem.actions. Reflection keeps older Input System references buildable.
            var global=typeof(InputSystem).GetProperty("actions",BindingFlags.Public|BindingFlags.Static);
            if(global!=null&&global.PropertyType==typeof(InputActionAsset)) collect(global.GetValue(null,null));
            return targets;
        }
    }
}
