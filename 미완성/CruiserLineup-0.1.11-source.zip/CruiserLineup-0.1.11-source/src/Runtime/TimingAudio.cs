using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx.Logging;
using CruiserLineup.Core;
using UnityEngine;
using Object=UnityEngine.Object;

namespace CruiserLineup
{
    // Original game AudioClip -> native Unity AudioSources. No managed streaming callback,
    // no synthesized replacement, no PCM extraction and no one-deadline-per-Update scheduler.
    public sealed class TimingAudio : IDisposable
    {
        private readonly Transform owner;
        private readonly ManualLogSource log;
        private readonly List<AudioSource> voices=new List<AudioSource>();
        private readonly List<GameObject> voiceRoots=new List<GameObject>();
        private Func<AudioClip> resolver;
        private AudioClip clip;
        private List<int> times;
        private float volume;
        private string moon;
        private bool requested,running,disposed,loadRequested,announced,outputProbed,warmupStopped;
        private int used,resolveAttempts;
        private double nextResolve,nextListenerProbe,deadline,endDsp,nextOutputProbe;
        private int listenerCount;
        public bool Playing=>requested||running;
        public string Moon=>moon;
        public event Action<string> Failed;
        public event Action Started;
        public TimingAudio(Transform owner,ManualLogSource log) {this.owner=owner;this.log=log;}

        // Called when a lobby is ready, not only after a user clicks Listen.
        public void Warmup(Func<AudioClip> clipResolver)
        { if(!disposed&&!Plugin.Quitting&&!warmupStopped&&resolver==null) {resolver=clipResolver;nextResolve=0;} }
        public void Play(Func<AudioClip> clipResolver,List<int> recordedTimes,string playingMoon,float playbackVolume)
        {
            if(disposed||Plugin.Quitting||owner==null)throw new InvalidOperationException("Audio owner is unavailable.");
            Guard.Times(recordedTimes,false);
            if(clipResolver==null)throw new ArgumentNullException(nameof(clipResolver));
            if(float.IsNaN(playbackVolume)||float.IsInfinity(playbackVolume)||playbackVolume<=0)
                throw new InvalidOperationException("[Audio] Volume must be above 0.");
            Stop();warmupStopped=false;resolver=clipResolver;times=new List<int>(recordedTimes);volume=Mathf.Clamp01(playbackVolume);moon=playingMoon;
            requested=true;resolveAttempts=0;deadline=Time.realtimeSinceStartupAsDouble+10;nextResolve=0;nextListenerProbe=0;
            HangTrace.Note("AUDIO/REQUEST events="+times.Count);
            log.LogInfo("[AUDIO/REQUEST] Native original-clip playback; events="+times.Count+"; lastMs="+times[times.Count-1]+"; cached="+(clip!=null));
            Tick();
        }
        private void AddVoice()
        {
            var root=new GameObject("CruiserLineup.LocalTimingVoice."+voices.Count);root.SetActive(false);
            root.hideFlags=HideFlags.HideAndDontSave; Object.DontDestroyOnLoad(root);
            try
            {
                var source=root.AddComponent<AudioSource>();source.playOnAwake=false;source.loop=false;source.spatialBlend=0;source.dopplerLevel=0;
                source.spatialize=false;source.spatializePostEffects=false;source.panStereo=0;source.mute=false;source.enabled=true;
                source.volume=1;source.pitch=1;source.priority=16;source.ignoreListenerPause=true;source.ignoreListenerVolume=false;
                source.bypassEffects=true;source.bypassListenerEffects=true;source.bypassReverbZones=true;source.outputAudioMixerGroup=null;
                source.clip=clip;root.SetActive(true);voiceRoots.Add(root);voices.Add(source);
            }
            catch {Object.Destroy(root);throw;}
        }
        private bool Prepare(double now)
        {
            if(clip==null&&resolver!=null&&now>=nextResolve)
            {
                if(!requested&&resolveAttempts>=15)
                {
                    resolver=null;warmupStopped=true;
                    log.LogInfo("[AUDIO/WARMUP] No game clip after 15 probes. Automatic scanning paused; Listen retries explicitly.");
                    return false;
                }
                resolveAttempts++;nextResolve=now+2;HangTrace.Note("AUDIO/RESOLVE-BEGIN");
                clip=resolver();HangTrace.Note("AUDIO/RESOLVE-END found="+(clip!=null));loadRequested=false;
            }
            if(clip==null) return false;
            if(voices.Any(v=>v==null||v.gameObject==null))
            {
                // A scene cleanup or external object deletion must not leave stale native sources.
                DestroyVoicePool();announced=false;
            }
            if(clip.loadState==AudioDataLoadState.Failed)throw new InvalidOperationException("The game's Cruiser jump sound failed to load.");
            if(clip.loadState==AudioDataLoadState.Unloaded&&!loadRequested)
            {
                loadRequested=true;HangTrace.Note("AUDIO/PRELOAD-BEGIN "+clip.name);
                bool accepted=clip.LoadAudioData();HangTrace.Note("AUDIO/PRELOAD-END accepted="+accepted);
                if(!accepted)throw new InvalidOperationException("Unity rejected preloading the actual Cruiser jump sound.");
            }
            if(clip.loadState!=AudioDataLoadState.Loaded)return false;
            if(clip.samples<=0||clip.frequency<=0||clip.channels<=0)throw new InvalidOperationException("Invalid Cruiser sound metadata.");
            int target=requested?times.Count:8;
            // Spread object construction across Updates. There is no sleep, spin or wait loop.
            for(int n=0;n<4&&voices.Count<target;n++)AddVoice();
            if(voices.Count<target)return false;
            if(!announced){announced=true;log.LogInfo("[AUDIO/READY] Cached actual clip="+clip.name+"; native voices="+voices.Count+"; no GetData/Create/PCM callbacks.");}
            return true;
        }
        private void ScheduleAll(double now)
        {
            if(now>=nextListenerProbe)
            {
                nextListenerProbe=now+.5;
                listenerCount=Object.FindObjectsOfType<AudioListener>().Count(l=>l!=null&&l.isActiveAndEnabled);
            }
            if(listenerCount==0)return;
            if(AudioListener.volume<=0)throw new InvalidOperationException("Game master volume is 0; global mute was not overridden.");
            if(AudioSettings.GetConfiguration().sampleRate<=0)throw new InvalidOperationException("No usable Unity audio output device.");
            // Do not use a frozen DSP clock or change somebody else's pause state.
            if(AudioListener.pause)throw new InvalidOperationException("Game audio is paused. Close the game pause menu before listening.");
            used=times.Count;
            for(int i=0;i<used;i++){voices[i].clip=clip;voices[i].volume=volume;voices[i].pitch=1;voices[i].mute=false;}
            // All loading/source construction is over BEFORE choosing the common DSP origin.
            // All events are submitted together now; later slow game frames cannot collapse the intervals.
            double origin=AudioSettings.dspTime+0.12+used*.001;
            var plan=TimingPlan.Schedule(times,origin);
            HangTrace.Note("AUDIO/SCHEDULE-BEGIN count="+used);
            for(int i=0;i<used;i++)voices[i].PlayScheduled(plan[i]);
            endDsp=plan[used-1]+(double)clip.samples/clip.frequency;
            requested=false;running=true;outputProbed=false;nextOutputProbe=now+.3;
            HangTrace.Note("AUDIO/SCHEDULE-END");
            log.LogInfo("[AUDIO/PLAY] clip="+clip.name+"; all "+used+" native starts submitted together; firstDsp="+origin+
                "; local 2D; volume="+volume+"; no generated AudioClip. Scheduling is not proof of physical audibility.");
            Started?.Invoke();
        }
        public void Tick()
        {
            if(disposed)return;
            if(Plugin.Quitting||owner==null){Stop();return;}
            try
            {
                double now=Time.realtimeSinceStartupAsDouble;
                if(!running)
                {
                    if(requested&&now>deadline){Fail(clip==null?"No actual Cruiser sound asset was available. No substitute sound was used.":"Audio preparation exceeded 10 seconds. Playback canceled; UI remains usable.");return;}
                    if(Prepare(now)&&requested)ScheduleAll(now);
                }
                if(!running)return;
                if(!outputProbed&&now>=nextOutputProbe)
                {
                    outputProbed=true;int active=0,virtualized=0;
                    for(int i=0;i<used;i++){if(voices[i]!=null&&voices[i].isPlaying)active++;if(voices[i]!=null&&voices[i].isVirtual)virtualized++;}
                    log.LogInfo("[AUDIO/OUTPUT] native playing="+active+"; virtual="+virtualized+"; scheduled="+used+"; DSP="+AudioSettings.dspTime+"; telemetry only.");
                }
                if(AudioSettings.dspTime>endDsp+.2){log.LogInfo("[AUDIO/END] Native schedule elapsed.");Stop();}
            }
            catch(Exception e)
            {
                if(requested||running)Fail(e.Message);
                else {log.LogWarning("[AUDIO/WARMUP] "+e.Message);resolver=null;clip=null;warmupStopped=true;} // do not retry a failed native call every frame
            }
        }
        private void Fail(string message){Stop();log.LogError("[AUDIO/FAIL] "+message);Failed?.Invoke(message);}
        public void Stop()
        {
            requested=false;running=false;times=null;moon=null;
            int stopping=used;used=0;
            for(int i=0;i<stopping&&i<voices.Count;i++)
            {
                try {if(voices[i]!=null)voices[i].Stop();}
                catch(Exception e){log.LogWarning("[AUDIO/STOP] Voice "+i+": "+e.Message);}
            }
            // Retain original clip / native source pool for the next click. Do not reload assets per click.
        }
        private void DestroyVoicePool()
        {
            foreach(var root in voiceRoots)
            {
                try {if(root!=null)Object.Destroy(root);}
                catch(Exception e){log.LogWarning("[AUDIO/DESTROY] "+e.Message);}
            }
            voices.Clear();voiceRoots.Clear();used=0;
        }
        public void Dispose()
        {
            if(disposed)return;Stop();disposed=true;resolver=null;
            DestroyVoicePool();clip=null; // never destroy the game's clip
        }
    }
}
