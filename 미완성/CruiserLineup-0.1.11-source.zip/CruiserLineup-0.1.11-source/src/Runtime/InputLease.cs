using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;

namespace CruiserLineup
{
    public sealed class GameInputTargets
    {
        public readonly HashSet<InputActionAsset> Assets=new HashSet<InputActionAsset>();
        public readonly HashSet<InputAction> Standalone=new HashSet<InputAction>();
        public bool Contains(InputAction action) => action!=null&&(Standalone.Contains(action)||
            (action.actionMap?.asset!=null&&Assets.Contains(action.actionMap.asset)));
        public bool Empty => Assets.Count==0&&Standalone.Count==0;
    }

    // The keyboard device is NEVER disabled: native input fields and Korean IME still receive text.
    // Existing Harmony callback guards block game actions; validated flags block polling.
    // Do not disable/re-enable InputActions: that mutates shared action maps and invokes
    // third-party synchronous callbacks. It is unnecessary for the modal guard.
    public sealed class InputLease
    {
        private readonly List<ButtonControl> closeHeldButtons=new List<ButtonControl>();
        private readonly ManualLogSource log;
        private GameBridge bridge;
        private Component player;
        private FieldInfo moveDisabled,lookDisabled,moveVector;
        private bool held,releasing,enforcing,ending,oldMoveDisabled,oldLookDisabled;
        private bool controlWarningLogged;
        private int skippedNullControls;
        private int releaseAfterFrame;

        public bool Held => held;
        public InputLease(ManualLogSource log) { this.log=log; }
        public void Acquire(GameBridge gameBridge)
        {
            if(ending) throw new InvalidOperationException("Input restoration is still in progress; retry opening the UI next frame.");
            if(gameBridge==null) throw new ArgumentNullException(nameof(gameBridge));
            if(held)
            {
                releasing=false; closeHeldButtons.Clear(); return;
            }
            var local=gameBridge.LocalPlayer;
            if(local==null) throw new InvalidOperationException("Local player is not ready for a modal input lease.");
            moveDisabled=CheckedField(local.GetType(),"disableMoveInput",typeof(bool));
            lookDisabled=CheckedField(local.GetType(),"disableLookInput",typeof(bool));
            moveVector=CheckedField(local.GetType(),"moveInputVector",typeof(Vector2));
            if(moveDisabled==null||lookDisabled==null||moveVector==null)
                throw new InvalidOperationException("Required player modal-input fields do not match this game; refusing to allow typing into gameplay.");
            bridge=gameBridge; player=local;
            oldMoveDisabled=(bool)moveDisabled.GetValue(player); oldLookDisabled=(bool)lookDisabled.GetValue(player);
            controlWarningLogged=false; skippedNullControls=0;

            held=true; releasing=false;
            try
            {
                InputSystem.onBeforeUpdate+=BeforeInputUpdate;
                Enforce();
            }
            catch { Release(); throw; }
            log.LogInfo("[INPUT/ACQUIRE] Callback/flag modal guard; changed InputActions=0; movement/look flags leased; keyboard/IME left enabled; native cursor writes=0.");
        }
        private static FieldInfo CheckedField(Type type,string name,Type expected)
        {
            var field=AccessTools.Field(type,name);
            return field!=null&&!field.IsStatic&&field.FieldType==expected?field:null;
        }
        // No native cursor lease. The private UI module uses a screen-space pointer
        // without competing with the game, other menus or Windows for cursor locking.
        private void BeforeInputUpdate()
        {
            if(!held) return;
            try { Enforce(); }
            catch(Exception e)
            {
                log.LogError("[INPUT/FAIL-OPEN] "+e);
                Release(); LineupRuntime.Current?.InputFault();
            }
        }
        public void Enforce()
        {
            if(!held||enforcing) return;
            enforcing=true;
            try
            {
                if(player==null||bridge.LocalPlayer!=player)
                    throw new InvalidOperationException("Local player changed during the modal input lease.");
                moveDisabled.SetValue(player,true); lookDisabled.SetValue(player,true);
                moveVector.SetValue(player,Vector2.zero);

            }
            finally { enforcing=false; }
        }
        // Input System 1.14.0 Keyboard.FinishSetup deliberately leaves a null entry
        // for IMESelected in allKeys. It is not a physical key, but the array includes it.
        // Never dereference an allKeys element (or an optional mouse control) without checking it.
        private bool IsPressedSafely(ButtonControl button)
        {
            if(button==null) return false;
            try
            {
                var device=button.device;
                return device!=null&&device.added&&button.isPressed;
            }
            catch(Exception e)
            {
                // A removed/rebuilt device must not trap the player in a modal input lease.
                // Warn once per acquisition; repeated probes must not spam per-frame logs.
                if(!controlWarningLogged)
                {
                    controlWarningLogged=true;
                    log.LogWarning("[INPUT/CONTROL-UNAVAILABLE] A button could not be read; it is not retained as held. "+e.GetType().Name+": "+e.Message);
                }
                return false;
            }
        }
        private void CaptureHeld(ButtonControl button)
        {
            if(button==null) { skippedNullControls++; return; }
            if(IsPressedSafely(button)&&!closeHeldButtons.Contains(button)) closeHeldButtons.Add(button);
        }
        // Keep genuine held keys/clicks blocked until released. No native cursor state is owned.
        // A snapshot/read/IME error cannot prevent the eventual release of actions and flags.
        public void BeginRelease()
        {
            if(!held||releasing||ending) return;
            releasing=true; releaseAfterFrame=Time.frameCount+1;
            closeHeldButtons.Clear(); skippedNullControls=0;
            try
            {
                // Snapshot device references once, so a current-device change cannot turn
                // a checked static property into a null dereference on its second read.
                var keyboard=Keyboard.current;
                var mouse=Mouse.current;
                var gamepad=Gamepad.current;
                if(keyboard!=null&&keyboard.added)
                    foreach(var key in keyboard.allKeys) CaptureHeld(key);
                if(mouse!=null&&mouse.added)
                {
                    CaptureHeld(mouse.leftButton); CaptureHeld(mouse.rightButton); CaptureHeld(mouse.middleButton);
                    CaptureHeld(mouse.forwardButton); CaptureHeld(mouse.backButton);
                }
                if(gamepad!=null&&gamepad.added)
                    foreach(var button in gamepad.allControls.OfType<ButtonControl>()) CaptureHeld(button);
                log.LogInfo("[INPUT/CLOSE] heldButtons="+closeHeldButtons.Count+"; skippedNullControls="+skippedNullControls+
                    "; waiting for real held controls only (IME placeholder excluded).");
            }
            catch(Exception e)
            {
                log.LogError("[INPUT/CLOSE-FAILOPEN] Failed to snapshot closing controls; restoring this mod's lease. "+e);
                Release();
            }
        }
        public void Tick()
        {
            if(!held) return;
            Enforce();
            if(releasing&&Time.frameCount>releaseAfterFrame&&
               closeHeldButtons.All(b=>!IsPressedSafely(b))) Release();
        }
        private void RestorePlayerField(FieldInfo field,object value,bool onlyIfTrue)
        {
            if(player==null||field==null) return;
            try
            {
                if(!onlyIfTrue||(bool)field.GetValue(player)) field.SetValue(player,value);
            }
            catch(Exception e) { log.LogWarning("[INPUT/FLAG-RESTORE] "+field.Name+": "+e.Message); }
        }
        public void Release()
        {
            if(!held||ending) return;
            ending=true;
            // Remove this mod's enforcement first. There is no InputAction.Enable()/Disable()
            // loop and no action-map restoration callback to block the Unity main thread.
            held=false; releasing=false; InputSystem.onBeforeUpdate-=BeforeInputUpdate;
            HangTrace.Note("INPUT/RELEASE-BEGIN");
            try
            {
                // Do not restore the old movement vector: its keys may already have been released.
                RestorePlayerField(moveVector,Vector2.zero,false);
                RestorePlayerField(moveDisabled,oldMoveDisabled,true);
                RestorePlayerField(lookDisabled,oldLookDisabled,true);

            }
            finally
            {
                closeHeldButtons.Clear();
                releasing=false; bridge=null; player=null;
                moveDisabled=lookDisabled=moveVector=null; ending=false;
            }
            HangTrace.Note("INPUT/RELEASE-END");
            log.LogInfo("[INPUT/RELEASE] Callback/flag lease cleared; changed InputActions=0; modal subscription removed.");
        }
    }

}
