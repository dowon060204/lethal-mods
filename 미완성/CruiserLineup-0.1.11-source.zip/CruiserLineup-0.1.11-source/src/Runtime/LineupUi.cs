using System;
using System.Collections;
using System.Globalization;
using System.Linq;
using CruiserLineup.Core;
using UiLabel = UnityEngine.UI.Text;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object=UnityEngine.Object;

namespace CruiserLineup
{
    // Native retained uGUI Text/InputField; no TMP font assets, OnGUI, custom TTF or per-frame font creation.
    // The visual tree is built once. Text/active/interactable properties change only when necessary.
    public sealed partial class LineupRuntime
    {
        private readonly UiCommandQueue uiCommands=new UiCommandQueue();
        private GameObject uiRoot,modalRoot,toastRoot,gridRoot,editorRoot,confirmRoot,footerRoot,ownedEventRoot;
        private RectTransform panelRect, pointerRect;
        private EventSystem previousEventSystem;
        private UiPointerModule pointerModule;
        private CanvasGroup mainUiGroup;
        private UiLabel titleLabel,statusLabel,toastLabel,unknownLabel,stepLabel,editorHelp,recordLabel,poseLabel;
        private InputField nameField,instructionsField;
        private GameObject namePage,posePage,timingPage,instructionsPage;
        private ButtonView closeButton,backButton,previousButton,nextButton,discardButton,savePoseButton,recordStartButton,recordStopButton,recordListenButton;
        private ButtonView clearButton,stopButton,reorderButton,cancelDeleteButton,deleteButton;
        private ButtonView[] stepButtons;
        private readonly SlotView[] slotViews=new SlotView[8];
        private Draft shownDraft;
        private bool syncingUi;
        private int uiWidth,uiHeight;
        private double nextUiSync,nextEventCheck;
        private bool eventWarningLogged;
        private static readonly Color Green=new Color(.48f,1f,.39f,1f), Orange=new Color(1f,.56f,.24f,1f);
        private static readonly Color Muted=new Color(.65f,.74f,.62f,1f), PanelColor=new Color(.014f,.028f,.018f,.99f);
        private sealed class ButtonView { public Button Button; public UiLabel Label; public GameObject Root=>Button.gameObject; }
        private sealed class SlotView
        {
            public GameObject Root; public Image Selection; public UiLabel Name;
            public ButtonView Add,Load,Listen,Edit,Delete,Move;
        }
        private static void Active(GameObject go,bool value) { if(go!=null&&go.activeSelf!=value) go.SetActive(value); }
        private static void Text(UiLabel label,string value) { if(label!=null&&label.text!=(value??"")) label.text=value??""; }
        private static void Caption(ButtonView button,string value,bool enabled=true)
        { Text(button.Label,value); if(button.Button.interactable!=enabled) button.Button.interactable=enabled; }
        private static RectTransform Rect(Transform parent,string name,float x,float y,float w,float h)
        {
            var go=new GameObject(name,typeof(RectTransform)); go.transform.SetParent(parent,false); go.layer=parent.gameObject.layer;
            var r=(RectTransform)go.transform; r.anchorMin=r.anchorMax=r.pivot=new Vector2(0,1);
            r.anchoredPosition=new Vector2(x,-y); r.sizeDelta=new Vector2(w,h); return r;
        }
        private static void Stretch(RectTransform r)
        { r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=r.offsetMax=Vector2.zero; }
        private Image Box(Transform parent,string name,float x,float y,float w,float h,Color colour,bool raycast=false)
        {
            var r=Rect(parent,name,x,y,w,h); var image=r.gameObject.AddComponent<Image>();
            image.color=colour; image.raycastTarget=raycast; return image;
        }
        private void Outline(Transform parent,float w,float h,Color colour,float t=1)
        { Box(parent,"top",0,0,w,t,colour);Box(parent,"bottom",0,h-t,w,t,colour);Box(parent,"left",0,0,t,h,colour);Box(parent,"right",w-t,0,t,h,colour); }
        private UiLabel Label(Transform parent,string name,float x,float y,float w,float h,int size=23,bool centre=false)
        {
            var r=Rect(parent,name,x,y,w,h);var t=r.gameObject.AddComponent<LineupUiText>();
            t.font=systemText.Get(); t.fontSize=size; t.color=Green; t.supportRichText=false;
            t.resizeTextForBestFit=false; t.horizontalOverflow=HorizontalWrapMode.Wrap;
            t.raycastTarget=false;t.alignment=centre?TextAnchor.MiddleCenter:TextAnchor.UpperLeft;
            t.verticalOverflow=VerticalWrapMode.Truncate;return t;
        }
        private ButtonView MakeButton(Transform parent,string name,float x,float y,float w,float h,Action action,int size=23)
        {
            var bg=Box(parent,name,x,y,w,h,new Color(.04f,.12f,.035f,1),true);Outline(bg.transform,w,h,Green);
            var b=bg.gameObject.AddComponent<Button>(); b.targetGraphic=bg;
            var colours=b.colors;colours.normalColor=Color.white;colours.highlightedColor=new Color(1.3f,1.5f,1.2f,1);
            colours.pressedColor=new Color(.7f,.8f,.6f,1);colours.disabledColor=new Color(.35f,.35f,.35f,1);b.colors=colours;
            b.navigation=new Navigation{mode=Navigation.Mode.None};
            var label=Label(bg.transform,"caption",6,2,w-12,h-4,size,true);
            b.onClick.AddListener(()=>QueueUiCommand(name,action));return new ButtonView{Button=b,Label=label};
        }
        private void QueueUiCommand(string name,Action action)
        {
            if(!visible||disposed||Plugin.Quitting) return;
            if(uiCommands.Enqueue(name,action)) HangTrace.Note("UI/CLICK "+name);
        }
        private void ProcessUiCommand()
        {
            if(!uiCommands.TryTake(out var name,out var action)) return;
            if(!visible||!Bridge.Alive) return;
            HangTrace.Note("UI/COMMAND-BEGIN "+name);
            try { action(); }
            catch(Exception e) { log.LogError("[UI/COMMAND] "+name+": "+e); SetStatus(L("요청 처리 실패: ","Request failed: ")+e.Message); }
            finally { HangTrace.Note("UI/COMMAND-END "+name); nextUiSync=0; }
        }
        private InputField Field(Transform parent,string name,float x,float y,float w,float h,int limit,bool multiline,Action<string> changed)
        {
            var bg=Box(parent,name,x,y,w,h,new Color(.012f,.025f,.015f,1),true);Outline(bg.transform,w,h,Green);
            var viewport=Rect(bg.transform,"viewport",12,8,w-24,h-16);viewport.gameObject.AddComponent<RectMask2D>();
            var text=Label(viewport,"text",0,0,w-24,h-16,25);Stretch(text.rectTransform);
            text.verticalOverflow=VerticalWrapMode.Overflow;
            text.horizontalOverflow=multiline?HorizontalWrapMode.Wrap:HorizontalWrapMode.Overflow;
            var f=bg.gameObject.AddComponent<InputField>();f.targetGraphic=bg;f.textComponent=text;
            f.characterLimit=limit; f.contentType=InputField.ContentType.Standard;
            f.navigation=new Navigation {mode=Navigation.Mode.None};
            f.lineType=multiline?InputField.LineType.MultiLineNewline:InputField.LineType.SingleLine;
            f.customCaretColor=true;f.caretColor=Green;f.selectionColor=new Color(.25f,.45f,.2f,.7f);
            f.onValueChanged.AddListener(value=> {if(!syncingUi&&visible&&ActiveDraft!=null) {changed(value);Touch();}});
            return f;
        }
        private IEnumerator BuildRetainedUi()
        {
            // Every yield is a separate Update. No coroutine runs while a UI callback is on the stack.
            HangTrace.Note("UI/TEXT-BEGIN system-fallback");
            systemText.Get();
            HangTrace.Note("UI/TEXT-END koreanSample="+systemText.KoreanSampleSupported);
            yield return null;
            HangTrace.Note("UI/BUILD-BEGIN native-uGUI-text");
            uiRoot=new GameObject("CruiserLineup.UI",typeof(RectTransform),typeof(Canvas),typeof(GraphicRaycaster));
            uiRoot.SetActive(false); uiRoot.layer=5;
            // Independent root: the runtime owner is intentionally hidden with HideFlags.
            Object.DontDestroyOnLoad(uiRoot);
            var canvas=uiRoot.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.sortingOrder=31000;
            modalRoot=Rect(uiRoot.transform,"modal",0,0,1,1).gameObject;Stretch((RectTransform)modalRoot.transform);
            var shade=Box(modalRoot.transform,"shade",0,0,1,1,new Color(0,0,0,.68f),true);Stretch((RectTransform)shade.transform);
            panelRect=Rect(modalRoot.transform,"panel",0,0,1200,720);
            panelRect.anchorMin=panelRect.anchorMax=panelRect.pivot=new Vector2(.5f,.5f);
            var panel=panelRect.gameObject.AddComponent<Image>();panel.color=PanelColor;panel.raycastTarget=true;Outline(panelRect,1200,720,Orange,2);
            titleLabel=Label(panelRect,"title",28,23,1040,50,31);
            closeButton=MakeButton(panelRect,"close",1090,22,82,42,()=>CloseUi(),18);
            Box(panelRect,"separator",28,82,1144,1,Orange);
            var main=Rect(panelRect,"content",0,84,1200,564);mainUiGroup=main.gameObject.AddComponent<CanvasGroup>();
            gridRoot=Rect(main,"grid",0,0,1200,564).gameObject;
            unknownLabel=Label(gridRoot.transform,"unknown",45,35,1100,160);
            yield return null;
            for(int display=0;display<8;display++)
            {
                int pos=display;float x=28+(pos%4)*290,y=20+(pos/4)*245;
                var card=Box(gridRoot.transform,"slot"+pos,x,y,274,225,new Color(.025f,.055f,.03f,1));Outline(card.transform,274,225,Green);
                var v=new SlotView{Root=card.gameObject};slotViews[pos]=v;
                v.Selection=Box(card.transform,"selection",0,0,274,3,Orange);
                v.Name=Label(card.transform,"name",12,12,250,65,24,true);
                v.Add=MakeButton(card.transform,"add-"+pos,13,14,248,196,()=>BeginEdit(slotOrder[pos]));
                v.Load=MakeButton(card.transform,"load-"+pos,16,87,242,44,()=>LoadSlot(slotOrder[pos]));
                v.Listen=MakeButton(card.transform,"listen-"+pos,16,139,242,40,()=>Listen(snapshot[slotOrder[pos]]));
                v.Edit=MakeButton(card.transform,"edit-"+pos,16,187,116,28,()=>BeginEdit(slotOrder[pos]),18);
                v.Delete=MakeButton(card.transform,"delete-"+pos,142,187,116,28,()=>RequestDelete(slotOrder[pos]),18);
                v.Move=MakeButton(card.transform,"move-"+pos,16,151,242,52,()=>ReorderAt(pos),18);
                HangTrace.Note("UI/BUILD-SLOT "+pos);
                yield return null;
            }
            editorRoot=Rect(main,"editor",0,0,1200,564).gameObject;
            stepLabel=Label(editorRoot.transform,"step",32,19,880,38);
            backButton=MakeButton(editorRoot.transform,"back-slots",947,16,222,36,()=>ShowGrid(),18);
            stepButtons=new ButtonView[4];
            for(int i=0;i<4;i++){int step=i;stepButtons[i]=MakeButton(editorRoot.transform,"step-"+step,32+step*285,66,270,42,()=>{if(ActiveDraft!=null&&recordingDraft==null){ActiveDraft.Step=step;Touch();}},18);}
            yield return null;
            namePage=Rect(editorRoot.transform,"name-page",0,119,1200,360).gameObject;
            editorHelp=Label(namePage.transform,"help",48,0,1104,60);nameField=Field(namePage.transform,"name-input",48,76,1104,66,Guard.MaxName,false,value=>ActiveDraft.Data.Name=value);
            yield return null;
            posePage=Rect(editorRoot.transform,"pose-page",0,119,1200,360).gameObject;
            poseLabel=Label(posePage.transform,"pose",48,0,1104,230);
            savePoseButton=MakeButton(posePage.transform,"capture-pose",48,263,1104,52,CapturePosition);
            yield return null;
            timingPage=Rect(editorRoot.transform,"timing-page",0,119,1200,360).gameObject;
            recordLabel=Label(timingPage.transform,"timing-text",48,0,1104,243,21);
            recordStartButton=MakeButton(timingPage.transform,"record-start",48,275,350,48,StartRecording);
            recordStopButton=MakeButton(timingPage.transform,"record-stop",421,275,350,48,()=>FinishRecording(false));
            recordListenButton=MakeButton(timingPage.transform,"record-listen",794,275,358,48,()=>Listen(ActiveDraft?.Data));
            yield return null;
            instructionsPage=Rect(editorRoot.transform,"instructions-page",0,119,1200,360).gameObject;
            var instructionHelp=Label(instructionsPage.transform,"hint",48,0,1104,46,18);
            // language-dependent hint is updated with the other controls, not recreated.
            instructionsHint=instructionHelp;
            instructionsField=Field(instructionsPage.transform,"instructions-input",48,52,1104,285,Guard.MaxInstructions,true,value=>ActiveDraft.Data.Instructions=value);
            previousButton=MakeButton(editorRoot.transform,"previous",48,499,168,43,()=>{if(ActiveDraft!=null&&ActiveDraft.Step>0){ActiveDraft.Step--;Touch();}});
            discardButton=MakeButton(editorRoot.transform,"discard",239,499,230,43,DiscardDraft,18);
            nextButton=MakeButton(editorRoot.transform,"next-save",947,499,201,43,()=>{if(ActiveDraft==null)return;if(ActiveDraft.Step<3){ActiveDraft.Step++;Touch();}else CommitDraft();});
            yield return null;
            footerRoot=Rect(main,"footer",0,522,1200,42).gameObject;
            clearButton=MakeButton(footerRoot.transform,"clear-overlay",28,0,216,36,()=>ghost.Clear(),18);
            stopButton=MakeButton(footerRoot.transform,"stop-audio",258,0,216,36,()=>{pendingPreview=null;audio.Stop();SetStatus("");},18);
            reorderButton=MakeButton(footerRoot.transform,"reorder",489,0,229,36,ToggleReorder,18);
            footerHint=Label(footerRoot.transform,"hint",740,6,432,32,18);footerHint.color=Muted;
            Box(panelRect,"status-line",28,653,1144,1,Orange);statusLabel=Label(panelRect,"status",30,662,1140,50,18);statusLabel.color=Muted;
            yield return null;
            confirmRoot=Rect(panelRect,"confirmation",0,84,1200,636).gameObject;
            Box(confirmRoot.transform,"veil",0,0,1200,636,new Color(0,0,0,.85f),true);
            var confirm=Box(confirmRoot.transform,"box",250,161,700,238,new Color(.055f,.055f,.025f,1),true);Outline(confirm.transform,700,238,Orange,2);
            confirmLabel=Label(confirm.transform,"text",25,22,650,110);
            cancelDeleteButton=MakeButton(confirm.transform,"cancel-delete",30,158,290,48,()=>deleteSlot=-1);
            deleteButton=MakeButton(confirm.transform,"confirm-delete",344,158,326,48,ConfirmDelete);
            toastRoot=Box(uiRoot.transform,"toast",16,16,1050,76,PanelColor).gameObject;Outline(toastRoot.transform,1050,76,Orange);
            toastLabel=Label(toastRoot.transform,"text",12,10,1026,57,23);
            // Drawn pointer, not a Windows cursor. Images do not participate in raycasts.
            pointerRect=Rect(uiRoot.transform,"pointer",0,0,18,24);
            Box(pointerRect,"stem",0,0,3,18,Green);Box(pointerRect,"cap",0,0,12,3,Green);
            Box(pointerRect,"tip",3,3,3,9,Green);
            Active(pointerRect.gameObject,false);
            Active(modalRoot,false);Active(toastRoot,false);uiRoot.SetActive(true);uiWidth=uiHeight=0;
            uiReady=true;
            HangTrace.Note("UI/BUILD-END native-uGUI-text");
            log.LogInfo("[UI/BACKEND] Retained uGUI Text/InputField; one cached OS default Hangul fallback; no TMP UI, TTF loading, global font patch or font installation.");
        }
        private UiLabel instructionsHint,footerHint,confirmLabel;
        private void EnsureEventSystem()
        {
            if(ownedEventRoot!=null&&ownedEventRoot.activeSelf)
            {
                if(EventSystem.current!=ownedEventRoot.GetComponent<EventSystem>())
                    RequestUiSafetyClose("Another menu took UI focus; this modal yielded without changing its input modules.");
                return;
            }
            previousEventSystem=EventSystem.current;
            if(ownedEventRoot==null)
            {
                ownedEventRoot=new GameObject("CruiserLineup.UIEvents");ownedEventRoot.SetActive(false);
                Object.DontDestroyOnLoad(ownedEventRoot);
                var events=ownedEventRoot.AddComponent<EventSystem>();events.sendNavigationEvents=false;
                pointerModule=ownedEventRoot.AddComponent<UiPointerModule>();
            }
            Active(ownedEventRoot,true);
            EventSystem.current=ownedEventRoot.GetComponent<EventSystem>();
            pointerModule.Begin(uiRoot.GetComponent<GraphicRaycaster>(),pointerRect);
            HangTrace.Note("UI/EVENTS-ACQUIRED nativeCursorWrites=0; otherModulesModified=0");
        }
        private void ReleaseEventSystem()
        {
            bool restore=ownedEventRoot!=null&&EventSystem.current==ownedEventRoot.GetComponent<EventSystem>();
            try
            {
                if(ownedEventRoot!=null)
                {
                    var system=ownedEventRoot.GetComponent<EventSystem>();
                    if(system!=null&&system.currentSelectedGameObject!=null)system.SetSelectedGameObject(null);
                }
            }
            finally
            {
                Active(ownedEventRoot,false);
                if(restore&&previousEventSystem!=null&&previousEventSystem.isActiveAndEnabled)EventSystem.current=previousEventSystem;
                previousEventSystem=null;
                if(pointerRect!=null)Active(pointerRect.gameObject,false);
            }
        }
        private void HideRetainedUi()
        {
            uiCommands.Invalidate();
            try { ReleaseEventSystem(); }
            finally { Active(modalRoot,false);shownDraft=null; }
        }
        private void TickRetainedUi()
        {
            if(!uiReady||uiFaulted||uiRoot==null) return;
            if(uiWidth!=Screen.width||uiHeight!=Screen.height)
            {
                uiWidth=Screen.width;uiHeight=Screen.height;
                float scale=Mathf.Max(.1f,Mathf.Min((uiWidth-24)/1200f,(uiHeight-24)/720f));panelRect.localScale=new Vector3(scale,scale,1);
                ((RectTransform)toastRoot.transform).localScale=new Vector3(Mathf.Min(1,(uiWidth-32)/1050f),1,1);
            }
            if(!visible) Active(modalRoot,false);
            bool toast=!visible&&(recordingDraft!=null||(!string.IsNullOrEmpty(status)&&Time.realtimeSinceStartupAsDouble<statusUntil));Active(toastRoot,toast);
            if(toast) Text(toastLabel,recordingDraft!=null?L("● 녹화 중 · ","● RECORDING · ")+recorder.Count+L("회 | F10 → 녹화 종료"," inputs | F10 → Stop recording"):status);
            if(!visible||Time.realtimeSinceStartupAsDouble<nextUiSync) return;nextUiSync=Time.realtimeSinceStartupAsDouble+.1;
            HangTrace.Stage("ui/sync");
            if(Time.realtimeSinceStartupAsDouble>=nextEventCheck)
            {
                nextEventCheck=Time.realtimeSinceStartupAsDouble+1;
                try { EnsureEventSystem(); }
                catch(Exception e)
                {
                    if(!eventWarningLogged) { eventWarningLogged=true; log.LogWarning("[UI/EVENTSYSTEM] "+e); }
                    RequestUiSafetyClose("UI event connection failed: "+e.GetType().Name);
                }
            }
            syncingUi=true;
            try
            {
                Text(titleLabel,(uiMoon==null?unknownMoon:UseKorean?uiMoon.Korean:uiMoon.English)+L(" 라인업 오버레이"," LINEUP OVERLAY"));
                Caption(closeButton,L("닫기","Close"));bool writable=!repository.ReadOnly&&!workspaceReadOnly;
                var draft=ActiveDraft;bool recording=recordingDraft!=null;bool known=uiMoon!=null;
                Active(gridRoot,draft==null);Active(editorRoot,draft!=null);Active(footerRoot,draft==null);Active(unknownLabel.gameObject,!known);
                Text(unknownLabel,L("지원 슬롯이 없는 위성입니다. 다른 위성으로 이동한 뒤 다시 열어주세요.","Unsupported moon. Route a supported moon and reopen."));
                for(int pos=0;pos<8;pos++)
                {
                    var v=slotViews[pos];Active(v.Root,known);if(!known)continue;
                    int id=slotOrder[pos];var d=snapshot[id];var pending=workspace.Find(uiMoon.Key,id);
                    Active(v.Selection.gameObject,reorderMode&&reorderFrom==pos);Active(v.Name.gameObject,reorderMode||d!=null);
                    Text(v.Name,d?.Name??pending?.Data.Name??L("빈 슬롯","Empty slot"));
                    Active(v.Add.Root,!reorderMode&&d==null);Active(v.Load.Root,!reorderMode&&d!=null);Active(v.Listen.Root,!reorderMode&&d!=null);
                    Active(v.Edit.Root,!reorderMode&&d!=null);Active(v.Delete.Root,!reorderMode&&d!=null);Active(v.Move.Root,reorderMode);
                    Caption(v.Add,pending!=null?L("작성 이어하기","Resume draft"):L("슬롯\n추가하기","Add\nslot"),writable);
                    Caption(v.Load,L("불러오기","Load"));Caption(v.Listen,L("타이밍 듣기","Listen timing"));Caption(v.Edit,pending!=null?L("수정 계속","Resume edit"):L("수정","Edit"),writable);
                    Caption(v.Delete,L("삭제","Delete"),writable);Caption(v.Move,reorderFrom==pos?L("선택 취소","Deselect"):reorderFrom<0?L("이동할 슬롯 선택","Select slot"):L("여기로 이동","Move here"),writable);
                }
                if(draft!=null)
                {
                    var steps=new[]{L("이름 짓기","Name"),L("위치 저장","Capture pose"),L("점프 타이밍 녹화","Record timing"),L("점프 순서 적기","Instructions")};
                    Text(stepLabel,(Array.IndexOf(slotOrder,draft.Slot)+1)+" / 8    "+(draft.Step+1)+". "+steps[draft.Step]);
                    for(int i=0;i<4;i++) Caption(stepButtons[i],(i+1)+". "+steps[i],!recording);
                    Caption(backButton,L("슬롯 목록으로","Back to slots"),!recording);
                    Active(namePage,draft.Step==0);Active(posePage,draft.Step==1);Active(timingPage,draft.Step==2);Active(instructionsPage,draft.Step==3);
                    Text(editorHelp,L("라인업 이름을 입력해주세요. 입력 중에는 게임 조작이 차단됩니다.","Enter a lineup name. Gameplay input is blocked while this window is open."));
                    if(shownDraft!=draft||!nameField.isFocused) if(nameField.text!=draft.Data.Name)nameField.SetTextWithoutNotify(draft.Data.Name);
                    if(shownDraft!=draft||!instructionsField.isFocused) if(instructionsField.text!=draft.Data.Instructions)instructionsField.SetTextWithoutNotify(draft.Data.Instructions);
                    shownDraft=draft;nameField.interactable=instructionsField.interactable=writable;
                    var pose=draft.Data.Pose;Text(poseLabel,pose==null?L("크루저를 원하는 곳에 둔 뒤 ‘위치 저장’을 누르세요.","Position the Cruiser and press Capture pose."):
                        L("저장된 위치: ","Position: ")+VectorText(pose.Position)+"\n"+L("방향: ","Rotation: ")+VectorText(pose.RotationEuler));
                    Caption(savePoseButton,L("위치 저장","Capture pose"),writable);
                    Text(recordLabel,(recording?L("녹화 중","Recording"):L("점프 입력을 녹화합니다.","Record actual jump inputs."))+"\n"+
                        L("녹화 시작 → 점프 → F10 → 녹화 종료\n첫 입력은 0ms, 이후 간격을 저장합니다.\n","Start → jump → F10 → Stop.\nThe first input is 0 ms; subsequent offsets are preserved.\n")+
                        L("저장된 입력: ","Recorded inputs: ")+draft.Data.JumpTimesMs.Count+"\n"+string.Join(" · ",draft.Data.JumpTimesMs.Take(28).Select(t=>t+"ms")));
                    Caption(recordStartButton,L("녹화 시작","Start recording"),writable&&!recording);Caption(recordStopButton,L("녹화 종료","Stop recording"),recording);
                    Caption(recordListenButton,L("타이밍 듣기","Listen timing"),!recording&&draft.Data.JumpTimesMs.Count>0);
                    Text(instructionsHint,L("불러오기 시 본인 채팅에 표시할 점프 방법을 입력하세요.","Enter the jump instructions to show in your local chat on Load."));
                    Caption(previousButton,L("이전","Back"),writable&&!recording&&draft.Step>0);Caption(discardButton,L("임시 편집 취소","Discard draft"),writable&&!recording);
                    bool canNext=draft.Step==0?!string.IsNullOrWhiteSpace(draft.Data.Name):draft.Step==1?pose!=null:draft.TimingComplete;
                    Caption(nextButton,draft.Step==3?L("슬롯 저장","Save slot"):L("다음","Next"),writable&&!recording&&canNext);
                }
                Caption(clearButton,L("오버레이 지우기","Clear overlay"),ghost.Active);Caption(stopButton,L("소리 정지","Stop sound"));
                Caption(reorderButton,reorderMode?L("순서 변경 완료","Finish reordering"):L("순서 변경","Reorder slots"),known&&writable&&!recording);
                Text(footerHint,L("F10 열기 / 닫기 · 개인 설정","F10 open / close · Local only"));
                string message=Time.realtimeSinceStartupAsDouble<statusUntil?status:"";
                if(message.Length==0&&known&&Bridge.CurrentMoon?.Key!=uiMoon.Key)message=L("위성이 변경되었습니다. 다시 열면 새 위성이 적용됩니다.","Moon changed. Reopen to load its slots.");
                if(message.Length==0)message=L("위성별 8개 슬롯 · 내용은 재실행 후에도 유지됩니다.","8 slots per moon · Saved data persists across restarts.");
                Text(statusLabel,message);Active(confirmRoot,deleteSlot>=0);mainUiGroup.interactable=mainUiGroup.blocksRaycasts=deleteSlot<0;
                Text(confirmLabel,L("이 슬롯을 삭제할까요?\n임시 편집 내용도 함께 삭제됩니다.","Delete this slot?\nIts pending draft will also be removed."));
                Caption(cancelDeleteButton,L("취소","Cancel"));Caption(deleteButton,L("삭제","Delete"),writable);
                // Activate only after the correct view/text is populated. No transient editor activation.
                Active(modalRoot,visible);
            }
            finally {syncingUi=false;HangTrace.Stage("ui/sync-end");}
        }
        private static string VectorText(Vec3 v)=>string.Format(CultureInfo.InvariantCulture,"{0:0.000} / {1:0.000} / {2:0.000}",v.X,v.Y,v.Z);
        private void DestroyUiResources()
        {
            uiBuild.Cancel(); uiReady=false; openWhenUiReady=false; uiFaulted=false; uiRenderFault=null;
            try { HideRetainedUi(); }
            finally
            {
                if(uiRoot!=null) { uiRoot.SetActive(false); Object.Destroy(uiRoot); }
                if(ownedEventRoot!=null) { ownedEventRoot.SetActive(false); Object.Destroy(ownedEventRoot); }
                uiRoot=ownedEventRoot=null; panelRect=pointerRect=null; pointerModule=null; previousEventSystem=null; mainUiGroup=null;
            }
        }
    }
}
