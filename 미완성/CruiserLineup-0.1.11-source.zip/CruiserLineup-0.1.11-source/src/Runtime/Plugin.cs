using System;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using CruiserLineup.Core;
using UnityEngine;
using UnityEngine.InputSystem;

namespace CruiserLineup
{
    public enum UiLanguage { Korean, English }
    public sealed class Settings
    {
        public readonly ConfigFile File;
        public readonly ConfigEntry<UiLanguage> Language;
        public readonly ConfigEntry<Key> ToggleKey;
        public readonly ConfigEntry<float> Opacity, Volume;
        public readonly ConfigEntry<bool> PreventConsoleSelection, HangDiagnostics, OverlayEnabled;
        public Settings(ConfigFile file)
        {
            File=file;
            PreventConsoleSelection=file.Bind("Diagnostics","PreventConsoleSelection",true,"Prevent QuickEdit mouse selection on this game's dedicated Windows console only. Temporary; no BepInEx.cfg or registry edits. Applies next launch.");
            HangDiagnostics=file.Bind("Diagnostics","HangDiagnostics",true,"Write bounded CruiserLineup.trace.log independently of console logging; record stage and console-selection state after an Update gap. Applies next launch.");
            Language=file.Bind("General","Language",UiLanguage.Korean,"Korean = 한국어, English = 영어. Applies when the UI opens.");
            ToggleKey=file.Bind("General","ToggleKey",Key.F10,"Open/close the lineup UI. This is a physical UI shortcut, not the Cruiser jump binding.");
            OverlayEnabled=file.Bind("Overlay","Enabled",true,"Local vehicle preview rendering. False completely skips mesh capture, shader lookup and material creation, but preserves the UI, audio, slots and local chat instructions. Reload when F10 opens.");
            Opacity=file.Bind("Overlay","Opacity",OverlayStyle.DefaultOpacity,new ConfigDescription("0.25 = 25% visible / 75% see-through. Recommended: 0.20 to 0.30. Reloaded when F10 opens; applies to the existing overlay. Local-only.",new AcceptableValueRange<float>(OverlayStyle.MinimumOpacity,OverlayStyle.MaximumOpacity)));
            Volume=file.Bind("Audio","Volume",0.8f,new ConfigDescription("Local timing playback volume.",new AcceptableValueRange<float>(0f,1f)));
        }
    }
    [BepInPlugin(Guid,Name,Version)]
    public sealed class Plugin : BaseUnityPlugin
    {
        public const string Guid="com.cruiserlineup.mod", Name="CruiserLineup", Version="0.1.11";
        internal static bool Quitting;
        private GameObject runtimeRoot;
        private void Awake()
        {
            if(Quitting||LineupRuntime.Current!=null) return;
            var preferences=new Settings(Config);
            var ownConsole=new ConsoleModeLease(); ownConsole.Acquire(preferences.PreventConsoleSelection.Value);
            Logger.LogInfo("[LOAD] "+Name+" "+Version+" / "+Assembly.GetExecutingAssembly().Location);
            Logger.LogInfo("[CONSOLE/GUARD] "+ownConsole.Result);
            try
            {
                // Protect our own independent root BEFORE adding any running component.
                // Do not change BepInEx's shared manager or its global config.
                runtimeRoot=new GameObject(Name+".Runtime");
                runtimeRoot.SetActive(false);
                runtimeRoot.hideFlags=HideFlags.HideAndDontSave;
                DontDestroyOnLoad(runtimeRoot);
                var runtime=runtimeRoot.AddComponent<LineupRuntime>();
                runtime.Initialize(preferences,Logger,Path.GetDirectoryName(Info.Location),ownConsole);
                runtimeRoot.SetActive(true);
            }
            catch(Exception e)
            {
                ownConsole.Dispose();
                Logger.LogError("[FATAL/LOAD] "+e);
                if(runtimeRoot!=null) Destroy(runtimeRoot);
            }
        }
        private void OnEnable() { if(!Quitting) Logger.LogInfo("[LIFECYCLE] Plugin OnEnable; runtime owns its own lifecycle."); }
        private void OnDisable() { if(!Quitting) Logger.LogWarning("[LIFECYCLE] Plugin OnDisable; independent runtime is not permanently disabled."); }
        private void OnDestroy()
        {
            // The BepInEx manager can be cleaned up independently. No static Plugin reference is kept.
            if(!Quitting) Logger.LogWarning("[LIFECYCLE] Plugin OnDestroy; existing independent runtime remains responsible for its resources.");
        }
        private void OnApplicationQuit() { Quitting=true; }
    }
}
