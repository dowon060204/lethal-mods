using System;
using CruiserLineup.Core;
using UnityEngine;

namespace CruiserLineup
{
    public sealed partial class LineupRuntime
    {
        private readonly UiFrameBuild uiBuild=new UiFrameBuild();
        private SystemUiText systemText;
        private bool uiReady,openWhenUiReady,uiFaulted;
        private double nextBuildAllowed;
        private string uiRenderFault;
        private bool UseKorean => language==UiLanguage.Korean&&
            (systemText==null||!systemText.Attempted||systemText.KoreanSampleSupported);
        private void CancelPendingUiOpen() {openWhenUiReady=false;}
        // Called from a mesh callback: no Unity mutations or console IO here.
        public void RequestUiSafetyClose(string reason)
        { if(!uiFaulted&&uiRenderFault==null) {uiRenderFault=reason??"UI render guard tripped.";HangTrace.Note("UI/RENDER-GUARD "+uiRenderFault);} }
        private void EnsureRetainedUi()
        {
            if(uiReady||uiBuild.Running||disposed||Plugin.Quitting) return;
            if(Time.realtimeSinceStartupAsDouble<nextBuildAllowed) {openWhenUiReady=false;return;}
            LineupUiText.ResetFault();
            uiBuild.Begin(BuildRetainedUi());
        }
        private void TickUiPreparation()
        {
            if(uiRenderFault!=null)
            {
                string reason=uiRenderFault;uiRenderFault=null;uiFaulted=true;
                CloseUi(true); if(uiRoot!=null) uiRoot.SetActive(false); log.LogError("[UI/RENDER-FAILOPEN] "+reason+" Input restored; no automatic reopen loop.");
                return;
            }
            if(uiBuild.Running)
            {
                HangTrace.Stage("ui/build-step");uiBuild.Tick(Time.frameCount);
                if(uiBuild.Error!=null)
                {
                    var error=uiBuild.Error;
                    DestroyUiResources(); nextBuildAllowed=Time.realtimeSinceStartupAsDouble+5;
                    log.LogError("[UI/BUILD-FAILED] "+error+" No input lease was taken. F10 may retry after 5 seconds.");
                    return;
                }
            }
            if(openWhenUiReady&&uiReady) {openWhenUiReady=false;OpenUi();}
        }
    }
}
