using System;
using System.Collections.Generic;
using BepInEx.Logging;
using CruiserLineup.Core;
using UnityEngine;

namespace CruiserLineup
{
    // The HUD's own TextMeshPro font is never inspected, cloned or modified.
    public sealed class LocalChat
    {
        private sealed class Pending { public string Text; public long Session; public double Expires; }
        private readonly Queue<Pending> queue=new Queue<Pending>();
        private readonly ManualLogSource log;
        private readonly GameBridge bridge;
        private double next;
        public LocalChat(GameBridge bridge,ManualLogSource log) { this.bridge=bridge; this.log=log; }
        public void Enqueue(Lineup data,long session)
        {
            foreach(var line in ChatLines.Split(data.Name,data.Instructions))
            {
                if(queue.Count>=128) queue.Dequeue();
                queue.Enqueue(new Pending { Text=line,Session=session,Expires=Time.realtimeSinceStartupAsDouble+60 });
            }
            log.LogInfo("[CHAT/QUEUE] Local instructions queued; chunks="+queue.Count+", session="+session);
        }
        public void Tick(long session)
        {
            var now=Time.realtimeSinceStartupAsDouble;
            if(now<next) return; next=now+0.15;
            while(queue.Count>0&&(queue.Peek().Session!=session||queue.Peek().Expires<now)) queue.Dequeue();
            if(queue.Count==0||bridge.Hud==null) return;
            if(bridge.ChatMethod==null) { log.LogError("[CHAT] Local chat API unavailable. Instructions remain in slot; not broadcast."); queue.Clear(); return; }
            var item=queue.Dequeue();
            // Exactly one attempt per chunk prevents duplicate history on an ambiguous failure.
            HangTrace.Note("CHAT/APPLY-BEGIN");
            try { bridge.PrintLocalChat(item.Text); HangTrace.Note("CHAT/APPLY-END"); }
            catch(Exception e) { log.LogError("[CHAT/APPLY] "+e+". Overlay and recording remain enabled."); }
        }
        public void Clear() { queue.Clear(); }
    }
}
