using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

namespace CruiserLineup
{
    // Diagnostic worker never calls Unity, InputSystem, a BepInEx logger or Console.Write.
    // The main thread only publishes a stage/heartbeat or a bounded queue entry.
    public sealed class HangTrace : IDisposable
    {
        private static HangTrace current;
        private readonly ConcurrentQueue<string> pending=new ConcurrentQueue<string>();
        private readonly string path;
        private readonly bool enabled;
        private Timer timer;
        private long lastBeat=Stopwatch.GetTimestamp(),lastStall;
        private int running,busy,disposed,count,dropped;
        private string stage="runtime/initializing";
        private readonly int[] phases=new int[]{-1,-1,-1,-1,-1,-1,-1};
        // phase: Update, LateUpdate, pointer, preCanvas, willCanvas, cameraBegin, cameraEnd.
        public static void FramePhase(int phase,int frame)
        {
            var trace=Volatile.Read(ref current);
            if(trace!=null&&trace.enabled&&phase>=0&&phase<trace.phases.Length)
                Volatile.Write(ref trace.phases[phase],frame);
        }
        private string FrameSnapshot()
        {
            var values=new string[phases.Length];
            for(int i=0;i<phases.Length;i++)values[i]=Volatile.Read(ref phases[i]).ToString(CultureInfo.InvariantCulture);
            return string.Join("/",values);
        }
        public string PathName => path;
        public HangTrace(string path,string playerLog,bool enabled)
        {
            this.path=path; this.enabled=enabled;
            Interlocked.Exchange(ref current,this);
            if(enabled)
            {
                using(var process=Process.GetCurrentProcess())
                    Add("RUN version="+Plugin.Version+"; PID="+process.Id+"; all stages are observations, not a hang diagnosis");
                Add("PATH/PLAYER-LOG "+playerLog);
                Add("PATH/TRACE "+path);
            }
        }
        public static void Note(string value)
        {
            var trace=Volatile.Read(ref current);
            if(trace==null||!trace.enabled||Volatile.Read(ref trace.disposed)!=0) return;
            Volatile.Write(ref trace.stage,value); trace.Add(value);
        }
        public static void Stage(string value)
        {
            var trace=Volatile.Read(ref current);
            if(trace!=null&&trace.enabled) Volatile.Write(ref trace.stage,value);
        }
        public static void Beat()
        {
            var trace=Volatile.Read(ref current);
            if(trace!=null&&trace.enabled) Interlocked.Exchange(ref trace.lastBeat,Stopwatch.GetTimestamp());
        }
        private void Add(string value)
        {
            if(Interlocked.Increment(ref count)>256)
            { Interlocked.Decrement(ref count); Interlocked.Increment(ref dropped); return; }
            pending.Enqueue(DateTime.UtcNow.ToString("O",CultureInfo.InvariantCulture)+" "+value);
        }
        public void Start()
        {
            if(!enabled||Volatile.Read(ref disposed)!=0||Interlocked.Exchange(ref running,1)!=0) return;
            Interlocked.Exchange(ref lastBeat,Stopwatch.GetTimestamp());
            if(timer==null) timer=new Timer(Flush,null,1000,2000);
            else timer.Change(1000,2000);
        }
        public void Stop()
        {
            Interlocked.Exchange(ref running,0);
            try { timer?.Change(Timeout.Infinite,Timeout.Infinite); } catch(ObjectDisposedException) { }
        }
        private void Flush(object unused)
        {
            if(Volatile.Read(ref running)==0||Volatile.Read(ref disposed)!=0||Interlocked.Exchange(ref busy,1)!=0) return;
            try
            {
                var now=Stopwatch.GetTimestamp();
                var gap=(now-Interlocked.Read(ref lastBeat))/(double)Stopwatch.Frequency;
                if(gap>=10&&(now-Interlocked.Read(ref lastStall))/(double)Stopwatch.Frequency>=10)
                {
                    Interlocked.Exchange(ref lastStall,now);
                    Add("STALL updateGapSeconds="+gap.ToString("F1",CultureInfo.InvariantCulture)+"; lastStage="+Volatile.Read(ref stage)+
                        "; framePhases(update/late/pointer/preCanvas/willCanvas/cameraBegin/cameraEnd)="+FrameSnapshot()+
                        "; consoleSelection="+ConsoleModeLease.SelectionState()+"; loading/focus/debugger/console selection can also cause a gap");
                }
                var text=new StringBuilder();
                for(int i=0;i<256&&pending.TryDequeue(out var item);i++)
                { Interlocked.Decrement(ref count); text.AppendLine(item); }
                var lost=Interlocked.Exchange(ref dropped,0);
                if(lost>0) text.AppendLine("TRACE bounded queue dropped "+lost+" entries; main thread was never blocked");
                if(text.Length==0||Volatile.Read(ref disposed)!=0) return;
                var directory=Path.GetDirectoryName(path); if(!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
                if(File.Exists(path)&&new FileInfo(path).Length>2*1024*1024)
                {
                    var previous=path+".previous";
                    if(File.Exists(previous)) File.Delete(previous);
                    File.Move(path,previous);
                }
                using(var file=new FileStream(path,FileMode.Append,FileAccess.Write,FileShare.ReadWrite|FileShare.Delete))
                using(var writer=new StreamWriter(file,new UTF8Encoding(false))) writer.Write(text.ToString());
            }
            catch { /* Diagnostics must not create another console-log deadlock or interrupt gameplay. */ }
            finally { Interlocked.Exchange(ref busy,0); }
        }
        public void Dispose()
        {
            if(Interlocked.Exchange(ref disposed,1)!=0) return;
            Stop(); timer?.Dispose(); timer=null;
            Interlocked.CompareExchange(ref current,null,this);
            // No thread join/WaitHandle/Unity callbacks during application shutdown.
        }
    }
}
