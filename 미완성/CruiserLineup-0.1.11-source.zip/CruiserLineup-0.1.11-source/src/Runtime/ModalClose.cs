using System;
using UnityEngine;

namespace CruiserLineup
{
    public sealed partial class LineupRuntime
    {
        // Shared by Load, F10/Escape/Close, recording and error/lifecycle cleanup.
        // In 0.1.3 visible=false was set before BeginRelease could throw; a second
        // CloseUi then returned early and never retried cleanup or saved the draft.
        private void CloseUi(bool immediateRelease=false)
        {
            CancelPendingUiOpen();
            bool wasVisible=visible;
            if(!wasVisible&&!(inputLease?.Held??false)) return;
            HangTrace.Note("UI/CLOSE-BEGIN");
            visible=false;
            try { HideRetainedUi(); } catch(Exception e) { log?.LogWarning("[UI/HIDE-TREE] "+e.Message); }
            deleteSlot=-1; reorderMode=false; reorderFrom=-1;
            blockUntilFrame=Time.frameCount+1;
            try
            {
                if(immediateRelease) inputLease?.Release();
                else inputLease?.BeginRelease();
            }
            catch(Exception e)
            {
                log?.LogError("[UI/CLOSE-RECOVER] Input close failed; forcing lease cleanup. "+e);
                try { inputLease?.Release(); }
                catch(Exception cleanupError) { log?.LogError("[UI/CLOSE-CLEANUP] "+cleanupError); }
            }
            finally
            {
                // Input/cursor cleanup is not allowed to suppress draft persistence.
                if(wasVisible)
                {
                    HangTrace.Note("UI/SAVE-BEGIN");
                    try { SaveWorkspace(); HangTrace.Note("UI/SAVE-END"); }
                    catch(Exception e) { log?.LogError("[UI/CLOSE-SAVE] Draft remains in memory after a save error. "+e); }
                    HangTrace.Note("UI/CLOSE-END");
                    log?.LogInfo("[UI/HIDE] Draft/view retained; inputLeasePending="+(inputLease?.Held??false)+".");
                }
            }
        }
    }
}
