using System;
using System.Globalization;
using System.Reflection;
using BepInEx.Logging;
using CruiserLineup.Core;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace CruiserLineup
{
    // Only our own material is changed. No UI/Default, Internal-Colored, shader-global
    // state or shared vehicle/UI material is touched. HDRP configures its own blend/pass state.
    internal static class GhostMaterial
    {
        private static readonly Color Tint = new Color(0.30f, 0.75f, 0.60f, 1f);
        public static Material Create(float opacity, ManualLogSource log)
        {
            var pipeline = GraphicsSettings.currentRenderPipeline;
            if (pipeline == null || pipeline.GetType().FullName != "UnityEngine.Rendering.HighDefinition.HDRenderPipelineAsset")
                throw new InvalidOperationException("Cruiser overlay requires the game's HDRP pipeline. No debug/UI shader fallback will be used.");
            var shader = Shader.Find("HDRP/Unlit");
            if (shader == null || !shader.isSupported)
                throw new InvalidOperationException("The game's HDRP/Unlit shader is unavailable. The slot and UI are unaffected.");
            var type = AccessTools.TypeByName("UnityEngine.Rendering.HighDefinition.HDMaterial");
            var validate = type?.GetMethod("ValidateMaterial", BindingFlags.Public | BindingFlags.Static,
                null, new[] { typeof(Material) }, null);
            if (validate == null || (validate.ReturnType != typeof(void) && validate.ReturnType != typeof(bool)))
                throw new MissingMethodException("HDRP HDMaterial.ValidateMaterial(Material) is unavailable; overlay creation was canceled.");
            Material material = null;
            try
            {
                material = new Material(shader) {
                    name = "CruiserLineup.PrivateHdrpGhost", hideFlags = HideFlags.HideAndDontSave,
                    renderQueue = (int)RenderQueue.Transparent, enableInstancing = false
                };
                foreach (var property in new[] { "_UnlitColor", "_SurfaceType", "_BlendMode", "_TransparentZWrite", "_SrcBlend", "_DstBlend", "_ZWrite" })
                    if (!material.HasProperty(property)) throw new InvalidOperationException("HDRP/Unlit contract changed: " + property);
                material.SetFloat("_SurfaceType", 1f);
                material.SetFloat("_BlendMode", 0f); // HDRP Alpha mode, not the UnityEngine.Rendering.BlendMode enum.
                material.SetFloat("_TransparentZWrite", 0f);
                Set(material, "_AlphaCutoffEnable", 0f);
                Set(material, "_DoubleSidedEnable", 0f);
                Set(material, "_TransparentCullMode", (float)CullMode.Back);
                Set(material, "_ZTestTransparent", (float)CompareFunction.LessEqual);
                Set(material, "_DistortionEnable", 0f);
                Set(material, "_DistortionOnly", 0f);
                Set(material, "_EnableFogOnTransparent", 0f);
                Set(material, "_UseEmissiveIntensity", 0f);
                if (material.HasProperty("_EmissiveColor")) material.SetColor("_EmissiveColor", Color.black);
                if (material.HasProperty("_UnlitColorMap")) material.SetTexture("_UnlitColorMap", Texture2D.whiteTexture);
                ApplyOpacity(material, opacity);
                HangTrace.Note("OVERLAY/MATERIAL-VALIDATE-BEGIN");
                var result = validate.Invoke(null, new object[] { material });
                if (result is bool accepted && !accepted) throw new InvalidOperationException("HDRP rejected the overlay material.");
                HangTrace.Note("OVERLAY/MATERIAL-VALIDATE-END");
                // Suppress only passes on our newly allocated material. The normal HDRP forward
                // pass remains intact; don't guess a fixed one-pass state for an SRP shader.
                foreach (var pass in new[] { "ShadowCaster", "MotionVectors", "DepthForwardOnly", "TransparentDepthPrepass", "TransparentDepthPostpass", "DistortionVectors" })
                    material.SetShaderPassEnabled(pass, false);
                if (!material.IsKeywordEnabled("_SURFACE_TYPE_TRANSPARENT") || material.GetInt("_ZWrite") != 0 ||
                    material.GetInt("_DstBlend") != (int)BlendMode.OneMinusSrcAlpha ||
                    material.renderQueue < (int)RenderQueue.Transparent || material.FindPass("ForwardOnly") < 0)
                    throw new InvalidOperationException("HDRP transparent forward-state validation failed; no opaque fallback was created.");
                LogState(material, log);
                return material;
            }
            catch
            {
                if (material != null) Object.Destroy(material);
                throw;
            }
        }
        private static void Set(Material material, string name, float value)
        { if (material.HasProperty(name)) material.SetFloat(name, value); }
        public static void ApplyOpacity(Material material, float opacity)
        {
            if (material == null) throw new ArgumentNullException(nameof(material));
            var colour = Tint; colour.a = OverlayStyle.NormalizeOpacity(opacity);
            material.SetColor("_UnlitColor", colour);
            if (!Mathf.Approximately(material.GetColor("_UnlitColor").a, colour.a))
                throw new InvalidOperationException("Overlay alpha was not retained.");
        }
        public static void LogState(Material material, ManualLogSource log)
        {
            log.LogInfo("[OVERLAY/ALPHA] plugin=" + Plugin.Version + "; backend=retained-HDRP; shader=" + material.shader.name +
                "; opacity=" + material.GetColor("_UnlitColor").a.ToString("0.###", CultureInfo.InvariantCulture) +
                "; src=" + material.GetInt("_SrcBlend") + "; dst=" + material.GetInt("_DstBlend") +
                "; zwrite=" + material.GetInt("_ZWrite") + "; queue=" + material.renderQueue +
                "; validation=properties-and-HDRP-validator, NOT a GPU appearance test");
        }
    }
}
