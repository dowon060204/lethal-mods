using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx.Logging;
using CruiserLineup.Core;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace CruiserLineup
{
    // A bounded, retained, transform/mesh-only snapshot. Unity/HDRP owns rendering.
    // No Graphics.DrawMesh loop, command buffers, render textures, cameras, post-processing
    // or shader globals. Opening F10 never creates this snapshot or its material.
    public sealed class GhostRenderer : IDisposable
    {
        private readonly List<MeshRenderer> renderers = new List<MeshRenderer>();
        private readonly List<Mesh> ownedMeshes = new List<Mesh>();
        private readonly ManualLogSource log;
        private Material material;
        private GameObject root;
        private Camera targetCamera;
        private bool subscribed, permitted, rendering, callbackFailed, disposed;
        private float appliedOpacity = -1f;
        public string MoonKey { get; private set; }
        public string Name { get; private set; }
        public bool Active => root != null && material != null && renderers.Count > 0;
        public int MeshCount => renderers.Count;
        public GhostRenderer(ManualLogSource log) { this.log = log; }
        public void Load(Component source, Lineup lineup, string moon, float opacity, GameBridge bridge)
        {
            if (disposed) throw new ObjectDisposedException(nameof(GhostRenderer));
            Guard.Data(lineup);
            if (source == null) throw new InvalidOperationException("Cruiser mesh source is not loaded yet.");
            Clear();
            try
            {
                material = GhostMaterial.Create(opacity, log);
                appliedOpacity = OverlayStyle.NormalizeOpacity(opacity);
                root = new GameObject("CruiserLineup.LocalGhost"); root.SetActive(false);
                root.hideFlags = HideFlags.DontSave;
                Object.DontDestroyOnLoad(root);
                root.transform.position = GameBridge.ToUnity(lineup.Pose.Position);
                root.transform.rotation = Quaternion.Euler(GameBridge.ToUnity(lineup.Pose.RotationEuler));
                root.transform.localScale = GameBridge.ToUnity(lineup.Pose.Scale);
                var originalRoot = source.transform;
                var nodes = new Dictionary<Transform, Transform> { [originalRoot] = root.transform };
                var allowedLod = new HashSet<Renderer>(); var allLod = new HashSet<Renderer>();
                foreach (var group in source.GetComponentsInChildren<LODGroup>(true))
                {
                    var lods = group.GetLODs();
                    foreach (var lod in lods) foreach (var renderer in lod.renderers) if (renderer != null) allLod.Add(renderer);
                    if (lods.Length > 0) foreach (var renderer in lods[0].renderers) if (renderer != null) allowedLod.Add(renderer);
                }
                var originalRenderers = source.GetComponentsInChildren<Renderer>(true);
                if (originalRenderers.Length > 2048) throw new InvalidOperationException("Unexpectedly large vehicle hierarchy; snapshot canceled.");
                var itemType = HarmonyLib.AccessTools.TypeByName("GrabbableObject");
                var seen = new List<Tuple<Mesh, Matrix4x4>>();
                int skipped = 0, subMeshes = 0;
                long vertices = 0;
                foreach (var renderer in originalRenderers)
                {
                    if (renderer == null || !renderer.enabled ||
                        (!renderer.gameObject.activeInHierarchy && source.gameObject.scene.IsValid()) ||
                        renderer.shadowCastingMode == ShadowCastingMode.ShadowsOnly ||
                        (allLod.Contains(renderer) && !allowedLod.Contains(renderer))) { skipped++; continue; }
                    if (!(renderer is MeshRenderer) && !(renderer is SkinnedMeshRenderer)) continue;
                    bool excluded = false; int depth = 0;
                    for (var t = renderer.transform; t != null && t != originalRoot; t = t.parent)
                    {
                        if (++depth > 64) throw new InvalidOperationException("Vehicle hierarchy exceeds 64 transform levels.");
                        if (!t.gameObject.activeSelf || t.GetComponent(bridge.PlayerType) != null ||
                            (itemType != null && t.GetComponent(itemType) != null)) { excluded = true; break; }
                    }
                    if (excluded) { skipped++; continue; }
                    var filter = renderer.GetComponent<MeshFilter>();
                    var identity = renderer is SkinnedMeshRenderer skinIdentity ? skinIdentity.sharedMesh : filter?.sharedMesh;
                    if (identity == null || identity.subMeshCount == 0) continue;
                    var relative = originalRoot.worldToLocalMatrix * renderer.transform.localToWorldMatrix;
                    if (renderer is MeshRenderer && seen.Any(p => p.Item1 == identity && p.Item2.Equals(relative))) { skipped++; continue; }
                    vertices += identity.vertexCount; subMeshes += identity.subMeshCount;
                    if (renderers.Count >= 256 || subMeshes > 512 || vertices > 2000000)
                        throw new InvalidOperationException("Vehicle snapshot exceeds the bounded mesh budget; no partial preview was kept.");
                    Mesh mesh = identity;
                    if (renderer is SkinnedMeshRenderer skin)
                    {
                        mesh = new Mesh { name = "CruiserLineup.PosedMesh", hideFlags = HideFlags.HideAndDontSave };
                        ownedMeshes.Add(mesh); skin.BakeMesh(mesh);
                    }
                    var target = CopyPath(renderer.transform, originalRoot, nodes);
                    var leaf = new GameObject("mesh-" + renderers.Count); leaf.layer = 0;
                    leaf.transform.SetParent(target, false);
                    leaf.AddComponent<MeshFilter>().sharedMesh = mesh; // never write to original mesh data
                    var copy = leaf.AddComponent<MeshRenderer>(); copy.enabled = false;
                    copy.shadowCastingMode = ShadowCastingMode.Off; copy.receiveShadows = false;
                    copy.lightProbeUsage = LightProbeUsage.Off; copy.reflectionProbeUsage = ReflectionProbeUsage.Off;
                    copy.motionVectorGenerationMode = MotionVectorGenerationMode.ForceNoMotion;
                    copy.allowOcclusionWhenDynamic = false;
                    copy.sharedMaterials = Enumerable.Repeat(material, mesh.subMeshCount).ToArray();
                    renderers.Add(copy); seen.Add(Tuple.Create(identity, relative));
                }
                if (renderers.Count == 0) throw new InvalidOperationException("No usable Cruiser meshes were found.");
                MoonKey = moon; Name = lineup.Name; callbackFailed = false;
                Subscribe(); root.SetActive(true); // All renderers are initially disabled.
                log.LogInfo("[APPLY/OVERLAY] backend=retained-HDRP; meshes=" + renderers.Count + "; submeshes=" + subMeshes +
                    "; skipped=" + skipped + "; moon=" + moon + "; local-camera-only; no vehicle/collider/network object cloned.");
                HangTrace.Note("OVERLAY/PREPARED meshes=" + renderers.Count + "; rendering=False");
            }
            catch { Clear(); throw; }
        }
        private static Transform CopyPath(Transform from, Transform originalRoot, Dictionary<Transform, Transform> nodes)
        {
            if (nodes.TryGetValue(from, out var existing)) return existing;
            var path = new List<Transform>();
            var current = from;
            while (current != null && !nodes.ContainsKey(current))
            {
                if (path.Count >= 64 || nodes.Count + path.Count > 2048) throw new InvalidOperationException("Vehicle transform budget exceeded.");
                path.Add(current); current = current.parent;
            }
            if (current == null) throw new InvalidOperationException("Renderer is no longer under the vehicle.");
            var parent = nodes[current];
            for (int i = path.Count - 1; i >= 0; i--)
            {
                var original = path[i]; var go = new GameObject("pose-" + nodes.Count);
                go.transform.SetParent(parent, false);
                go.transform.localPosition = original.localPosition;
                go.transform.localRotation = original.localRotation;
                go.transform.localScale = original.localScale;
                nodes.Add(original, go.transform); parent = go.transform;
            }
            return parent;
        }
        public void SetOpacity(float opacity)
        {
            if (material == null) return;
            var value = OverlayStyle.NormalizeOpacity(opacity);
            if (Mathf.Approximately(appliedOpacity, value)) return;
            GhostMaterial.ApplyOpacity(material, value); appliedOpacity = value; GhostMaterial.LogState(material, log);
        }
        public void SetView(Camera camera, bool allow)
        {
            if (callbackFailed) { Clear(); return; }
            targetCamera = camera;
            permitted = allow && !callbackFailed && Active && camera != null;
            if (!permitted) SetVisible(false);
        }
        private void Subscribe()
        {
            if (subscribed) return;
            RenderPipelineManager.beginCameraRendering += BeginCamera;
            RenderPipelineManager.endCameraRendering += EndCamera;
            subscribed = true;
        }
        private void BeginCamera(ScriptableRenderContext unused, Camera camera)
        {
            try { SetVisible(permitted && camera != null && camera == targetCamera && !Plugin.Quitting); }
            catch (Exception error) { CallbackFault(error); }
        }
        private void EndCamera(ScriptableRenderContext unused, Camera camera)
        {
            try { SetVisible(false); }
            catch (Exception error) { CallbackFault(error); }
        }
        private void CallbackFault(Exception error)
        {
            permitted = false; callbackFailed = true;
            // Do not log synchronously or destroy meshes inside a rendering callback.
            HangTrace.Note("OVERLAY/CAMERA-FAILED " + error.GetType().Name);
            // SetView observes this latch on the next main-thread LateUpdate.
        }
        private void SetVisible(bool show)
        {
            if (rendering == show) return;
            rendering = show;
            foreach (var renderer in renderers) if (renderer != null) renderer.enabled = show;
        }
        public void Clear()
        {
            permitted = false; targetCamera = null;
            if (subscribed)
            {
                RenderPipelineManager.beginCameraRendering -= BeginCamera;
                RenderPipelineManager.endCameraRendering -= EndCamera;
                subscribed = false;
            }
            if (root != null) { root.SetActive(false); Object.Destroy(root); } root = null;
            renderers.Clear(); rendering = false;
            foreach (var mesh in ownedMeshes) if (mesh != null) Object.Destroy(mesh);
            ownedMeshes.Clear();
            if (material != null) Object.Destroy(material); material = null;
            appliedOpacity = -1f; MoonKey = null; Name = null;
        }
        public void Dispose() { if (disposed) return; Clear(); disposed = true; }
    }
}
