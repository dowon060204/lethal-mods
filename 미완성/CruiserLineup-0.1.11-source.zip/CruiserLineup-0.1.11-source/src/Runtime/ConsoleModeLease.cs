using System;
using System.Runtime.InteropServices;
using CruiserLineup.Core;

namespace CruiserLineup
{
    // Windows-only, current process's dedicated console only. No global BepInEx.cfg,
    // registry setting, injected key, console close or other process modification.
    public sealed class ConsoleModeLease : IDisposable
    {
        private IntPtr input;
        private uint original,applied;
        private bool changed,ownsHandle;
        public string Result { get; private set; }="Not requested";
        public void Acquire(bool enabled)
        {
            if(changed) return;
            if(!enabled) { Result="Disabled by CruiserLineup setting"; return; }
            if(Environment.OSVersion.Platform!=PlatformID.Win32NT) { Result="Non-Windows; not applicable"; return; }
            try
            {
                var ids=new uint[2]; var count=GetConsoleProcessList(ids,(uint)ids.Length);
                if(count!=1||ids[0]!=GetCurrentProcessId())
                { Result="No dedicated current-process console; left unchanged"; return; }
                input=GetStdHandle(-10);
                if(input==IntPtr.Zero||input==new IntPtr(-1)||!GetConsoleMode(input,out original))
                {
                    input=CreateFileW("CONIN$",0xC0000000,3,IntPtr.Zero,3,0,IntPtr.Zero);
                    ownsHandle=input!=IntPtr.Zero&&input!=new IntPtr(-1);
                    if(!ownsHandle||!GetConsoleMode(input,out original))
                    { Result="Console input unavailable; Win32="+Marshal.GetLastWin32Error(); CloseOwnedHandle(); return; }
                }
                applied=ConsoleModePolicy.WithoutQuickEdit(original);
                if(applied==original) { Result="QuickEdit already off; no changes"; CloseOwnedHandle(); return; }
                if(!SetConsoleMode(input,applied))
                { Result="SetConsoleMode failed; Win32="+Marshal.GetLastWin32Error(); CloseOwnedHandle(); return; }
                changed=true;
                uint readBack;
                Result=GetConsoleMode(input,out readBack)&&(readBack&ConsoleModePolicy.QuickEdit)==0
                    ?"QuickEdit off for this game console only; original mode=0x"+original.ToString("X")
                    :"Console mode changed, but read-back could not confirm QuickEdit off";
            }
            catch(Exception e) { Result="Optional console guard unavailable: "+e.GetType().Name; if(!changed) CloseOwnedHandle(); }
        }
        public void Dispose()
        {
            try
            {
                uint current;
                if(changed&&GetConsoleMode(input,out current)&&ConsoleModePolicy.CanRestore(current,applied))
                    SetConsoleMode(input,ConsoleModePolicy.RestoreOwnBits(current,original));
            }
            catch { /* Optional platform cleanup cannot prevent the runtime from shutting down. */ }
            finally { changed=false; CloseOwnedHandle(); }
        }
        private void CloseOwnedHandle()
        {
            if(ownsHandle) { try { CloseHandle(input); } catch { } }
            ownsHandle=false; input=IntPtr.Zero;
        }
        // Called only by the diagnostic worker. No Console.Write/Unity/BepInEx logging.
        public static string SelectionState()
        {
            if(Environment.OSVersion.Platform!=PlatformID.Win32NT) return "not-windows";
            try
            {
                ConsoleSelectionInfo info;
                if(!GetConsoleSelectionInfo(out info)) return "unavailable:"+Marshal.GetLastWin32Error();
                return info.Flags==0?"none":"active:0x"+info.Flags.ToString("X");
            }
            catch(Exception e) { return "unavailable:"+e.GetType().Name; }
        }
        [StructLayout(LayoutKind.Sequential)] private struct Coord { public short X,Y; }
        [StructLayout(LayoutKind.Sequential)] private struct SmallRect { public short Left,Top,Right,Bottom; }
        [StructLayout(LayoutKind.Sequential)] private struct ConsoleSelectionInfo
        { public uint Flags; public Coord Anchor; public SmallRect Selection; }
        [DllImport("kernel32.dll",SetLastError=true)] private static extern IntPtr GetStdHandle(int kind);
        [DllImport("kernel32.dll",SetLastError=true)] private static extern bool GetConsoleMode(IntPtr handle,out uint mode);
        [DllImport("kernel32.dll",SetLastError=true)] private static extern bool SetConsoleMode(IntPtr handle,uint mode);
        [DllImport("kernel32.dll",SetLastError=true)] private static extern uint GetConsoleProcessList([Out] uint[] ids,uint length);
        [DllImport("kernel32.dll")] private static extern uint GetCurrentProcessId();
        [DllImport("kernel32.dll",SetLastError=true)] private static extern bool GetConsoleSelectionInfo(out ConsoleSelectionInfo info);
        [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] private static extern IntPtr CreateFileW(string name,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
        [DllImport("kernel32.dll",SetLastError=true)] private static extern bool CloseHandle(IntPtr handle);
    }
}
