using System;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Logging;
using CruiserLineup.Core;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

namespace CruiserLineup
{
    [DefaultExecutionOrder(-32000)]
    public sealed partial class LineupRuntime : MonoBehaviour
    {
        public static LineupRuntime Current { get; private set; }
        public GameBridge Bridge { get; private set; }
        private Settings settings;
        private ManualLogSource log;
        private LineupRepository repository;
        private Workspace workspace;
        private string workspacePath,workspaceSignature;
        private bool workspaceReadOnly,dirty,initialized,subscribed,firstUpdate,disposed;
        private InputLease inputLease;
        private ConsoleModeLease consoleGuard;
        private HangTrace trace;
        private Action pendingPreview;
        private long pendingPreviewSession;
        private string pendingPreviewMoon;
        private PatchSet patches;
        private GhostRenderer ghost;
        private TimingAudio audio;
        private LocalChat chat;
        private readonly TimingRecorder recorder=new TimingRecorder();
        private Draft recordingDraft;
        private Component recordingVehicle;
        private double armedAt;
        private Moon uiMoon;
        private UiLanguage language;
        private string unknownMoon="";
        private Lineup[] snapshot;
        private int[] slotOrder=SlotOrdering.Identity().ToArray();
        private string orderBaseline;
        private bool reorderMode;
        private int reorderFrom=-1;
        private bool visible;
        private int blockUntilFrame=-1;
        private int lastPlayerId,lastRoundId;
        private string lastMoonKey,lastRole="";
        private long session;
        private double nextContext,nextSave,nextErrorLog,nextApiRetry;
        private int apiRetries;
        private bool uiPrebuildAttempted;
        private bool legacyF10Unsupported;
        private bool missingKeyboardLogged;
        private string status="";
        private double statusUntil;
        private int deleteSlot=-1;
        private string deleteBaseline;
        public bool BlockGameInput => visible||(inputLease?.Held??false)||Time.frameCount<=blockUntilFrame;
        private string L(string ko,string en)=>(UseKorean?ko:en).Replace("F10",settings?.ToggleKey.Value.ToString()??"F10");
        private Draft ActiveDraft => uiMoon==null?null:workspace.Find(uiMoon.Key,workspace.View(uiMoon.Key).ActiveDraftSlot);
        public void Initialize(Settings settings,ManualLogSource log,string pluginDirectory,ConsoleModeLease consoleGuard)
        {
            if(Current!=null&&Current!=this) throw new InvalidOperationException("Duplicate runtime rejected.");
            Current=this; this.settings=settings; this.log=log; language=settings.Language.Value;
            this.consoleGuard=consoleGuard;
            trace=new HangTrace(Path.Combine(Path.GetDirectoryName(Paths.ConfigPath),"CruiserLineup.trace.log"),
                Application.consoleLogPath,settings.HangDiagnostics.Value);
            log.LogInfo("[PATH/PLAYER-LOG] "+Application.consoleLogPath);
            log.LogInfo("[PATH/TRACE] "+trace.PathName);
            workspacePath=Path.Combine(Paths.ConfigPath,"CruiserLineup.workspace.json");
            string dataPath=Path.Combine(Paths.ConfigPath,"CruiserLineup.lineups.json");
            LineupBook defaults;
            var defaultsPath=Path.Combine(pluginDirectory,"CruiserLineup.defaults.json");
            if(File.Exists(defaultsPath)) defaults=JsonStore.Read<LineupBook>(defaultsPath,b=>Guard.Book(b,true));
            else
            {
                using(var stream=typeof(Plugin).Assembly.GetManifestResourceStream("CruiserLineup.defaults.json"))
                {
                    if(stream==null) throw new FileNotFoundException("Packaged defaults and embedded fallback are missing.");
                    using(var ms=new MemoryStream()) { stream.CopyTo(ms); defaults=JsonStore.Decode<LineupBook>(ms.ToArray()); }
                    Guard.Book(defaults,true);
                }
            }
            if(!File.Exists(dataPath)) JsonStore.WriteAtomic(dataPath,LineupBook.Empty("inherit"),b=>Guard.Book(b));
            repository=new LineupRepository(dataPath,defaults);
            workspace=new Workspace(); LoadWorkspace();
            Bridge=new GameBridge(log); Bridge.Bind();
            patches=new PatchSet(log); if(Bridge.CoreBound) patches.Install(Bridge);
            inputLease=new InputLease(log); ghost=new GhostRenderer(log); systemText=new SystemUiText(log);
            audio=new TimingAudio(transform,log); audio.Failed+=AudioFailed; audio.Started+=AudioStarted;
            chat=new LocalChat(Bridge,log);
            initialized=true;
            log.LogInfo("[INIT] 13 moons x 8 slots; local config="+dataPath+"; workspace="+workspacePath);
            log.LogInfo("[NETWORK] Local-only tool: no custom messages, RPCs, authority writes, participant arrays or ACK protocol.");
            if(repository.ReadOnly) log.LogError("[CONFIG/READONLY] "+repository.Error);
            // No universal Ready flag: every feature reports its own verified stage.
        }
        private void OnEnable()
        {
            if(!initialized||disposed||Plugin.Quitting) return;
            trace?.Start(); Subscribe(); log.LogInfo("[LIFECYCLE] Runtime OnEnable; independent hidden persistent root.");
        }
        private void Subscribe()
        {
            if(subscribed) return; subscribed=true;
            SceneManager.sceneLoaded+=SceneLoaded; SceneManager.sceneUnloaded+=SceneUnloaded;
            Canvas.preWillRenderCanvases+=ObservePreCanvas; Canvas.willRenderCanvases+=ObserveWillCanvas;
            RenderPipelineManager.beginCameraRendering+=ObserveCameraBegin; RenderPipelineManager.endCameraRendering+=ObserveCameraEnd;
            AudioSettings.OnAudioConfigurationChanged+=AudioConfigurationChanged;
        }
        private void Unsubscribe()
        {
            if(!subscribed) return; subscribed=false;
            SceneManager.sceneLoaded-=SceneLoaded; SceneManager.sceneUnloaded-=SceneUnloaded;
            Canvas.preWillRenderCanvases-=ObservePreCanvas; Canvas.willRenderCanvases-=ObserveWillCanvas;
            RenderPipelineManager.beginCameraRendering-=ObserveCameraBegin; RenderPipelineManager.endCameraRendering-=ObserveCameraEnd;
            AudioSettings.OnAudioConfigurationChanged-=AudioConfigurationChanged;
        }
        private void Update()
        {
            if(!initialized||disposed||Plugin.Quitting) return;
            HangTrace.Beat(); HangTrace.FramePhase(0,Time.frameCount); HangTrace.Stage("update/begin");
            if(!firstUpdate) { firstUpdate=true; log.LogInfo("[RUNTIME] First Update observed. This does not establish game/multiplayer validation."); }
            try
            {
                var now=Time.realtimeSinceStartupAsDouble;
                if(!Bridge.CoreBound&&Bridge.Pending&&apiRetries<30&&now>=nextApiRetry)
                {
                    nextApiRetry=now+2; apiRetries++; Bridge.Bind();
                    if(Bridge.CoreBound) patches.Install(Bridge);
                    else if(apiRetries==30) log.LogError("[API/WAIT-EXHAUSTED] Game types unavailable after 30 bounded retries; restart after correcting dependencies.");
                }
                if(now>=nextContext) { nextContext=now+0.5; RefreshContext(); }
                if(!uiPrebuildAttempted&&Bridge.Alive)
                {
                    uiPrebuildAttempted=true;
                    EnsureRetainedUi();
                }
                TickUiPreparation();
                var keyboard=Keyboard.current;
                if(keyboard==null&&!missingKeyboardLogged)
                {missingKeyboardLogged=true;log.LogWarning("[INPUT/F10] No Input System keyboard yet; will retry each Update.");}
                bool fallbackToggle=false;
                if(keyboard==null&&settings.ToggleKey.Value==Key.F10&&!legacyF10Unsupported)
                {
                    try { fallbackToggle=UnityEngine.Input.GetKeyDown(KeyCode.F10); }
                    catch(InvalidOperationException) { legacyF10Unsupported=true; }
                }
                if(fallbackToggle)
                {
                    HangTrace.Note("INPUT/F10-LEGACY-FALLBACK");
                    if(visible||openWhenUiReady) CloseUi(); else OpenUi();
                }
                else if(keyboard!=null)
                {
                    var key=settings.ToggleKey.Value;
                    UnityEngine.InputSystem.Controls.KeyControl toggle=null;
                    try { toggle=key==Key.None?null:keyboard[key]; }
                    catch(Exception e) { log.LogWarning("[INPUT/F10] Invalid configured ToggleKey "+key+": "+e.Message); }
                    var escape=keyboard.escapeKey;
                    bool pressed=toggle!=null&&toggle.wasPressedThisFrame;
                    // Use one source per frame. Polling the legacy key API as well can
                    // duplicate a toggle when old/new input updates do not coincide.
                    if(pressed)
                    {
                        HangTrace.Note("INPUT/F10-PRESSED "+(visible?"close":"open"));
                        log.LogInfo("[INPUT/F10] Toggle detected; windowCurrentlyOpen="+visible);
                        if(visible||openWhenUiReady) CloseUi(); else OpenUi();
                    }
                    else if((visible||openWhenUiReady)&&escape!=null&&escape.wasPressedThisFrame) CloseUi();
                }
                HangTrace.Stage("input/tick"); inputLease.Tick();
                ProcessUiCommand();
                ProcessPreview();
                if(recordingDraft!=null)
                {
                    if(!Bridge.Alive||recordingVehicle==null||!Bridge.IsLocalVehicle(recordingVehicle)||!Bridge.Landed||
                       Bridge.CurrentMoon?.Key!=recordingDraft.Moon||now-armedAt>Guard.MaxTimeMs/1000.0)
                        FinishRecording(true);
                }
                if(Bridge.Alive&&!uiBuild.Running) audio.Warmup(Bridge.JumpClip);
                HangTrace.Stage("audio/tick"); audio.Tick();
                HangTrace.Stage("ui/tick"); TickRetainedUi();
                HangTrace.Stage("chat/tick"); chat.Tick(session);
                if(dirty&&now>=nextSave) { nextSave=now+1.0; SaveWorkspace(); }
            }
            catch(Exception e)
            {
                if(Time.realtimeSinceStartupAsDouble>=nextErrorLog)
                { nextErrorLog=Time.realtimeSinceStartupAsDouble+5; log.LogError("[RUNTIME/RECOVERABLE] "+e); }
                // Fail open on input: an auxiliary rendering/config error must not trap the user in a modal.
                CloseUi(true);
            }
            finally { HangTrace.Stage("update/returned-to-engine"); }
        }
        private void LateUpdate()
        {
            if(!initialized||disposed||Plugin.Quitting) return;
            try
            {
                HangTrace.FramePhase(1,Time.frameCount);
                HangTrace.Stage("overlay/late-update");
                if(!settings.OverlayEnabled.Value&&ghost.Active)ghost.Clear();
                ghost.SetView(Bridge.LocalCamera,!visible&&settings.OverlayEnabled.Value&&Bridge.Alive&&Bridge.Landed&&Bridge.CurrentMoon?.Key==ghost.MoonKey);
                if(!visible)ghost.SetOpacity(settings.Opacity.Value);
            }
            catch(Exception e) { ghost.Clear(); log.LogError("[OVERLAY/LOCAL] "+e); SetStatus(L("오버레이 표시를 중단했습니다.","Overlay rendering stopped.")); }
            finally { HangTrace.Stage("late-update/returned-to-engine"); }
        }
        private static int Id(object value) => value is UnityEngine.Object obj&&obj!=null?obj.GetInstanceID():0;
        private void RefreshContext()
        {
            if(!Bridge.CoreBound) return;
            var playerId=Id(Bridge.LocalPlayer); var roundId=Id(Bridge.Round);
            var moonKey=Bridge.CurrentMoon?.Key;
            if(playerId!=lastPlayerId||roundId!=lastRoundId)
            {
                pendingPreview=null; FinishRecording(true); CloseUi(true); ghost.Clear(); audio.Stop(); Bridge.ForgetJumpClip(); chat.Clear();
                session++; lastPlayerId=playerId; lastRoundId=roundId;
                log.LogInfo("[SESSION] "+session+"; localPlayer="+playerId+"; round="+roundId+"; "+Bridge.Role);
                log.LogInfo("[GAME/VERSION] gameVersionNum="+(Bridge.Member(Bridge.Network,"gameVersionNum")??"not exposed")+"; moon="+Bridge.RawMoon);
            }
            if(moonKey!=lastMoonKey)
            {
                // IMPORTANT: uiMoon and snapshot are deliberately NOT updated here.
                pendingPreview=null; ghost.Clear(); audio.Stop(); FinishRecording(true); lastMoonKey=moonKey;
                log.LogInfo("[MOON] Current="+(moonKey??"unrecognized")+"; UI snapshot="+(uiMoon?.Key??"none")+"; visible="+visible);
            }
            if(lastRole!=Bridge.Role) { lastRole=Bridge.Role; log.LogInfo("[ROLE] "+lastRole+"; no host-only initialization branch."); }
            if(visible&&(!Bridge.Alive||Bridge.GameMenuOpen)) CloseUi();
        }
        // Read-only frame markers; no renderer, camera, material or global state changes.
        private void ObservePreCanvas() { HangTrace.FramePhase(3,Time.frameCount); }
        private void ObserveWillCanvas() { HangTrace.FramePhase(4,Time.frameCount); }
        private void ObserveCameraBegin(ScriptableRenderContext context,Camera camera) { HangTrace.FramePhase(5,Time.frameCount); }
        private void ObserveCameraEnd(ScriptableRenderContext context,Camera camera) { HangTrace.FramePhase(6,Time.frameCount); }
        private void SceneLoaded(Scene scene,LoadSceneMode mode)
        { if(!initialized||disposed) return; nextContext=0; log.LogInfo("[SCENE] Loaded "+scene.name+"; context refresh queued."); }
        private void SceneUnloaded(Scene scene)
        {
            if(!initialized||disposed) return;
            pendingPreview=null; ghost.Clear(); audio.Stop(); Bridge.ForgetJumpClip(); FinishRecording(true); nextContext=0;
            // Routing a moon does not replace an already-open slot view.
            log.LogInfo("[SCENE] Unloaded "+scene.name+"; scene-owned previews/audio cleared.");
        }
        private void AudioConfigurationChanged(bool deviceChanged)
        { if(audio==null) return; audio.Stop(); log?.LogWarning("[AUDIO] Output configuration changed; local timing playback canceled. Press Listen again after the device is ready."); }
        private void AudioStarted()
        {
            SetStatus(L("저장한 타이밍으로 점프 소리 재생을 시작했습니다.",
                "Started the jump-sound sequence at the saved timing."));
        }
        public void EnforceModalInput()
        {
            try { inputLease?.Enforce(); }
            catch(Exception e) { log.LogError("[INPUT/GUARD] "+e); inputLease?.Release(); InputFault(); }
        }
        public void ModalInputFault(Exception error)
        {
            log.LogError("[INPUT/VEHICLE-GUARD] "+error);
            inputLease?.Release(); InputFault();
        }
        public void InputFault()
        {
            CloseUi(true);
            SetStatus(L("입력 보호에 문제가 있어 창을 닫았습니다. 게임 조작은 해제했습니다.","The modal closed after an input-guard error. Game controls were released."));
        }
        private void AudioFailed(string message) => SetStatus(L("타이밍 재생 실패: ","Timing playback failed: ")+message);
        private void LoadWorkspace()
        {
            try
            {
                var latest=File.Exists(workspacePath)?JsonStore.Read<Workspace>(workspacePath,Guard.Drafts):new Workspace();
                workspace=latest; workspaceSignature=JsonStore.Hash(latest); workspaceReadOnly=false; dirty=false;
            }
            catch(Exception e) { workspaceReadOnly=true; log.LogError("[WORKSPACE/READONLY] "+e); }
        }
        private void Touch() { dirty=true; }
        private void SaveWorkspace()
        {
            if(!dirty||workspace==null) return;
            if(workspaceReadOnly) { dirty=false; return; }
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(workspacePath));
                using(var fileLock=new FileStream(workspacePath+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None))
                {
                    if(File.Exists(workspacePath))
                    {
                        var existing=JsonStore.Read<Workspace>(workspacePath,Guard.Drafts);
                        Guard.Require(JsonStore.Hash(existing)==workspaceSignature,"Workspace changed externally; refusing to overwrite it.");
                    }
                    JsonStore.WriteAtomic(workspacePath,workspace,Guard.Drafts);
                    workspaceSignature=JsonStore.Hash(workspace); dirty=false;
                }
            }
            catch(Exception e)
            {
                // Keep the in-memory draft. Do not silently reset the original file.
                workspaceReadOnly=true; dirty=false;
                log.LogError("[WORKSPACE/SAVE] "+e);
                SetStatus(L("임시 편집 내용을 파일에 저장하지 못했습니다. 현재 내용은 메모리에 유지됩니다.","Draft could not be written. The current in-memory draft was retained."));
            }
        }
        private void OpenUi()
        {
            HangTrace.Note("UI/OPEN-REQUEST");
            if(visible||!Bridge.CoreBound)
            {
                if(!Bridge.CoreBound)
                {
                    log.LogError("[UI/BLOCKED/CORE] "+Bridge.Error);
                    SetStatus(L("게임 API 연결에 실패해 창을 열지 못했습니다. BepInEx 로그를 확인해주세요.",
                        "Game API binding failed. Check BepInEx logs."));
                }
                return;
            }
            RefreshContext();
            if(!patches.ModalPatched)
            {
                log.LogError("[UI/BLOCKED/MODAL] Essential input guards unavailable; not opening an unsafe input modal.");
                SetStatus(L("입력 보호 API 또는 패치가 맞지 않아 창을 열 수 없습니다. 로그의 [API/MODAL]을 확인해주세요.",
                    "Required modal input guards did not bind. Check [API/MODAL] and [PATCH] in the log."));
                return;
            }
            if(!Bridge.Alive||Bridge.Typing||Bridge.GameMenuOpen)
            {
                log.LogInfo("[UI/WAIT] alive="+Bridge.Alive+"; typing="+Bridge.Typing+"; gameMenu="+Bridge.GameMenuOpen+". Local alive player required.");
                SetStatus(L("플레이어가 준비되고 채팅/메뉴를 닫은 뒤 다시 시도해주세요.",
                    "Wait for the player and close chat/menu before reopening."));
                return;
            }
            try
            {
                try { settings.File.Reload(); } catch(Exception e) { log.LogWarning("[CONFIG/PREFERENCES] "+e.Message); }
                language=settings.Language.Value;
                repository.Reload();
                // Drafts are retained in memory after any failed write, not replaced with old disk contents.
                if(!dirty&&!workspaceReadOnly&&recordingDraft==null) LoadWorkspace();
                uiMoon=Bridge.CurrentMoon; unknownMoon=Bridge.RawMoon; deleteSlot=-1; reorderMode=false; reorderFrom=-1;
                RefreshSnapshot();
                // Do not take the input lease until the full hidden visual tree is ready.
                if(!uiReady)
                {
                    openWhenUiReady=true; EnsureRetainedUi();
                    HangTrace.Note("UI/OPEN-DEFERRED building"); return;
                }
                openWhenUiReady=false; uiFaulted=false; LineupUiText.ResetFault();
                if(uiRoot!=null&&!uiRoot.activeSelf) uiRoot.SetActive(true);
                HangTrace.Note("INPUT/ACQUIRE-BEGIN"); inputLease.Acquire(Bridge); HangTrace.Note("INPUT/ACQUIRE-END");
                EnsureEventSystem();
                ghost.SetView(null,false);
                if(!settings.OverlayEnabled.Value)ghost.Clear();
                HangTrace.Note("UI/OPEN-STATE overlayEnabled="+settings.OverlayEnabled.Value+"; preparedMeshes="+ghost.MeshCount+"; overlayRendering=False; nativeCursorWrites=0");
                uiCommands.Invalidate(); visible=true; nextUiSync=0; TickRetainedUi();
                if(repository.ReadOnly) SetStatus(L("좌표 설정 오류: 읽기 전용입니다. ","Lineup config is read-only: ")+repository.Error);
                else if(workspaceReadOnly) SetStatus(L("편집 임시 파일 오류: 현재 편집 내용을 보존하고 있습니다.","Workspace error: keeping the current draft in memory."));
                log.LogInfo("[UI/SHOW] moon="+(uiMoon?.Key??unknownMoon)+"; session="+session+"; language="+language);
            }
            catch(Exception e)
            {
                HangTrace.Note("UI/OPEN-FAILED "+e.GetType().Name);
                visible=false;
                try { HideRetainedUi(); } catch(Exception cleanup) { log.LogWarning("[UI/CLEANUP] "+cleanup); }
                try { inputLease.Release(); } catch(Exception cleanup) { log.LogWarning("[INPUT/CLEANUP] "+cleanup); }
                log.LogError("[UI/OPEN] "+e);
            }
        }
        private void RefreshSnapshot()
        {
            snapshot=uiMoon==null?null:Enumerable.Range(0,8).Select(i=>repository.Get(uiMoon.Key,i)).ToArray();
            slotOrder=uiMoon==null?SlotOrdering.Identity().ToArray():repository.GetOrder(uiMoon.Key).ToArray();
            orderBaseline=uiMoon==null?null:repository.OrderSignature(uiMoon.Key);
        }
        private void ToggleReorder()
        {
            if(uiMoon==null||repository.ReadOnly||workspaceReadOnly||recordingDraft!=null) return;
            reorderMode=!reorderMode; reorderFrom=-1;
            SetStatus(reorderMode?
                L("옮길 슬롯을 선택한 뒤, 이동할 칸을 눌러주세요. 변경할 때마다 저장됩니다.","Select a slot, then its destination. Every move is saved immediately."):
                L("슬롯 순서 변경을 마쳤습니다.","Slot reordering finished."));
        }
        private void ReorderAt(int position)
        {
            if(!reorderMode||uiMoon==null||repository.ReadOnly||workspaceReadOnly||recordingDraft!=null) return;
            if(reorderFrom<0) { reorderFrom=position; return; }
            if(reorderFrom==position) { reorderFrom=-1; return; }
            try
            {
                var from=reorderFrom; var movedId=slotOrder[from];
                var order=SlotOrdering.Move(slotOrder,from,position);
                repository.Reorder(uiMoon.Key,order,orderBaseline);
                // Slot IDs are stable, so pending drafts and their conflict baselines are untouched.
                RefreshSnapshot(); reorderFrom=-1;
                SetStatus(L("슬롯 순서를 저장했습니다. ","Slot order saved. ")+(from+1)+" → "+(position+1));
                log.LogInfo("[CONFIG/ORDER] moon="+uiMoon.Key+"; stableSlot="+movedId+"; display="+(from+1)+"->"+(position+1)+
                    "; order="+string.Join(",",slotOrder)+"; atomic round-trip/read-back complete. Drafts/data not reassigned.");
            }
            catch(Exception e)
            {
                reorderFrom=-1;
                SetStatus(L("순서 변경 실패: ","Reordering failed: ")+e.Message); log.LogError("[CONFIG/ORDER] "+e);
            }
        }
        private void SetStatus(string message) { status=message; statusUntil=Time.realtimeSinceStartupAsDouble+20; }
        private bool SamePhysicalMoon()
        {
            if(uiMoon==null||Bridge.CurrentMoon?.Key!=uiMoon.Key)
            { SetStatus(L("위성이 변경되었습니다. F10으로 닫았다가 다시 열어주세요.","Moon changed. Close and reopen with F10.")); return false; }
            if(!Bridge.Landed) { SetStatus(L("위성에 착륙한 뒤 사용할 수 있습니다.","Available after landing on the moon.")); return false; }
            return true;
        }
        private void BeginEdit(int slot)
        {
            if(uiMoon==null||repository.ReadOnly||workspaceReadOnly) return;
            var draft=workspace.Find(uiMoon.Key,slot);
            if(draft==null)
            {
                var value=snapshot[slot];
                draft=new Draft { Moon=uiMoon.Key,Slot=slot,Step=0,Baseline=repository.Signature(uiMoon.Key,slot),
                    Data=value==null?new Lineup():JsonStore.Clone(value),TimingComplete=value!=null };
                workspace.Drafts.Add(draft);
            }
            workspace.View(uiMoon.Key).ActiveDraftSlot=slot; Touch(); SaveWorkspace();
        }
        private void ShowGrid()
        {
            if(uiMoon==null) return;
            workspace.View(uiMoon.Key).ActiveDraftSlot=-1; Touch(); SaveWorkspace();
        }
        private void DiscardDraft()
        {
            var draft=ActiveDraft; if(draft==null) return;
            if(recordingDraft==draft) FinishRecording(true);
            workspace.Drafts.Remove(draft); workspace.View(uiMoon.Key).ActiveDraftSlot=-1; Touch(); SaveWorkspace();
        }
        private void CapturePosition()
        {
            var draft=ActiveDraft; if(draft==null||!SamePhysicalMoon()) return;
            try
            {
                var vehicle=Bridge.FindVehicle(true);
                if(vehicle==null) { SetStatus(L("탑승 중이거나 30m 이내에 있는 크루저가 필요합니다.","Enter a Cruiser or stand within 30 m of one.")); return; }
                draft.Data.Pose=Bridge.Pose(vehicle); Guard.Pose(draft.Data.Pose);
                Touch(); SaveWorkspace(); SetStatus(L("크루저 위치와 방향을 저장했습니다.","Cruiser position and orientation captured."));
                log.LogInfo("[CAPTURE/POSE] moon="+draft.Moon+"; slot="+draft.Slot+"; source="+vehicle.GetInstanceID());
            }
            catch(Exception e) { SetStatus(L("위치 저장 실패: ","Pose capture failed: ")+e.Message); log.LogError("[CAPTURE/POSE] "+e); }
        }
        private void StartRecording()
        {
            var draft=ActiveDraft; if(draft==null||!SamePhysicalMoon()) return;
            if(!patches.RecordingPatched) { SetStatus(L("점프 입력 패치를 확인하지 못해 녹화를 사용할 수 없습니다.","Recording is unavailable because the jump callback patch was not verified.")); return; }
            var vehicle=Bridge.FindVehicle(true);
            if(vehicle==null||!Bridge.IsLocalVehicle(vehicle))
            { SetStatus(L("크루저 운전석에 탑승한 상태에서 녹화를 시작해주세요.","Start recording while controlling the Cruiser from the driver's seat.")); return; }
            pendingPreview=null; audio.Stop(); recordingDraft=draft; recordingVehicle=vehicle; draft.TimingComplete=false;
            draft.Data.JumpTimesMs.Clear(); recorder.Start(); armedAt=Time.realtimeSinceStartupAsDouble; Touch();
            CloseUi();
            log.LogInfo("[RECORD/ARM] moon="+draft.Moon+"; slot="+draft.Slot+"; waiting for first actual jump input event.");
        }
        public void OnJumpInput(object vehicle,double inputTime)
        {
            if(recordingDraft==null||!recorder.Recording||visible||Bridge.Typing||Bridge.GameMenuOpen||
               vehicle!=recordingVehicle||!Bridge.Alive||!Bridge.Landed||Bridge.CurrentMoon?.Key!=recordingDraft.Moon) return;
            if(recorder.Press(inputTime))
            {
                recordingDraft.Data.JumpTimesMs=recorder.Times.ToList(); Touch();
                if(recorder.Count==1) log.LogInfo("[RECORD/FIRST] Input event timestamp anchored to 0 ms.");
            }
            else if(!recorder.Recording) FinishRecording(true);
        }
        public void RecordingFault(Exception error)
        { log.LogError("[RECORD/INPUT] "+error); FinishRecording(true); }
        private void FinishRecording(bool interrupted)
        {
            if(recordingDraft==null) return;
            var draft=recordingDraft; var times=recorder.Stop();
            recordingDraft=null; recordingVehicle=null;
            draft.Data.JumpTimesMs=times; draft.TimingComplete=times.Count>0;
            Touch(); SaveWorkspace();
            SetStatus(times.Count==0?L("점프 입력이 없어 저장할 타이밍이 없습니다.","No jump inputs were recorded."):
                (interrupted?L("녹화가 중단되어 현재까지의 입력을 보관했습니다.","Recording interrupted; captured inputs were retained."):
                    L("점프 타이밍을 저장했습니다.","Jump timings captured.")));
            log.LogInfo("[RECORD/STOP] events="+times.Count+"; finalMs="+(times.Count==0?0:times[times.Count-1])+"; interrupted="+interrupted);
        }
        private void CommitDraft()
        {
            var draft=ActiveDraft; if(draft==null||workspaceReadOnly||repository.ReadOnly) return;
            if(recordingDraft!=null) { SetStatus(L("먼저 녹화를 종료해주세요.","Stop recording first.")); return; }
            try
            {
                if(!draft.TimingComplete) throw new Core.InvalidDataException("Complete the jump timing recording first.");
                draft.Data.Name=draft.Data.Name.Trim(); Guard.Data(draft.Data);
                repository.Commit(draft.Moon,draft.Slot,draft.Data,draft.Baseline);
                workspace.Drafts.Remove(draft); workspace.View(draft.Moon).ActiveDraftSlot=-1; Touch(); SaveWorkspace();
                RefreshSnapshot(); SetStatus(L("슬롯을 저장했습니다.","Slot saved."));
                log.LogInfo("[CONFIG/COMMIT] moon="+draft.Moon+"; slot="+draft.Slot+"; C# round-trip and disk read-back verified.");
            }
            catch(Exception e) { SetStatus(L("슬롯 저장 실패: ","Slot save failed: ")+e.Message); log.LogError("[CONFIG/COMMIT] "+e); }
        }
        private void RequestDelete(int slot)
        { if(uiMoon==null) return; deleteSlot=slot; deleteBaseline=repository.Signature(uiMoon.Key,slot); }
        private void ConfirmDelete()
        {
            if(uiMoon==null||deleteSlot<0) return;
            try
            {
                repository.Commit(uiMoon.Key,deleteSlot,null,deleteBaseline);
                var draft=workspace.Find(uiMoon.Key,deleteSlot);
                if(draft!=null) { if(recordingDraft==draft) FinishRecording(true); workspace.Drafts.Remove(draft); }
                if(workspace.View(uiMoon.Key).ActiveDraftSlot==deleteSlot) workspace.View(uiMoon.Key).ActiveDraftSlot=-1;
                Touch(); SaveWorkspace(); ghost.Clear(); RefreshSnapshot(); deleteSlot=-1;
                SetStatus(L("슬롯을 삭제했습니다.","Slot deleted."));
            }
            catch(Exception e) { deleteSlot=-1; SetStatus(L("슬롯 삭제 실패: ","Delete failed: ")+e.Message); log.LogError("[CONFIG/DELETE] "+e); }
        }
        // Pointer events enqueue commands; Update dispatches them. Load additionally captures
        // its session/moon so a route change cannot apply an old world's preview.
        private void QueuePreview(Action action,string moon)
        {
            pendingPreview=action; pendingPreviewSession=session;
            pendingPreviewMoon=moon; 
        }
        private void ProcessPreview()
        {
            if(pendingPreview==null) return;
            var action=pendingPreview; pendingPreview=null;
            if(pendingPreviewSession!=session||!Bridge.Alive||Bridge.CurrentMoon?.Key!=pendingPreviewMoon)
            { HangTrace.Note("PREVIEW/CANCELED context changed"); return; }
            HangTrace.Note("PREVIEW/BEGIN");
            try { action(); }
            finally { HangTrace.Note("PREVIEW/END"); }
        }
        private void LoadSlot(int index)
        {
            if(snapshot==null||index<0||index>=snapshot.Length||snapshot[index]==null||!SamePhysicalMoon()) return;
            var data=JsonStore.Decode<Lineup>(JsonStore.Encode(snapshot[index]));
            var moon=uiMoon.Key;
            QueuePreview(()=>
            {
                try
                {
                    HangTrace.Note("OVERLAY/CAPTURE-BEGIN");
                    if(settings.OverlayEnabled.Value)
                        ghost.Load(Bridge.FindVehicle(false),data,moon,settings.Opacity.Value,Bridge);
                    else { ghost.Clear(); HangTrace.Note("OVERLAY/BYPASS disabled; mesh/shader/material calls=0"); }
                    HangTrace.Note("OVERLAY/CAPTURE-END"); chat.Enqueue(data,session);
                }
                catch(Exception e) { SetStatus(L("불러오기 실패: ","Load failed: ")+e.Message); log.LogError("[OVERLAY/LOAD] "+e); }
            },moon);
            CloseUi();
        }
        private void Listen(Lineup data)
        {
            if(data==null||uiMoon==null) return;
            var copy=JsonStore.Decode<Lineup>(JsonStore.Encode(data)); var moon=uiMoon.Key;
            SetStatus("");
            HangTrace.Note("AUDIO/BUTTON");
            try { audio.Play(Bridge.JumpClip,copy.JumpTimesMs,moon,settings.Volume.Value); }
            catch(Exception e) { SetStatus(L("타이밍 재생 실패: ","Timing playback failed: ")+e.Message); log.LogError("[AUDIO/START] "+e); }
        }
        private void OnDisable()
        {
            if(!initialized||disposed) return;
            pendingPreview=null;
            try { FinishRecording(true); CloseUi(true); SaveWorkspace(); }
            catch(Exception e) { log.LogError("[LIFECYCLE/SAVE] "+e); }
            finally { if(uiBuild.Running) { Cleanup(DestroyUiResources); uiPrebuildAttempted=false; }
                Cleanup(()=>inputLease?.Release()); Cleanup(()=>ghost?.Clear()); Cleanup(()=>audio?.Stop()); Cleanup(Unsubscribe); Cleanup(()=>trace?.Stop()); }
            if(!Plugin.Quitting) log.LogWarning("[LIFECYCLE] Runtime OnDisable. Resources released; OnEnable may resume. No recreation during quit.");
        }
        private void OnApplicationQuit()
        {
            Plugin.Quitting=true; pendingPreview=null;
            try { if(initialized) { FinishRecording(true); SaveWorkspace(); } }
            catch(Exception e) { log?.LogError("[LIFECYCLE/QUIT-SAVE] "+e); }
            finally
            {
                Cleanup(()=>inputLease?.Release()); Cleanup(Unsubscribe);
                Cleanup(()=>trace?.Stop()); Cleanup(()=>consoleGuard?.Dispose());
            }
        }
        private void Cleanup(Action action)
        { try { action(); } catch(Exception e) { log?.LogError("[LIFECYCLE/CLEANUP] "+e); } }
        private void OnDestroy()
        {
            if(disposed) return; disposed=true;
            Cleanup(Unsubscribe); Cleanup(()=>inputLease?.Release());
            if(audio!=null) { audio.Failed-=AudioFailed; audio.Started-=AudioStarted; }
            Cleanup(()=>audio?.Dispose());
            Cleanup(()=>ghost?.Dispose()); Cleanup(DestroyUiResources); Cleanup(()=>systemText?.Dispose()); Cleanup(()=>patches?.Dispose());
            pendingPreview=null; Cleanup(()=>trace?.Dispose()); Cleanup(()=>consoleGuard?.Dispose());
            if(Current==this) Current=null;
            if(!Plugin.Quitting) log?.LogWarning("[LIFECYCLE] Runtime OnDestroy. Only this mod's patches/resources were removed.");
        }
    }
}
