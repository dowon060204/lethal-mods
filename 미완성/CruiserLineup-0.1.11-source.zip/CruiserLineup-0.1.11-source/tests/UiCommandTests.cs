using System;
using CruiserLineup.Core;
internal static class UiCommandTests
{
    private static void Need(bool value,string message){if(!value)throw new Exception(message);}
    public static void Register(Action<string,Action> Test)
    {
        Test("UI queue: click callback never executes application action",()=>{var q=new UiCommandQueue();int n=0;Need(q.Enqueue("listen",()=>n++),"not queued");Need(n==0,"callback executed inline");});
        Test("UI queue: one accepted click executes exactly once",()=>{var q=new UiCommandQueue();int n=0;q.Enqueue("load",()=>n++);Need(q.TryTake(out var name,out var action)&&name=="load","wrong command");action();Need(!q.TryTake(out _,out _)&&n==1,"duplicate execution");});
        Test("UI queue: double clicks cannot accumulate work",()=>{var q=new UiCommandQueue();q.Enqueue("one",()=>{});Need(!q.Enqueue("two",()=>{}),"unbounded queue");});
        Test("UI queue: close invalidates an unexecuted click",()=>{var q=new UiCommandQueue();q.Enqueue("old",()=>throw new Exception("stale"));q.Invalidate();Need(!q.TryTake(out _,out _),"stale view click survived");});
        Test("UI queue: next view can enqueue after invalidation",()=>{var q=new UiCommandQueue();q.Enqueue("old",()=>{});q.Invalidate();q.Enqueue("new",()=>{});Need(q.TryTake(out var name,out _)&&name=="new","new view lost");});
        Test("UI queue: an exception cannot leave completed command queued",()=>{var q=new UiCommandQueue();q.Enqueue("throws",()=>throw new Exception("test"));q.TryTake(out _,out var a);try{a();}catch{}Need(!q.Pending,"fault kept queued action");});
        Test("UI queue: null actions rejected before state mutation",()=>{var q=new UiCommandQueue();try{q.Enqueue("null",null);throw new Exception("accepted");}catch(ArgumentNullException){}Need(!q.Pending,"state mutated");});
        Test("UI queue: 10000 click-close cycles retain no work",()=>{var q=new UiCommandQueue();for(int i=0;i<10000;i++){q.Enqueue("x",()=>{});q.Invalidate();}Need(!q.Pending,"work retained");});
    }
}
