// TEST-ONLY fake external APIs. Not Unity, Input System, BepInEx or game execution.
// The plugin explicitly compiles only src/**/*.cs, so these types cannot be distributed in its DLL.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx.Logging;

namespace HarmonyLib
{
    public static class AccessTools
    {
        public static FieldInfo Field(Type type,string name) => type.GetField(name,
            BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic);
    }
}
namespace UnityEngine
{
    public struct Vector2
    {
        public float x,y;
        public Vector2(float x,float y) {this.x=x;this.y=y;}
        public static Vector2 zero => new Vector2(0,0);
    }
    public static partial class Time { public static int frameCount; }
    public enum CursorLockMode { None,Locked,Confined }
    public static class Cursor
    {
        public static int Writes;
        private static bool shown;
        public static bool visible {get=>shown;set{Writes++;shown=value;}}
        public static bool FailLock;
        private static CursorLockMode currentLock;
        public static CursorLockMode lockState
        {
            get=>currentLock;
            set {Writes++;if(FailLock&&value==CursorLockMode.Locked)throw new InvalidOperationException("test cursor failure"); currentLock=value;}
        }
    }
}
namespace UnityEngine.InputSystem
{
    public class InputDevice
    {
        public bool added=true;
        public Controls.InputControl[] allControls=Array.Empty<Controls.InputControl>();
    }
    public class InputActionAsset { }
    public class InputActionMap { public InputActionAsset asset; }
    public class InputAction
    {
        public bool enabled;
        public InputActionMap actionMap;
        public bool FailEnable,FailDisable;
        public Action OnEnable;
        public int Enables,Disables;
        public void Enable()
        {
            if(FailEnable)throw new ObjectDisposedException("test action");
            enabled=true;Enables++;OnEnable?.Invoke();
        }
        public void Disable()
        {
            if(FailDisable)throw new InvalidOperationException("test disable failure");
            enabled=false;Disables++;
        }
    }
    public static class InputSystem
    {
        public static readonly List<InputAction> Actions=new List<InputAction>();
        public static event Action onBeforeUpdate;
        public static int SubscriberCount=>onBeforeUpdate?.GetInvocationList().Length??0;
        public static IEnumerable<InputAction> ListEnabledActions()=>Actions.Where(a=>a.enabled);
        public static void BeforeUpdate()=>onBeforeUpdate?.Invoke();
        public static void Reset(){Actions.Clear();onBeforeUpdate=null;}
    }
    public class Keyboard : InputDevice
    {
        public static Keyboard CurrentValue;
        public static int CurrentReads;
        public static bool CurrentDisappearsAfterFirstRead;
        public static Keyboard current
        {
            get {CurrentReads++;return CurrentDisappearsAfterFirstRead&&CurrentReads>1?null:CurrentValue;}
            set {CurrentValue=value;CurrentReads=0;}
        }
        public Controls.KeyControl[] Keys=Array.Empty<Controls.KeyControl>();
        public bool ThrowKeyEnumeration,ThrowIme;
        public Controls.KeyControl[] allKeys
        {get {if(ThrowKeyEnumeration)throw new InvalidOperationException("test keyboard layout removed");return Keys;}}
        public Controls.ButtonControl imeSelected;
        public bool ImeEnabled;
        public void SetIMEEnabled(bool value)
        {if(ThrowIme)throw new InvalidOperationException("test IME unavailable");ImeEnabled=value;}
    }
    public class Mouse : InputDevice
    {
        public static Mouse current;
        public Controls.ButtonControl leftButton,rightButton,middleButton,forwardButton,backButton;
    }
    public class Gamepad : InputDevice { public static Gamepad current; }
}
namespace UnityEngine.InputSystem.Controls
{
    public class InputControl { public UnityEngine.InputSystem.InputDevice device; }
    public class ButtonControl : InputControl
    {
        public bool Down,ThrowRead;
        public bool isPressed
        {get {if(ThrowRead)throw new InvalidOperationException("test control removed");return Down;}}
    }
    public class KeyControl : ButtonControl { }
}
namespace CruiserLineup
{
    public class GameBridge
    {
        public UnityEngine.Component LocalPlayer;
        public readonly GameInputTargets Targets=new GameInputTargets();
        public GameInputTargets GameInputs()=>Targets;
    }
    public sealed class TestPlayer : UnityEngine.Component
    {
        public bool disableMoveInput,disableLookInput;
        public UnityEngine.Vector2 moveInputVector;
    }
    // Harness shell around the actual production ModalClose.cs method; no replacement CloseUi implementation.
    public sealed partial class LineupRuntime
    {
        public static LineupRuntime Current;
        private bool visible,reorderMode;
        private int deleteSlot=-1,reorderFrom=-1,blockUntilFrame=-1;
        private InputLease inputLease;
        private ManualLogSource log;
        public bool FailSave;
        public int Saves,Faults;
        public int RenderFaults; public string RenderReason;
        public void RequestUiSafetyClose(string message) {RenderFaults++;RenderReason=message;}
        private void CancelPendingUiOpen() { }
        private void HideRetainedUi() { } // UGUI engine lifecycle is NOT simulated by this input harness.
        private void SaveWorkspace(){Saves++;if(FailSave)throw new System.IO.IOException("test read-only workspace");}
        public void InputFault(){Faults++;CloseUi(true);}
        public void TestMount(InputLease lease,ManualLogSource logger)
        {inputLease=lease;log=logger;visible=true;Current=this;}
        public void TestClose(bool immediate=false)=>CloseUi(immediate);
        public void TestMakeInvisible()=>visible=false;
        public bool TestVisible=>visible;
        public int TestBlockFrame=>blockUntilFrame;
        public bool TestUiSelectionCleared=>deleteSlot==-1&&!reorderMode&&reorderFrom==-1;
    }
}
