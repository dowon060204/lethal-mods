using System;
using System.Collections;
using System.Linq;
using BepInEx.Logging;
using CruiserLineup;
using CruiserLineup.Core;
using UnityEngine;
using UnityEngine.UI;

internal static class UiRegressionTests
{
    private static void Check(bool value,string label="assertion") {if(!value)throw new Exception(label);}
    private sealed class Steps : IEnumerator,IDisposable
    {
        public int Moves,Disposals;
        public int Count=3;
        public bool FailMove,FailDispose;
        public object Current=>null;
        public bool MoveNext(){Moves++;if(FailMove)throw new InvalidOperationException("fixture failure");return Moves<=Count;}
        public void Reset()=>throw new NotSupportedException();
        public void Dispose(){Disposals++;if(FailDispose)throw new InvalidOperationException("fixture dispose failure");}
    }
    public static void Register(Action<string,Action> test)
    {
        test("UI build: begin never executes a Unity construction step",()=>{using var b=new UiFrameBuild();var s=new Steps();b.Begin(s);Check(s.Moves==0&&b.Running);});
        test("UI build: at most one step in the same frame",()=>{using var b=new UiFrameBuild();var s=new Steps();b.Begin(s);for(int i=0;i<10000;i++)b.Tick(1);Check(s.Moves==1);});
        test("UI build: separate frames advance separate steps",()=>{using var b=new UiFrameBuild();var s=new Steps();b.Begin(s);b.Tick(1);b.Tick(2);Check(s.Moves==2&&!b.Completed);});
        test("UI build: completion only after enumerator ends",()=>{using var b=new UiFrameBuild();var s=new Steps();b.Begin(s);for(int i=0;i<4;i++)b.Tick(i);Check(b.Completed&&!b.Running&&s.Disposals==1);});
        test("UI build: cancellation disposes partial tree routine once",()=>{using var b=new UiFrameBuild();var s=new Steps();b.Begin(s);b.Tick(1);b.Cancel();b.Cancel();b.Tick(2);Check(s.Moves==1&&s.Disposals==1&&!b.Completed);});
        test("UI build: a second concurrent routine is rejected",()=>{using var b=new UiFrameBuild();b.Begin(new Steps());bool rejected=false;try{b.Begin(new Steps());}catch(InvalidOperationException){rejected=true;}Check(rejected);});
        test("UI build: managed exception is not retried every Update",()=>{using var b=new UiFrameBuild();var s=new Steps{FailMove=true};b.Begin(s);b.Tick(0);for(int i=1;i<100;i++)b.Tick(i);Check(b.Error!=null&&s.Moves==1&&s.Disposals==1&&!b.Running);});
        test("UI build: endless yielded routine is bounded",()=>{using var b=new UiFrameBuild(3);var s=new Steps{Count=int.MaxValue};b.Begin(s);for(int i=0;i<6;i++)b.Tick(i);Check(b.Error!=null&&s.Moves==3&&s.Disposals==1);});
        test("UI build: explicit new build resets earlier failure",()=>{using var b=new UiFrameBuild();b.Begin(new Steps{FailMove=true});b.Tick(0);b.Begin(new Steps{Count=0});b.Tick(1);Check(b.Completed&&b.Error==null);});
        test("UI build: dispose failure is never reported completed",()=>{using var b=new UiFrameBuild();var s=new Steps{Count=0,FailDispose=true};b.Begin(s);b.Tick(0);Check(b.Error!=null&&!b.Completed&&s.Disposals==1);});
        test("UI budget: normal single-frame text population allowed",()=>{var b=new UiRenderBudget(3);Check(b.Enter(0)&&b.Enter(0)&&b.Enter(0));});
        test("UI budget: rebuild flood latches and does not auto-retry",()=>{var b=new UiRenderBudget(2);b.Enter(0);b.Enter(0);Check(!b.Enter(0)&&b.Fault!=null&&!b.Enter(1));});
        test("UI budget: new frames reset normal count",()=>{var b=new UiRenderBudget(1);for(int i=0;i<100;i++)Check(b.Enter(i));});
        test("UI budget: explicit reopen clears latched error",()=>{var b=new UiRenderBudget(1);b.Fail("fixture");b.Reset();Check(b.Fault==null&&b.Enter(0));});
        test("UI budget: first error is retained",()=>{var b=new UiRenderBudget();b.Fail("first");b.Fail("second");Check(b.Fault=="first");});
        test("System text: one cached native font for repeated UI access",()=>{Font.Reset();using var service=new SystemUiText(new ManualLogSource());var f=service.Get();for(int i=0;i<10000;i++)Check(ReferenceEquals(f,service.Get()));Check(Font.Creates==1&&Font.Requests==1);});
        test("System text: no designer font families or whole Hangul atlas",()=>{Font.Reset();using var service=new SystemUiText(new ManualLogSource());service.Get();Check(Font.LastFamilies.Contains("Malgun Gothic")&&!Font.LastFamilies.Any(n=>n.Contains("Orbit")||n.Contains("3270")));Check(Font.LastCharacters.Length<100);});
        test("System text: Korean probe result is preserved",()=>{Font.Reset();Font.Hangul=false;using var service=new SystemUiText(new ManualLogSource());service.Get();Check(service.Attempted&&!service.KoreanSampleSupported);});
        test("System text: native creation failure is attempted only once",()=>{Font.Reset();Font.FailCreate=true;using var service=new SystemUiText(new ManualLogSource());for(int i=0;i<5;i++){try{service.Get();}catch(InvalidOperationException){}}Check(Font.Creates==1);});
        test("System text: probe error cannot leak an owned font",()=>{Font.Reset();Font.FailRequest=true;int before=UnityEngine.Object.All.Count;using var service=new SystemUiText(new ManualLogSource());try{service.Get();}catch(InvalidOperationException){}Check(UnityEngine.Object.All.Skip(before).OfType<Font>().All(f=>f.Destroyed));});
        test("System text: dispose destroys own font only",()=>{Font.Reset();var other=new Font();var service=new SystemUiText(new ManualLogSource());var own=service.Get();service.Dispose();service.Dispose();Check(own.Destroyed&&!other.Destroyed);});
        test("System text: disposed cache cannot recreate native objects",()=>{Font.Reset();var service=new SystemUiText(new ManualLogSource());service.Dispose();bool rejected=false;try{service.Get();}catch(ObjectDisposedException){rejected=true;}Check(rejected&&Font.Creates==0);});
        test("UI text: renderer exception is deferred instead of thrown",()=>{LineupUiText.ResetFault();Text.NativeCalls=0;Text.Reenter=null;Text.FailNative=true;var r=new LineupRuntime();LineupRuntime.Current=r;var t=new GameObject("fixture").AddComponent<LineupUiText>();var m=new VertexHelper();t.TestPopulate(m);Check(m.Clears==1&&r.RenderFaults==1);Text.FailNative=false;LineupRuntime.Current=null;LineupUiText.ResetFault();});
        test("UI text: native renderer is not repeatedly called after a fault",()=>{LineupUiText.ResetFault();Text.NativeCalls=0;Text.Reenter=null;Text.FailNative=true;var t=new GameObject("fixture").AddComponent<LineupUiText>();var m=new VertexHelper();t.TestPopulate(m);Text.FailNative=false;t.TestPopulate(m);Check(Text.NativeCalls==1);LineupUiText.ResetFault();});
        test("UI text: reentrant mesh generation is bounded",()=>{LineupUiText.ResetFault();Text.NativeCalls=0;Text.FailNative=false;var t=new GameObject("fixture").AddComponent<LineupUiText>();var m=new VertexHelper();Text.Reenter=()=>t.TestPopulate(m);t.TestPopulate(m);Text.Reenter=null;Check(Text.NativeCalls==1&&m.Clears==1);LineupUiText.ResetFault();});
    }
}
