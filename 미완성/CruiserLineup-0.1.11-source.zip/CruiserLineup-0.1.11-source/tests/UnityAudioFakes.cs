// TEST-ONLY API fakes. This file is NEVER included in the plugin project.
// Executing these tests does not execute Unity or a physical audio device.
using System;
using System.Collections.Generic;
using System.Linq;

namespace BepInEx.Logging
{
    public sealed class ManualLogSource
    {
        public readonly List<string> Entries = new List<string>();
        public void LogInfo(object value) => Entries.Add("INFO " + value);
        public void LogWarning(object value) => Entries.Add("WARN " + value);
        public void LogError(object value) => Entries.Add("ERROR " + value);
    }
}
namespace CruiserLineup { internal static class Plugin { public static bool Quitting; public const string Version="0.1.11-TEST"; } }
namespace UnityEngine
{
    public enum HideFlags { None=0, HideAndDontSave=61 }
    public class Object
    {
        internal static readonly List<Object> All = new List<Object>();
        public string name = "";
        public HideFlags hideFlags;
        public bool Destroyed;
        public Object() { All.Add(this); }
        public static T[] FindObjectsOfType<T>() where T : Object => All.OfType<T>().Where(x => !x.Destroyed && (!(x is Component c) || (c.gameObject!=null && !c.gameObject.Destroyed))).ToArray();
        public static void DontDestroyOnLoad(Object value) { }
        public static void Destroy(Object value) { if(value!=null)value.Destroyed=true; }
    }
    public class Component : Object
    {
        public GameObject gameObject;
        public bool enabled=true;
        public bool isActiveAndEnabled => enabled && !Destroyed && gameObject!=null && gameObject.activeInHierarchy;
    }
    public sealed class Transform : Component { }
    public sealed class GameObject : Object
    {
        public bool activeInHierarchy=true;
        public Transform transform;
        public GameObject(string label) { name=label;transform=new Transform {gameObject=this}; }
        public void SetActive(bool value) { activeInHierarchy=value; }
        public T AddComponent<T>() where T:Component,new()
        {
            var value=new T {gameObject=this};
            if(value is AudioSource){Time.realtimeSinceStartupAsDouble+=FakeAudio.SourceCreationDelay;AudioSettings.dspTime+=FakeAudio.SourceCreationDelay;}
            return value;
        }
    }
    public static partial class Time { public static double realtimeSinceStartupAsDouble; }
    public static class Mathf { public static float Clamp01(float value) => Math.Min(1f,Math.Max(0f,value)); }
    public enum AudioDataLoadState { Unloaded, Loading, Loaded, Failed }
    public enum AudioClipLoadType { DecompressOnLoad, CompressedInMemory, Streaming }
    public sealed class AudioClip : Object
    {
        public delegate void PCMReaderCallback(float[] data);
        public delegate void PCMSetPositionCallback(int position);
        public int samples,channels=1,frequency=48000;
        public AudioDataLoadState loadState=AudioDataLoadState.Loaded;
        public AudioClipLoadType loadType=AudioClipLoadType.DecompressOnLoad;
        public float[] Data;
        public bool Readable=true,LoadAccepted=true;
        public PCMReaderCallback Reader;
        public PCMSetPositionCallback Seeker;
        public bool LoadAudioData(){if(!LoadAccepted)return false;loadState=AudioDataLoadState.Loaded;return true;}
        public bool GetData(float[] data,int offset)
        {if(!Readable||Data==null||loadState!=AudioDataLoadState.Loaded)return false;Array.Copy(Data,offset*channels,data,0,data.Length);return true;}
        public static AudioClip Create(string name,int lengthSamples,int channels,int frequency,bool stream,PCMReaderCallback reader,PCMSetPositionCallback seeker)
        {
            if(FakeAudio.FailCreate)return null;
            if(!stream)throw new Exception("Regression: full-track native allocation path requested");
            return new AudioClip {name=name,samples=lengthSamples,channels=channels,frequency=frequency,Reader=reader,Seeker=seeker,loadType=AudioClipLoadType.Streaming};
        }
    }
    public sealed class AudioListener : Component {public static float volume=1f;public static bool pause;}
    public struct AudioConfiguration {public int sampleRate;public int numRealVoices;}
    public static class AudioSettings
    {
        public static int Rate=48000;
        public static double dspTime;
        public static AudioConfiguration GetConfiguration()=>new AudioConfiguration{sampleRate=Rate,numRealVoices=80};
    }
    public sealed class AudioSource : Component
    {
        public bool playOnAwake,loop,spatialize,spatializePostEffects,mute,ignoreListenerPause,ignoreListenerVolume;
        public bool bypassEffects,bypassListenerEffects,bypassReverbZones,isPlaying,isVirtual;
        public float spatialBlend,dopplerLevel,panStereo,volume,pitch;
        public int priority,timeSamples,PlayCalls,StopCalls;
        public readonly List<double> Scheduled=new List<double>();
        public void PlayScheduled(double time){Scheduled.Add(time);isPlaying=!FakeAudio.SuppressStart;timeSamples=0;}
        public object outputAudioMixerGroup;
        public AudioClip clip;
        public readonly List<float> Delivered=new List<float>();
        public void Play(){PlayCalls++;isPlaying=!FakeAudio.SuppressStart;timeSamples=0;clip?.Seeker?.Invoke(0);}
        public void Stop(){StopCalls++;isPlaying=false;}
        // A simulated native/audio-thread consumption step, independent of TimingAudio.Tick().
        public void AdvanceFrames(int count)
        {
            if(!isPlaying || (AudioListener.pause&&!ignoreListenerPause))return;
            var buffer=new float[count*clip.channels];clip.Reader(buffer);Delivered.AddRange(buffer);
            timeSamples=Math.Min(clip.samples,timeSamples+count);
            if(timeSamples>=clip.samples)isPlaying=false;
        }
    }
    internal static class FakeAudio
    {
        public static double SourceCreationDelay;
        public static bool FailCreate,SuppressStart;
        public static void Reset()
        {
            Object.All.Clear();Time.realtimeSinceStartupAsDouble=0;AudioListener.volume=0.48f;AudioListener.pause=false;
            AudioSettings.Rate=48000;AudioSettings.dspTime=0;SourceCreationDelay=0;FailCreate=SuppressStart=false;CruiserLineup.Plugin.Quitting=false;
        }
    }
}
