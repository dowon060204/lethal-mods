using System;
using CruiserLineup.Core;

internal static class UiPointerTests
{
    private static void Need(bool value) { if(!value) throw new Exception("pointer assertion"); }
    public static void Register(Action<string,Action> test)
    {
        test("UI pointer: initial position is the screen center",()=>{var p=new UiPointerState();p.Open(1920,1080);Need(p.X==960&&p.Y==540);});
        test("UI pointer: locked native mouse uses deltas rather than center position",()=>{var p=new UiPointerState();p.Open(1000,600);p.Step(1,true,27,-13,500,300,1000,600);Need(p.X==527&&p.Y==287);});
        test("UI pointer: same frame cannot accumulate raw mouse delta twice",()=>{var p=new UiPointerState();p.Open(1000,600);for(int i=0;i<10000;i++)p.Step(1,true,2,3,500,300,1000,600);Need(p.X==502&&p.Y==303);});
        test("UI pointer: successive frames each consume their own delta",()=>{var p=new UiPointerState();p.Open(1000,600);p.Step(1,true,5,2,0,0,1000,600);p.Step(2,true,5,2,0,0,1000,600);Need(p.X==510&&p.Y==304);});
        test("UI pointer: unlocked cursor uses actual absolute position",()=>{var p=new UiPointerState();p.Open(1000,600);p.Step(1,false,99,99,127,230,1000,600);Need(p.X==127&&p.Y==230);});
        test("UI pointer: screen edges are clamped",()=>{var p=new UiPointerState();p.Open(1000,600);p.Step(1,true,-99999,99999,0,0,1000,600);Need(p.X==0&&p.Y==599);});
        test("UI pointer: NaN and infinite deltas do not poison coordinates",()=>{var p=new UiPointerState();p.Open(1000,600);p.Step(1,true,float.NaN,float.PositiveInfinity,0,0,1000,600);Need(p.X==500&&p.Y==300);});
        test("UI pointer: malformed absolute coordinates retain previous position",()=>{var p=new UiPointerState();p.Open(1000,600);p.Step(1,false,0,0,float.NegativeInfinity,float.NaN,1000,600);Need(p.X==500&&p.Y==300);});
        test("UI pointer: reopening retains the prior virtual position",()=>{var p=new UiPointerState();p.Open(1000,600);p.Step(1,true,40,10,0,0,1000,600);p.Open(1000,600);Need(p.X==540&&p.Y==310);});
        test("UI pointer: reopen clamps coordinates to a smaller resolution",()=>{var p=new UiPointerState();p.Open(1920,1080);p.Open(320,200);Need(p.X==319&&p.Y==199);});
        test("UI pointer: invalid screen sizes remain finite",()=>{var p=new UiPointerState();p.Open(float.NaN,float.PositiveInfinity);p.Step(1,true,20,30,0,0,0,-1);Need(p.X==0&&p.Y==0);});
        test("UI pointer: locked to unlocked transition does not retain an offset",()=>{var p=new UiPointerState();p.Open(1000,600);p.Step(1,true,250,100,0,0,1000,600);p.Step(2,false,0,0,25,80,1000,600);Need(p.X==25&&p.Y==80);});
        test("UI pointer: ten thousand alternating frames have no time scaling drift",()=>{var p=new UiPointerState();p.Open(1000,600);for(int i=0;i<10000;i++)p.Step(i,true,i%2==0?1:-1,0,500,300,1000,600);Need(p.X==500&&p.Y==300);});
        test("UI pointer: implicit initialization is equivalent to explicit open",()=>{var p=new UiPointerState();p.Step(1,true,10,20,0,0,1000,600);Need(p.X==510&&p.Y==320);});
    }
}
