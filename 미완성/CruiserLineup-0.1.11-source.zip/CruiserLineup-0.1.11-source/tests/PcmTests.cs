using System;
using System.Collections.Generic;
using System.Linq;
using CruiserLineup.Core;

internal static class PcmTests
{
    private static void Eq<T>(T value, T expected)
    { if (!EqualityComparer<T>.Default.Equals(value, expected)) throw new Exception($"Expected {expected}, got {value}"); }
    private static void Near(float value, float expected)
    { if (Math.Abs(value - expected) > 0.000001f) throw new Exception($"Expected {expected}, got {value}"); }
    private static void Throws(Action action)
    { try { action(); } catch { return; } throw new Exception("Expected rejection"); }
    private static PcmTimeline Mono(float[] data, params int[] times) => new PcmTimeline(data, 1, 48000, times.ToList());
    public static void Register(Action<string, Action> Test)
    {
        Test("PCM first event starts at sample frame zero", () => { var t = Mono(new[]{0.4f, -0.2f}, 0); var a = new float[4]; t.Read(a); Near(a[0],0.4f); Near(a[1],-0.2f); Eq(a[2],0f); Eq(a[3],0f); Eq(t.TotalFrames,2); });
        Test("PCM millisecond offsets at 48 kHz are exact", () => { foreach (int ms in new[]{0,1,137,250,2656,600000}) Eq(PcmTimeline.MillisecondsToFrames(ms,48000),ms*48); });
        Test("PCM 44.1 kHz rounding error is at most half a sample", () => { for(int ms=0;ms<=10000;ms++) { double exact=ms*44.1; if(Math.Abs(PcmTimeline.MillisecondsToFrames(ms,44100)-exact)>0.5000001)throw new Exception("Excess rounding"); } });
        Test("PCM stereo channels remain interleaved without time doubling", () => { var t=new PcmTimeline(new[]{0.1f,-0.2f,0.3f,-0.4f},2,48000,new(){0,1}); var a=new float[102];t.Read(a);Near(a[0],0.1f);Near(a[1],-0.2f);Near(a[2],0.3f);Near(a[3],-0.4f);Near(a[96],0.1f);Near(a[97],-0.2f);Eq(t.TotalFrames,50); });
        Test("PCM five synthetic events with last offset 2656ms retain every onset", () => { var offsets=new List<int>{0,250,600,1500,2656};var t=new PcmTimeline(new[]{0.25f},1,48000,offsets);var a=new float[t.TotalFrames];t.Read(a);Eq(a.Count(v=>v!=0),5);foreach(var ms in offsets)Near(a[ms*48],0.25f); });
        Test("PCM callback buffer partition does not change the waveform", () => { var raw=new[]{0.1f,-0.1f,0.2f,-0.2f};var t=new PcmTimeline(raw,2,48000,new(){0,2,5});var expected=new float[t.TotalFrames*2];t.RenderAt(0,expected);var actual=new List<float>();for(int n=0;actual.Count<expected.Length;n++){var a=new float[(n%7+1)*2];t.Read(a);actual.AddRange(a);}for(int i=0;i<expected.Length;i++)Near(actual[i],expected[i]); });
        Test("PCM silence gap does not introduce extra events", () => { var t=Mono(new[]{0.5f},0,1000);var a=new float[1024];Eq(t.RenderAt(100,a),false);Eq(a.All(v=>v==0),true);t.RenderAt(47999,a);Near(a[1],0.5f); });
        Test("PCM entire final waveform tail is retained", () => {var t=Mono(new[]{0.1f,0.2f,0.3f},0,1);Eq(t.TotalFrames,51);var a=new float[4];t.RenderAt(48,a);Near(a[2],0.3f);Eq(a[3],0f); });
        Test("PCM overlapping original sounds are summed without dropping an event", () => {var data=Enumerable.Repeat(0.1f,96).ToArray();var t=Mono(data,0,1);var a=new float[144];t.Read(a);Eq(t.PeakOverlap,2);Eq(t.Gain,1f);Near(a[0],0.1f);Near(a[48],0.2f);Near(a[96],0.1f); });
        Test("PCM uniform headroom keeps dense overlaps finite and bounded", () => {var t=Mono(Enumerable.Repeat(0.9f,96).ToArray(),0,1);var a=new float[t.TotalFrames];t.Read(a);Eq(t.Gain<1,true);Eq(a.All(v=>!float.IsNaN(v)&&Math.Abs(v)<=1),true);Near(a[48],1f); });
        Test("PCM identical millisecond timestamps remain distinct events", () => {var t=Mono(new[]{0.1f},0,0,0);var a=new float[1];t.Read(a);Eq(t.EventCount,3);Near(a[0],0.3f); });
        Test("PCM endpoint touch is not overlapping", () => {var t=Mono(Enumerable.Repeat(0.5f,48).ToArray(),0,1);Eq(t.PeakOverlap,1);Eq(t.Gain,1f); });
        Test("PCM ten-minute timeline uses source-sized storage, not full-track allocation", () => {var t=Mono(new[]{0.25f,-0.25f},0,600000);Eq(t.TotalFrames,28800002);Eq(t.StorageBytes,16L);var a=new float[3];t.RenderAt(28800000,a);Near(a[0],0.25f);Near(a[1],-0.25f); });
        Test("PCM maximum 512 events fit and are not silently dropped", () => {var t=Mono(new[]{0.1f},Enumerable.Range(0,512).ToArray());Eq(t.EventCount,512);var a=new float[t.TotalFrames];t.Read(a);Eq(a.Count(v=>v!=0),512); });
        Test("PCM input arrays and saved timing list cannot mutate a running sequence", () => {float[] data={0.2f};var offsets=new List<int>{0,1};var t=new PcmTimeline(data,1,48000,offsets);data[0]=0;offsets[1]=10;var a=new float[49];t.Read(a);Near(a[0],0.2f);Near(a[48],0.2f);Eq(offsets[1],10); });
        Test("PCM seek position is a frame offset in stereo", () => {var t=new PcmTimeline(new[]{0.1f,-0.2f,0.3f,-0.4f},2,48000,new(){0});t.Seek(1);var a=new float[2];t.Read(a);Near(a[0],0.3f);Near(a[1],-0.4f); });
        Test("PCM seek clamp and rewind do not leave stale audio", () => {var t=Mono(new[]{0.3f},0);var a=new[]{9f,9f};t.Seek(999);t.Read(a);Eq(a.All(v=>v==0),true);t.Seek(-5);t.Read(a);Near(a[0],0.3f);Eq(a[1],0f); });
        Test("PCM end-of-stream fills every further buffer with silence", () => {var t=Mono(new[]{0.1f},0);var a=new float[256];t.Read(a);Array.Fill(a,9f);t.Read(a);Eq(a.All(v=>v==0),true);Eq(t.MaximumReadFrame,1L);Eq(t.NonSilentBuffers,1L); });
        Test("PCM callback diagnostics count work rather than claiming audibility", () => {var t=Mono(new[]{0.2f},0,100);t.Read(new float[32]);t.Read(new float[32]);Eq(t.ReadCalls,2L);Eq(t.NonSilentBuffers,1L);Eq(t.Position,64L); });
        Test("PCM malformed callback buffers are silenced without throwing", () => {var t=new PcmTimeline(new[]{0.2f,-0.2f},2,48000,new(){0});var a=new[]{9f,9f,9f};t.Read(a);t.Read(null);Eq(a.All(v=>v==0),true);Eq(t.MalformedBuffers,2L);Eq(t.Position,0L); });
        Test("PCM zero and invalid source data are rejected instead of silent success", () => {Throws(()=>Mono(new[]{0f,0f},0));Throws(()=>Mono(new[]{float.NaN},0));Throws(()=>Mono(new[]{float.PositiveInfinity},0));Throws(()=>Mono(Array.Empty<float>(),0));Throws(()=>Mono(null,0)); });
        Test("PCM invalid sample format is rejected before callback creation", () => {Throws(()=>new PcmTimeline(new[]{0.2f},0,48000,new(){0}));Throws(()=>new PcmTimeline(new[]{0.2f},9,48000,new(){0}));Throws(()=>new PcmTimeline(new[]{0.2f},2,48000,new(){0}));Throws(()=>new PcmTimeline(new[]{0.2f},1,0,new(){0}));Throws(()=>PcmTimeline.MillisecondsToFrames(600001,48000)); });
        Test("PCM malformed timing keeps existing validation", () => {Throws(()=>Mono(new[]{0.2f},1));Throws(()=>Mono(new[]{0.2f},0,3,2));Throws(()=>Mono(new[]{0.2f},Array.Empty<int>()));Throws(()=>Mono(new[]{0.2f},Enumerable.Range(0,513).ToArray())); });
        Test("PCM callback can advance entire rhythm with no game-frame ticks", () => {var t=Mono(new[]{0.2f},0,250,640);var result=new List<float>();while(t.Position<t.TotalFrames){var a=new float[512];t.Read(a);result.AddRange(a);}Eq(result.Count(v=>v!=0),3);Near(result[0],0.2f);Near(result[12000],0.2f);Near(result[30720],0.2f); });
    }
}
