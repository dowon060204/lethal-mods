using CruiserLineup.Core;
using System.Text;

internal static class Program
{
    private static int passed,failed;
    private static void Test(string name,Action action)
    {try{action();passed++;Console.WriteLine("PASS "+name);}catch(Exception e){failed++;Console.WriteLine("FAIL "+name+"\n"+e);}}
    private static void Eq<T>(T actual,T expected) {if(!EqualityComparer<T>.Default.Equals(actual,expected))throw new Exception($"Expected {expected}, actual {actual}");}
    private static void Throws(Action action) {try{action();}catch{return;}throw new Exception("Expected rejection");}
    private static Lineup Sample(int i=0)=>new Lineup {Name="한글 라인업 "+i,Instructions="첫 점프 → 왼쪽\n두 번째: 멈춤 🙂",Pose=new PoseData{Position=new Vec3(123.125f,-4.5f,i+.25f),RotationEuler=new Vec3(15,180.25f,1),Scale=new Vec3(1,1,1)},JumpTimesMs=new List<int>{0,137,420,1001}};
    private static LineupBook Populated()
    {
        var b=LineupBook.Empty("value");int i=0;foreach(var m in b.Maps)foreach(var s in m.Slots)s.Data=Sample(i++);return b;
    }
    private static void WithTemp(Action<string> action)
    {var dir=Path.Combine(Path.GetTempPath(),"CruiserLineup-tests-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);try{action(dir);}finally{Directory.Delete(dir,true);}}
    private static int Main(string[] args)
    {
        Test("13 moons x 8 slots",()=>{var b=LineupBook.Empty("empty");Guard.Book(b,true);Eq(b.Maps.Sum(m=>m.Slots.Count),104);});
        Test("Full actual C# book + Korean + arrays + pose round-trip",()=>{var b=Populated();Guard.Book(b);var c=JsonStore.Clone(b);Guard.Book(c);Eq(JsonStore.Hash(c),JsonStore.Hash(b));for(int i=0;i<13;i++)for(int j=0;j<8;j++){Eq(c.Maps[i].Slots[j].Data.Name,b.Maps[i].Slots[j].Data.Name);Eq(c.Maps[i].Slots[j].Data.Instructions,b.Maps[i].Slots[j].Data.Instructions);Eq(c.Maps[i].Slots[j].Data.Pose.Position.Z,b.Maps[i].Slots[j].Data.Pose.Position.Z);}});
        Test("null lineup round-trip",()=>Eq(JsonStore.Clone<Lineup>(null),null));
        Test("Workspace with all 104 drafts round-trip",()=>{var w=new Workspace();foreach(var m in Moons.All)for(int i=0;i<8;i++)w.Drafts.Add(new Draft{Moon=m.Key,Slot=i,Step=i%4,Baseline=JsonStore.Hash<Lineup>(null),Data=Sample(i),TimingComplete=true});w.View("company").ActiveDraftSlot=7;Guard.Drafts(w);var c=JsonStore.Clone(w);Guard.Drafts(c);Eq(c.Drafts.Count,104);Eq(c.View("company").ActiveDraftSlot,7);Eq(JsonStore.Hash(c),JsonStore.Hash(w));});
        Test("Partial draft with no pose/timing survives",()=>{var w=new Workspace();w.Drafts.Add(new Draft{Moon="vow",Slot=2,Step=0,Baseline=JsonStore.Hash<Lineup>(null)});Guard.Drafts(JsonStore.Clone(w));});
        Test("Missing moon rejected",()=>{var b=Populated();b.Maps.RemoveAt(0);Throws(()=>Guard.Book(b));});
        Test("Duplicate moon rejected",()=>{var b=Populated();b.Maps[1].Moon=b.Maps[0].Moon;Throws(()=>Guard.Book(b));});
        Test("Missing slot rejected",()=>{var b=Populated();b.Maps[0].Slots.RemoveAt(0);Throws(()=>Guard.Book(b));});
        Test("Unknown schema rejected",()=>{var b=Populated();b.SchemaVersion=2;Throws(()=>Guard.Book(b));});
        Test("Missing required JSON field rejected",()=>{var json=Encoding.UTF8.GetString(JsonStore.Encode(Sample())).Replace("\"jumpTimesMs\"","\"absentField\"");Throws(()=>JsonStore.Decode<Lineup>(Encoding.UTF8.GetBytes(json)));});
        Test("Oversized file rejected",()=>Throws(()=>JsonStore.Decode<Lineup>(new byte[JsonStore.MaxBytes+1])));
        Test("NaN vector rejected",()=>{var d=Sample();d.Pose.Position.X=float.NaN;Throws(()=>Guard.Data(d));});
        Test("Infinity vector rejected",()=>{var d=Sample();d.Pose.Position.X=float.PositiveInfinity;Throws(()=>Guard.Data(d));});
        Test("Non-positive scale rejected",()=>{var d=Sample();d.Pose.Scale.Z=0;Throws(()=>Guard.Data(d));});
        Test("Empty final name rejected",()=>{var d=Sample();d.Name=" ";Throws(()=>Guard.Data(d));});
        Test("First timestamp must be zero",()=>Throws(()=>Guard.Times(new List<int>{1,2},false)));
        Test("Descending timestamps rejected",()=>Throws(()=>Guard.Times(new List<int>{0,20,10},false)));
        Test("Empty final recording rejected",()=>Throws(()=>Guard.Times(new List<int>(),false)));
        Test("Recording over 10 minutes rejected",()=>Throws(()=>Guard.Times(new List<int>{0,600001},false)));
        Test("More than 512 events rejected",()=>Throws(()=>Guard.Times(Enumerable.Range(0,513).ToList(),false)));
        Test("First event zero and last-event duration",()=>{var r=new TimingRecorder();r.Start();r.Press(30);r.Press(30.125);r.Press(30.875);var a=r.Stop();Eq(string.Join(",",a),"0,125,875");});
        Test("Duplicate and reordered callbacks ignored",()=>{var r=new TimingRecorder();r.Start();r.Press(20);r.Press(20);r.Press(19);r.Press(20.5);Eq(r.Count,2);});
        Test("Release / idle adds no trailing event",()=>{var r=new TimingRecorder();r.Start();r.Press(10);r.Press(11);Eq(r.Stop().Last(),1000);Eq(r.Press(100),false);});
        Test("Recorder reset does not retain old events",()=>{var r=new TimingRecorder();r.Start();r.Press(10);r.Press(11);r.Start();r.Press(40);Eq(string.Join(",",r.Stop()),"0");});
        Test("Invalid event times ignored",()=>{var r=new TimingRecorder();r.Start();Eq(r.Press(double.NaN),false);Eq(r.Press(double.PositiveInfinity),false);Eq(r.Count,0);});
        Test("DSP schedule retains millisecond offsets",()=>{var t=TimingPlan.Schedule(new List<int>{0,125,1000},100.125);Eq(t[0],100.125);Eq(t[1],100.25);Eq(t[2],101.125);});
        Test("DSP overlap detection",()=>{Eq(TimingPlan.PeakOverlap(new List<int>{0,50,100,700},.3),3);});
        Test("Chat Korean, markup escaping and UTF16 boundaries",()=>{var lines=ChatLines.Split("한글",new string('가',179)+"🙂<b>점프</b>\0",180);foreach(var line in lines){if(line.Length>180)throw new Exception("Oversized chunk");if(line.Length>0&&char.IsHighSurrogate(line.Last()))throw new Exception("Split surrogate");if(line.Contains('<')||line.Contains('\0'))throw new Exception("Unsafe chat characters");}if(!string.Concat(lines).Contains("🙂"))throw new Exception("Lost Unicode");});
        Test("Invalid chunk size rejected",()=>Throws(()=>ChatLines.Split("a","b",1)));
        Test("Moon scene priority and localized names",()=>{Eq(Moons.Resolve("Level1Experimentation","85 렌드").Key,"experimentation");Eq(Moons.Resolve("CompanyBuilding","71 Gordion").Key,"company");Eq(Moons.Resolve("", "68 아티피스").Key,"artifice");Eq(Moons.Resolve("", "Liquidation").Key,"liquidation");Eq(Moons.Resolve("Level999Unknown", "unknown"),null);});
        Test("Atomic write replaces and preserves backup",()=>WithTemp(dir=>{var p=Path.Combine(dir,"book.json");JsonStore.WriteAtomic(p,Populated(),b=>Guard.Book(b));var b2=Populated();b2.Entry("vow",0).Data.Name="수정";JsonStore.WriteAtomic(p,b2,b=>Guard.Book(b));Eq(JsonStore.Read<LineupBook>(p,b=>Guard.Book(b)).Entry("vow",0).Data.Name,"수정");Eq(File.Exists(p+".bak"),true);Eq(Directory.GetFiles(dir,"*.tmp-*").Length,0);}));
        Test("Inheritance, override and explicit tombstone",()=>WithTemp(dir=>{var p=Path.Combine(dir,"user.json");var d=Populated();var r=new LineupRepository(p,d);Eq(r.Get("company",7).Name,d.Entry("company",7).Data.Name);r.Commit("company",7,Sample(777),r.Signature("company",7));Eq(r.Get("company",7).Name,"한글 라인업 777");r.Commit("company",7,null,r.Signature("company",7));Eq(r.Get("company",7),null);Eq(new LineupRepository(p,d).Get("company",7),null);}));
        Test("External edit to a different slot is retained",()=>WithTemp(dir=>{var p=Path.Combine(dir,"user.json");var r=new LineupRepository(p,Populated());var baseline=r.Signature("vow",0);var ext=LineupBook.Empty("inherit");ext.Entry("company",7).State="value";ext.Entry("company",7).Data=Sample(99);JsonStore.WriteAtomic(p,ext,b=>Guard.Book(b));r.Commit("vow",0,Sample(1),baseline);Eq(r.Get("company",7).Name,"한글 라인업 99");}));
        Test("Stale same-slot overwrite is rejected",()=>WithTemp(dir=>{var p=Path.Combine(dir,"user.json");var d=Populated();var r1=new LineupRepository(p,d);var r2=new LineupRepository(p,d);var old=r1.Signature("vow",1);r2.Commit("vow",1,Sample(222),r2.Signature("vow",1));Throws(()=>r1.Commit("vow",1,Sample(333),old));Eq(new LineupRepository(p,d).Get("vow",1).Name,"한글 라인업 222");}));
        Test("Corrupt file is not reset or overwritten",()=>WithTemp(dir=>{var p=Path.Combine(dir,"user.json");File.WriteAllText(p,"BROKEN JSON");var r=new LineupRepository(p,Populated());Eq(r.ReadOnly,true);Throws(()=>r.Commit("vow",0,Sample(),r.Signature("vow",0)));Eq(File.ReadAllText(p),"BROKEN JSON");}));
        Test("Overlay default is 25 percent visible",()=>Eq(OverlayStyle.DefaultOpacity,0.25f));
        Test("Requested 20 to 30 percent opacity preserved",()=>{Eq(OverlayStyle.NormalizeOpacity(0.20f),0.20f);Eq(OverlayStyle.NormalizeOpacity(0.25f),0.25f);Eq(OverlayStyle.NormalizeOpacity(0.30f),0.30f);});
        Test("Existing valid personal opacity preserved",()=>{Eq(OverlayStyle.NormalizeOpacity(0.6f),0.6f);Eq(OverlayStyle.NormalizeOpacity(1f),1f);});
        Test("Opacity below range is bounded",()=>{Eq(OverlayStyle.NormalizeOpacity(-1f),0.05f);Eq(OverlayStyle.NormalizeOpacity(0f),0.05f);});
        Test("Opacity above range is bounded",()=>Eq(OverlayStyle.NormalizeOpacity(2f),1f));
        Test("Nonfinite opacity is not silently made opaque",()=>{Eq(OverlayStyle.NormalizeOpacity(float.NaN),0.25f);Eq(OverlayStyle.NormalizeOpacity(float.PositiveInfinity),0.25f);Eq(OverlayStyle.NormalizeOpacity(float.NegativeInfinity),0.25f);});
        Test("Legacy book without slotOrder retains identity order",()=>{var b=Populated();var json=Encoding.UTF8.GetString(JsonStore.Encode(b));Eq(json.Contains("slotOrder"),false);var restored=JsonStore.Decode<LineupBook>(Encoding.UTF8.GetBytes(json));Guard.Book(restored);foreach(var m in restored.Maps)Eq(string.Join(",",SlotOrdering.Effective(m.SlotOrder)),"0,1,2,3,4,5,6,7");});
        Test("Order rejects duplicate missing out-of-range IDs",()=>{Throws(()=>SlotOrdering.Validate(new[]{0,1,2,3,4,5,6,6}));Throws(()=>SlotOrdering.Validate(new[]{0,1,2}));Throws(()=>SlotOrdering.Validate(new[]{0,1,2,3,4,5,6,8}));Throws(()=>SlotOrdering.Validate(new[]{-1,1,2,3,4,5,6,7}));Throws(()=>SlotOrdering.Validate(null));});
        Test("Move forward inserts and shifts rather than swaps",()=>Eq(string.Join(",",SlotOrdering.Move(SlotOrdering.Identity(),0,3)),"1,2,3,0,4,5,6,7"));
        Test("Move backward across rows preserves other order",()=>Eq(string.Join(",",SlotOrdering.Move(SlotOrdering.Identity(),7,0)),"7,0,1,2,3,4,5,6"));
        Test("No-op and every from-to pair preserve IDs and input",()=>{var original=SlotOrdering.Identity();for(int from=0;from<8;from++)for(int to=0;to<8;to++){var moved=SlotOrdering.Move(original,from,to);SlotOrdering.Validate(moved);Eq(moved[to],from);Eq(string.Join(",",original),"0,1,2,3,4,5,6,7");if(from==to)Eq(string.Join(",",moved),string.Join(",",original));}});
        Test("Out-of-range reorder positions rejected",()=>{Throws(()=>SlotOrdering.Move(SlotOrdering.Identity(),-1,3));Throws(()=>SlotOrdering.Move(SlotOrdering.Identity(),0,8));});
        Test("All 13 moon orders and all 104 lineups round-trip",()=>{var book=Populated();for(int i=0;i<13;i++)book.Maps[i].SlotOrder=SlotOrdering.Move(SlotOrdering.Identity(),0,i%8);Guard.Book(book);var copy=JsonStore.Clone(book);Guard.Book(copy);Eq(JsonStore.Hash(copy),JsonStore.Hash(book));Eq(copy.Maps.Sum(m=>m.Slots.Count),104);});
        Test("Saved order survives repository restart",()=>WithTemp(dir=>{var path=Path.Combine(dir,"book.json");var r=new LineupRepository(path,Populated());r.Reorder("company",SlotOrdering.Move(r.GetOrder("company"),0,7),r.OrderSignature("company"));Eq(string.Join(",",new LineupRepository(path,Populated()).GetOrder("company")),"1,2,3,4,5,6,7,0");}));
        Test("Order-only move preserves inherited empty and value entries",()=>WithTemp(dir=>{var path=Path.Combine(dir,"book.json");var r=new LineupRepository(path,Populated());r.Commit("company",1,null,r.Signature("company",1));r.Commit("company",2,Sample(800),r.Signature("company",2));var before=JsonStore.Read<LineupBook>(path,b=>Guard.Book(b));r.Reorder("company",SlotOrdering.Move(r.GetOrder("company"),0,7),r.OrderSignature("company"));var after=JsonStore.Read<LineupBook>(path,b=>Guard.Book(b));foreach(var moon in Moons.All)for(int i=0;i<8;i++)Eq(JsonStore.Hash(before.Entry(moon.Key,i)),JsonStore.Hash(after.Entry(moon.Key,i)));Eq(r.Get("company",1),null);Eq(r.Get("company",2).Name,"한글 라인업 800");}));
        Test("Reordering does not reassign draft IDs or conflict baselines",()=>WithTemp(dir=>{var path=Path.Combine(dir,"book.json");var r=new LineupRepository(path,Populated());var w=new Workspace();w.Drafts.Add(new Draft{Moon="vow",Slot=3,Step=2,Baseline=r.Signature("vow",3),Data=Sample(3),TimingComplete=true});w.View("vow").ActiveDraftSlot=3;var before=JsonStore.Hash(w);r.Reorder("vow",SlotOrdering.Move(r.GetOrder("vow"),3,0),r.OrderSignature("vow"));Eq(JsonStore.Hash(w),before);var draft=w.Find("vow",3);draft.Data.Name="이동 뒤 수정";r.Commit("vow",draft.Slot,draft.Data,draft.Baseline);Eq(r.Get("vow",3).Name,"이동 뒤 수정");Eq(r.GetOrder("vow")[0],3);}));
        Test("Conflicting external same-moon order is not overwritten",()=>WithTemp(dir=>{var path=Path.Combine(dir,"book.json");var defaults=Populated();var a=new LineupRepository(path,defaults);var b=new LineupRepository(path,defaults);var old=a.OrderSignature("vow");b.Reorder("vow",SlotOrdering.Move(b.GetOrder("vow"),0,7),b.OrderSignature("vow"));var bytes=File.ReadAllBytes(path);Throws(()=>a.Reorder("vow",SlotOrdering.Move(a.GetOrder("vow"),0,2),old));Eq(Convert.ToHexString(File.ReadAllBytes(path)),Convert.ToHexString(bytes));}));
        Test("External different-moon order is retained",()=>WithTemp(dir=>{var path=Path.Combine(dir,"book.json");var defaults=Populated();var a=new LineupRepository(path,defaults);var b=new LineupRepository(path,defaults);b.Reorder("company",SlotOrdering.Move(b.GetOrder("company"),7,0),b.OrderSignature("company"));a.Reorder("vow",SlotOrdering.Move(a.GetOrder("vow"),0,7),a.OrderSignature("vow"));Eq(a.GetOrder("company")[0],7);Eq(a.GetOrder("vow")[7],0);}));
        Test("External lineup edit survives order-only commit",()=>WithTemp(dir=>{var path=Path.Combine(dir,"book.json");var defaults=Populated();var a=new LineupRepository(path,defaults);var b=new LineupRepository(path,defaults);b.Commit("vow",0,Sample(999),b.Signature("vow",0));a.Reorder("vow",SlotOrdering.Move(a.GetOrder("vow"),0,7),a.OrderSignature("vow"));Eq(a.Get("vow",0).Name,"한글 라인업 999");}));
        Test("Invalid stored order is read-only without resetting file",()=>WithTemp(dir=>{var path=Path.Combine(dir,"book.json");var invalid=LineupBook.Empty("inherit");invalid.Maps[0].SlotOrder=new List<int>{0,0,2,3,4,5,6,7};File.WriteAllBytes(path,JsonStore.Encode(invalid));var before=File.ReadAllBytes(path);var r=new LineupRepository(path,Populated());Eq(r.ReadOnly,true);Throws(()=>r.Reorder("company",SlotOrdering.Identity(),r.OrderSignature("company")));Eq(Convert.ToHexString(before),Convert.ToHexString(File.ReadAllBytes(path)));}));
        Test("Slot edits and deletion retain saved order",()=>WithTemp(dir=>{var path=Path.Combine(dir,"book.json");var r=new LineupRepository(path,Populated());r.Reorder("vow",SlotOrdering.Move(r.GetOrder("vow"),7,0),r.OrderSignature("vow"));var order=string.Join(",",r.GetOrder("vow"));r.Commit("vow",4,Sample(333),r.Signature("vow",4));r.Commit("vow",7,null,r.Signature("vow",7));Eq(string.Join(",",new LineupRepository(path,Populated()).GetOrder("vow")),order);Eq(r.Get("vow",7),null);}));
        Test("Moved inherited slots keep original default identity on update",()=>WithTemp(dir=>{var path=Path.Combine(dir,"book.json");var defaults=Populated();var r=new LineupRepository(path,defaults);r.Reorder("vow",SlotOrdering.Move(r.GetOrder("vow"),0,7),r.OrderSignature("vow"));defaults.Entry("vow",0).Data.Name="갱신된 원래 슬롯";var reloaded=new LineupRepository(path,defaults);Eq(reloaded.Get("vow",reloaded.GetOrder("vow")[7]).Name,"갱신된 원래 슬롯");}));
        if(args.Length!=0) {Console.Error.WriteLine("Usage: CoreTests (no arguments)");return 2;}
        PcmTests.Register(Test);
        AudioRuntimeTests.Register(Test);
        UiCommandTests.Register(Test);
        UiRegressionTests.Register(Test);
        UiPointerTests.Register(Test);
        InputRuntimeTests.Register(Test);
        ConsoleModeTests.Register(Test);
        Console.WriteLine($"C# core + historical PCM utility + UI build/render/pointer policy + native-audio/command/input/system-text API-fake tests: {passed} passed, {failed} failed. Real Unity/Input System, physical devices, audio output, UI/IME rendering, game and multiplayer tests are NOT covered.");
        return failed==0?0:1;
    }
}
