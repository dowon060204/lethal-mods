using System;
using CruiserLineup.Core;

internal static class ConsoleModeTests
{
    private static void Need(bool value) { if(!value) throw new Exception("Console flag policy failed"); }
    public static void Register(Action<string,Action> Test)
    {
        Test("Console policy clears QuickEdit and sets required extended flag",()=>
            Need(ConsoleModePolicy.WithoutQuickEdit(0x40)==0x80));
        Test("Console policy preserves unrelated mode bits",()=>
            Need(ConsoleModePolicy.WithoutQuickEdit(0xFFFF)==0xFFBF));
        Test("Console policy is idempotent",()=>
            Need(ConsoleModePolicy.WithoutQuickEdit(ConsoleModePolicy.WithoutQuickEdit(0xF7))==ConsoleModePolicy.WithoutQuickEdit(0xF7)));
        Test("Console policy does not own global registry state",()=>
            Need(ConsoleModePolicy.Mask==0xC0));
        Test("Console policy permits restoration of untouched own bits",()=>
            Need(ConsoleModePolicy.CanRestore(0x9F,0x9F)));
        Test("Console policy refuses overwriting another quickedit change",()=>
            Need(!ConsoleModePolicy.CanRestore(0xDF,0x9F)));
        Test("Console policy keeps unrelated changes on restore",()=>
            Need(ConsoleModePolicy.RestoreOwnBits(0xA9F,0xDF)==0xADF));
        Test("Console policy exhaustive low-mode preservation",()=>
        {
            for(uint mode=0;mode<4096;mode++)
            {
                var applied=ConsoleModePolicy.WithoutQuickEdit(mode);
                Need((applied&0x40)==0&&(applied&0x80)!=0);
                Need((applied&~ConsoleModePolicy.Mask)==(mode&~ConsoleModePolicy.Mask));
                Need(ConsoleModePolicy.RestoreOwnBits(applied,mode)==mode);
            }
        });
    }
}
