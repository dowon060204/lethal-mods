using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx.Logging;
using CruiserLineup;
using UnityEngine;

// Production TimingAudio against controlled API fakes: verifies scheduling/lifecycle only.
// It does not load Unity, play a speaker or validate a game's audio device.
internal static class AudioRuntimeTests
{
    private sealed class Fixture:IDisposable
    {
        public readonly AudioClip Original;
        public readonly TimingAudio Audio;
        public readonly AudioListener Listener;
        public readonly ManualLogSource Log=new ManualLogSource();
        public readonly List<string> Errors=new List<string>();
        public int Started;
        public Fixture(bool warm=true)
        {
            FakeAudio.Reset();Listener=new GameObject("Listener").AddComponent<AudioListener>();
            Original=new AudioClip{name="Cruiser_JumpInSeat_TEST",samples=36856,channels=2,frequency=48000};
            Audio=new TimingAudio(new GameObject("Runtime").transform,Log);Audio.Failed+=Errors.Add;Audio.Started+=()=>Started++;
            if(warm){Audio.Warmup(()=>Original);Audio.Tick();Audio.Tick();}
        }
        public AudioSource[] Sources=>UnityEngine.Object.FindObjectsOfType<AudioSource>();
        public void Play(List<int> times=null)=>Audio.Play(()=>Original,times??new List<int>{0,250,600,1500,2656},"dine",.8f);
        public void Tick(double wall=.02,double dsp=.02){Time.realtimeSinceStartupAsDouble+=wall;AudioSettings.dspTime+=dsp;Audio.Tick();}
        public void Dispose(){Audio.Dispose();}
    }
    private static void Run(Action<Fixture> action){using(var f=new Fixture())action(f);}
    private static void Eq<T>(T a,T b){if(!EqualityComparer<T>.Default.Equals(a,b))throw new Exception($"Expected {b}, got {a}");}
    private static void Need(bool ok,string why){if(!ok)throw new Exception(why);}
    public static void Register(Action<string,Action> Test)
    {
        Test("Native audio: normal cached click submits original clip immediately",()=>Run(f=>{f.Play();Eq(f.Started,1);Eq(f.Errors.Count,0);Eq(f.Sources.Sum(s=>s.Scheduled.Count),5);Need(f.Sources.Take(5).All(s=>ReferenceEquals(s.clip,f.Original)),"replacement asset used");}));
        Test("Native audio: all relative millisecond offsets are preserved",()=>Run(f=>{f.Play();var at=f.Sources.Take(5).Select(s=>s.Scheduled.Single()).ToArray();var ms=new[]{0,250,600,1500,2656};for(int i=0;i<ms.Length;i++)Need(Math.Abs((at[i]-at[0])*1000-ms[i])<.00001,"interval changed");}));
        Test("Native audio: only original AudioClip exists after playback starts",()=>Run(f=>{f.Play();Eq(UnityEngine.Object.FindObjectsOfType<AudioClip>().Length,1);}));
        Test("Native audio: original does not need readable PCM",()=>Run(f=>{f.Original.Readable=false;f.Original.Data=null;f.Play();Eq(f.Started,1);Eq(f.Errors.Count,0);}));
        Test("Native audio: compressed original is played without GetData",()=>Run(f=>{f.Original.loadType=AudioClipLoadType.CompressedInMemory;f.Play();Eq(f.Started,1);Eq(f.Errors.Count,0);}));
        Test("Native audio: 41 second Update delay does not add or retime events",()=>Run(f=>{f.Play();var before=f.Sources.SelectMany(s=>s.Scheduled).ToArray();f.Tick(41,41);Eq(string.Join(",",f.Sources.SelectMany(s=>s.Scheduled)),string.Join(",",before));Eq(f.Errors.Count,0);}));
        Test("Native audio: source creation precedes choosing DSP origin",()=>{using(var f=new Fixture(false)){FakeAudio.SourceCreationDelay=2.23;f.Play(new List<int>{0,250});Eq(f.Errors.Count,0);Eq(f.Started,1);Need(f.Sources[0].Scheduled[0]>AudioSettings.dspTime,"stale origin");}});
        Test("Native audio: cold voice allocation is bounded per Tick",()=>{using(var f=new Fixture(false)){f.Play(Enumerable.Range(0,32).Select(i=>i*100).ToList());Eq(f.Sources.Length,4);for(int i=0;i<7;i++)f.Tick();Eq(f.Sources.Length,32);Eq(f.Started,1);Eq(f.Errors.Count,0);}});
        Test("Native audio: all 512 supported events get distinct scheduled sources",()=>Run(f=>{f.Play(Enumerable.Range(0,512).Select(i=>i*10).ToList());for(int i=0;i<130&&f.Started==0;i++)f.Tick();Eq(f.Started,1);Eq(f.Sources.Sum(s=>s.Scheduled.Count),512);}));
        Test("Native audio: repeated Listen reuses pool and stops old schedule",()=>Run(f=>{f.Play();var first=f.Sources;f.Play();Eq(f.Started,2);Eq(f.Sources.Length,8);Eq(first.Take(5).All(s=>s.StopCalls==1),true);Eq(first.Take(5).All(s=>s.Scheduled.Count==2),true);}));
        Test("Native audio: Stop retains game clip and warm pool",()=>Run(f=>{f.Play();f.Audio.Stop();Eq(f.Audio.Playing,false);Eq(f.Original.Destroyed,false);Eq(f.Sources.Length,8);}));
        Test("Native audio: Dispose destroys owned roots but never game clip",()=>Run(f=>{f.Play();f.Audio.Dispose();Eq(f.Original.Destroyed,false);Eq(f.Sources.Length,0);}));
        Test("Native audio: absent asset times out instead of permanent preparation",()=>Run(f=>{using(var a=new TimingAudio(new GameObject("other").transform,f.Log)){int failed=0;a.Failed+=_=>failed++;a.Play(()=>null,new List<int>{0},"vow",.8f);Time.realtimeSinceStartupAsDouble+=11;a.Tick();Eq(failed,1);Eq(a.Playing,false);}}));
        Test("Native audio: missing listener can recover without modifying offsets",()=>Run(f=>{f.Listener.enabled=false;f.Play();Eq(f.Started,0);f.Listener.enabled=true;f.Tick(.6,.6);Eq(f.Started,1);}));
        Test("Native audio: muted master volume is reported and not overridden",()=>Run(f=>{AudioListener.volume=0;f.Play();Eq(f.Started,0);Eq(f.Errors.Count,1);Eq(AudioListener.volume,0f);}));
        Test("Native audio: DSP pause is reported rather than scheduling on a frozen clock",()=>Run(f=>{AudioListener.pause=true;f.Play();Eq(f.Started,0);Eq(f.Errors.Count,1);Eq(AudioListener.pause,true);}));
        Test("Native audio: failed clip load is isolated",()=>{using(var f=new Fixture(false)){f.Original.loadState=AudioDataLoadState.Failed;f.Play();Eq(f.Errors.Count,1);Eq(f.Started,0);Eq(f.Original.Destroyed,false);}});
        Test("Native audio: rejected load request is isolated",()=>{using(var f=new Fixture(false)){f.Original.loadState=AudioDataLoadState.Unloaded;f.Original.LoadAccepted=false;f.Play();Eq(f.Errors.Count,1);Eq(f.Started,0);}});
        Test("Native audio: 2D playback respects existing master volume",()=>Run(f=>{f.Play();var s=f.Sources[0];Eq(s.spatialBlend,0f);Eq(s.spatialize,false);Eq(s.volume,.8f);Eq(s.ignoreListenerVolume,false);Eq(AudioListener.volume,.48f);Eq(s.outputAudioMixerGroup,null);}));
        Test("Native audio: quit stops scheduled sound without creating more sources",()=>Run(f=>{f.Play();Plugin.Quitting=true;f.Tick();Eq(f.Audio.Playing,false);Eq(f.Sources.Length,8);}));
        Test("Native audio: no device sample rate fails once",()=>Run(f=>{AudioSettings.Rate=0;f.Play();Eq(f.Errors.Count,1);Eq(f.Started,0);}));
        Test("Native audio: maximum time offset is not shortened",()=>Run(f=>{f.Play(new List<int>{0,600000});Need(Math.Abs(f.Sources[1].Scheduled[0]-f.Sources[0].Scheduled[0]-600)<1e-9,"long timing shortened");}));
        Test("Native audio: removed source pool is rebuilt without stale handles",()=>Run(f=>{f.Sources[0].gameObject=null;f.Play();f.Tick();Eq(f.Started,1);Eq(f.Errors.Count,0);Eq(f.Sources.Sum(v=>v.Scheduled.Count),5); }));
        Test("Native audio: prewarm failure is not retried every Update",()=>{using(var f=new Fixture(false)){int calls=0;f.Audio.Warmup(()=>{calls++;throw new Exception("test resolver failure");});f.Tick();for(int i=0;i<50;i++){f.Audio.Warmup(()=>{calls++;return f.Original;});f.Tick(2,2);}Eq(calls,1);f.Play();f.Tick();Eq(f.Started,1);}});
        Test("Native audio: missing-asset warmup probing has a fixed bound",()=>{using(var f=new Fixture(false)){int calls=0;f.Audio.Warmup(()=>{calls++;return null;});for(int i=0;i<100;i++)f.Tick(2,2);Eq(calls,15);f.Play();f.Tick();Eq(f.Started,1);}});
        Test("Native audio: owned roots protected before adding sources",()=>Run(f=>{Need(f.Sources.All(v=>v.gameObject.hideFlags==HideFlags.HideAndDontSave),"unprotected source root");}));
        Test("Native audio: zero duplicate offsets remain simultaneous",()=>Run(f=>{f.Play(new List<int>{0,0,250});Eq(f.Sources[0].Scheduled[0],f.Sources[1].Scheduled[0]);}));
    }
}
