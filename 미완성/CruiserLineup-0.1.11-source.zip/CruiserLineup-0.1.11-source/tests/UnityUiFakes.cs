// Test-only external API fakes. This is not actual text rasterization / Windows font loading.
using System;
using System.Linq;
namespace UnityEngine
{
    public enum FontStyle {Normal}
    public sealed class Font : Object
    {
        public static int Creates,Requests;
        public static bool FailCreate,FailRequest,Hangul=true;
        public static string[] LastFamilies;
        public static string LastCharacters;
        public static Font CreateDynamicFontFromOSFont(string[] names,int size)
        { Creates++; LastFamilies=(string[])names.Clone(); if(FailCreate)throw new InvalidOperationException("test native font failure");return new Font(); }
        public void RequestCharactersInTexture(string chars,int size,FontStyle style)
        {Requests++;LastCharacters=chars;if(FailRequest)throw new InvalidOperationException("test probe failure");}
        public bool HasCharacter(char c) => c<128||Hangul;
        public static void Reset(){Creates=Requests=0;FailCreate=FailRequest=false;Hangul=true;LastFamilies=null;LastCharacters=null;}
    }
}
namespace UnityEngine.UI
{
    public sealed class VertexHelper {public int Clears;public void Clear(){Clears++;}}
    public class Text : UnityEngine.Component
    {
        public static bool FailNative;
        public static int NativeCalls;
        public static Action Reenter;
        protected virtual void OnPopulateMesh(VertexHelper helper)
        {NativeCalls++;Reenter?.Invoke();if(FailNative)throw new InvalidOperationException("test text engine error");}
        public void TestPopulate(VertexHelper helper)=>OnPopulateMesh(helper);
    }
}
