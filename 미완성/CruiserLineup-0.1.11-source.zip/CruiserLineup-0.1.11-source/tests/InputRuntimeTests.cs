using System;
using System.Linq;
using BepInEx.Logging;
using CruiserLineup;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;

internal static class InputRuntimeTests
{
    private sealed class Fixture
    {
        public readonly ManualLogSource Log=new ManualLogSource();
        public readonly GameBridge Bridge=new GameBridge();
        public readonly TestPlayer Player=new TestPlayer();
        public readonly InputAction GameAction=new InputAction{enabled=true};
        public readonly InputAction OriginallyOff=new InputAction{enabled=false};
        public readonly InputAction OtherMod=new InputAction{enabled=true};
        public readonly Keyboard Keyboard=new Keyboard();
        public readonly KeyControl Key=new KeyControl();
        public readonly InputLease Lease;
        public Fixture()
        {
            FakeAudio.Reset();InputSystem.Reset();Time.frameCount=20;
            Cursor.FailLock=false;Cursor.lockState=CursorLockMode.Locked;Cursor.visible=false;Cursor.Writes=0;
            CruiserLineup.LineupRuntime.Current=null;
            UnityEngine.InputSystem.Keyboard.CurrentDisappearsAfterFirstRead=false;
            UnityEngine.InputSystem.Keyboard.current=Keyboard;Mouse.current=null;Gamepad.current=null;
            Key.device=Keyboard;
            Keyboard.Keys=new KeyControl[]{Key,null}; // Deliberate real 1.14-style IMESelected gap.
            Keyboard.imeSelected=new ButtonControl{device=Keyboard,Down=false};
            Bridge.LocalPlayer=Player;
            Bridge.Targets.Standalone.Add(GameAction);Bridge.Targets.Standalone.Add(OriginallyOff);
            InputSystem.Actions.Add(GameAction);InputSystem.Actions.Add(OriginallyOff);InputSystem.Actions.Add(OtherMod);
            Lease=new InputLease(Log);Lease.Acquire(Bridge);
        }
        public void Advance(int frames=2){Time.frameCount+=frames;Time.realtimeSinceStartupAsDouble+=0.03;Lease.Tick();}
        public LineupRuntime Ui(){var ui=new LineupRuntime();ui.TestMount(Lease,Log);return ui;}
        public void Released()
        {
            Need(!Lease.Held,"lease still held");Need(GameAction.enabled,"game action not restored");
            Need(!OriginallyOff.enabled,"previously disabled action enabled");Need(OtherMod.enabled,"other mod action changed");
            Need(!Player.disableMoveInput&&!Player.disableLookInput,"player flags not restored");
            Need(InputSystem.SubscriberCount==0,"input event subscriber leaked");
        }
    }
    private static void Need(bool value,string message){if(!value)throw new Exception(message);}
    public static void Register(Action<string,Action> Test)
    {
        Test("Input 1.14 null IME slot does not throw on BeginRelease",()=>
        {var f=new Fixture();f.Lease.BeginRelease();f.Advance();f.Released();Need(f.Log.Entries.Any(s=>s.Contains("skippedNullControls=1")),"null gap not counted");});
        Test("Input baseline unguarded enumeration rejects same null fixture",()=>
        {
            var f=new Fixture();bool reproduced=false;
            try{foreach(var key in f.Keyboard.allKeys){_ = key.isPressed;}}
            catch(NullReferenceException){reproduced=true;}
            finally{f.Lease.Release();}
            Need(reproduced,"legacy null assumption not reproduced by fixture");
        });
        Test("Input null slot followed by held key still preserves held-key protection",()=>
        {var f=new Fixture();f.Key.Down=true;f.Keyboard.Keys=new KeyControl[]{null,f.Key,null};f.Lease.BeginRelease();f.Advance();Need(f.Lease.Held&&f.Player.disableMoveInput,"held typing key lost its modal guard");f.Key.Down=false;f.Advance();f.Released();});
        Test("Input absent current keyboard mouse and gamepad is safe",()=>
        {var f=new Fixture();Keyboard.current=null;f.Lease.BeginRelease();f.Advance();f.Released();});
        Test("Input no keyboard at acquisition is safe",()=>
        {var f=new Fixture();f.Lease.Release();Keyboard.current=null;f.Lease.Acquire(f.Bridge);f.Lease.BeginRelease();f.Advance();f.Released();});
        Test("Input snapshots changing current keyboard only once",()=>
        {var f=new Fixture();Keyboard.CurrentReads=0;Keyboard.CurrentDisappearsAfterFirstRead=true;f.Lease.BeginRelease();Need(Keyboard.CurrentReads==1,"current keyboard reread");f.Advance();f.Released();});
        Test("Input optional null mouse buttons do not prevent left-button hold",()=>
        {var f=new Fixture();var m=new Mouse();m.leftButton=new ButtonControl{device=m,Down=true};Mouse.current=m;f.Lease.BeginRelease();f.Advance();Need(f.Lease.Held,"held click leaked");m.leftButton.Down=false;f.Advance();f.Released();});
        Test("Input disconnected held keyboard does not retain a permanent lease",()=>
        {var f=new Fixture();f.Key.Down=true;f.Lease.BeginRelease();f.Keyboard.added=false;f.Advance();f.Released();});
        Test("Input removed held control is skipped and logged once",()=>
        {var f=new Fixture();f.Key.Down=true;f.Lease.BeginRelease();f.Key.ThrowRead=true;f.Advance();f.Released();Need(f.Log.Entries.Count(s=>s.Contains("[INPUT/CONTROL-UNAVAILABLE]"))==1,"control warning count");});
        Test("Input invalid control among valid controls is isolated",()=>
        {var f=new Fixture();var broken=new KeyControl{device=f.Keyboard,ThrowRead=true};f.Key.Down=true;f.Keyboard.Keys=new[]{broken,null,f.Key};f.Lease.BeginRelease();f.Advance();Need(f.Lease.Held,"valid key abandoned after another key failed");f.Key.Down=false;f.Advance();f.Released();});
        Test("Input failed enumeration restores actions and unsubscribes",()=>
        {var f=new Fixture();f.Keyboard.ThrowKeyEnumeration=true;f.Lease.BeginRelease();f.Released();Need(f.Log.Entries.Any(s=>s.Contains("[INPUT/CLOSE-FAILOPEN]")),"missing error stage");});
        Test("Input modal does not call an unavailable native IME toggle",()=>
        {var f=new Fixture();Need(!f.Keyboard.ImeEnabled,"modal enabled native IME without text focus");f.Keyboard.ThrowIme=true;f.Lease.BeginRelease();f.Advance();f.Released();Need(!f.Keyboard.ImeEnabled,"modal changed native IME on release");});
        Test("Input release does not call unavailable native cursor setters",()=>
        {var f=new Fixture();Cursor.FailLock=true;f.Lease.BeginRelease();f.Advance();f.Released();Need(!Cursor.visible&&Cursor.Writes==0,"unexpected native cursor call");Cursor.FailLock=false;});
        Test("Input release does not enable unrelated or already-disabled actions",()=>
        {var f=new Fixture();Need(f.OtherMod.Disables==0,"other mod was disabled");f.Lease.Release();f.Released();Need(f.OriginallyOff.Enables==0&&f.OtherMod.Enables==0,"unowned action restored");});
        Test("Input broken third-party Enable/Disable callbacks are never invoked",()=>
        {var f=new Fixture();f.GameAction.FailEnable=true;f.GameAction.FailDisable=true;f.Lease.Enforce();f.Lease.Release();f.Released();Need(f.GameAction.Enables==0&&f.GameAction.Disables==0,"action lifecycle was touched");});
        Test("Input reacquire cancels pending release without duplicate hook",()=>
        {var f=new Fixture();f.Key.Down=true;f.Lease.BeginRelease();f.Lease.Acquire(f.Bridge);f.Key.Down=false;f.Advance();Need(f.Lease.Held&&!Cursor.visible,"reopened UI lost protection or changed native cursor");Need(InputSystem.SubscriberCount==1,"duplicate hook");f.Lease.BeginRelease();f.Advance();f.Released();});
        Test("Input multiple release calls never mutate actions",()=>
        {var f=new Fixture();f.Lease.BeginRelease();f.Lease.BeginRelease();f.Advance();f.Lease.Release();f.Released();Need(f.GameAction.Enables==0,"action restore must not run");});
        Test("Input action-enable callbacks cannot be triggered by modal release",()=>
        {var f=new Fixture();f.GameAction.OnEnable=()=>f.Lease.Release();f.Lease.Release();f.Released();Need(f.GameAction.Enables==0,"action-enable callback was invoked");});
        Test("Input same-frame close click remains blocked until a later input frame",()=>
        {var f=new Fixture();f.Lease.BeginRelease();f.Lease.Tick();Need(f.Lease.Held,"same-frame release");f.Advance(1);Need(f.Lease.Held,"next-frame boundary released early");f.Advance(1);f.Released();});
        Test("Input gamepad real button waits and synthetic non-button controls are ignored",()=>
        {var f=new Fixture();var pad=new Gamepad();var button=new ButtonControl{device=pad,Down=true};pad.allControls=new InputControl[]{null,new InputControl{device=pad},button};Gamepad.current=pad;f.Lease.BeginRelease();f.Advance();Need(f.Lease.Held,"gamepad hold lost");button.Down=false;f.Advance();f.Released();});
        Test("Input player replacement during lease releases old flags and closes modal",()=>
        {var f=new Fixture();var ui=f.Ui();f.Bridge.LocalPlayer=new TestPlayer();InputSystem.BeforeUpdate();f.Released();Need(!ui.TestVisible&&ui.Faults==1,"failed input lease left modal active");});
        Test("UI actual common CloseUi method handles the 1.14 null gap",()=>
        {var f=new Fixture();var ui=f.Ui();ui.TestClose();Need(!ui.TestVisible&&ui.Saves==1&&ui.TestUiSelectionCleared,"close boundary state not saved");f.Advance();f.Released();});
        Test("UI shared close boundary saves draft after input enumeration failure",()=>
        {var f=new Fixture();var ui=f.Ui();f.Keyboard.ThrowKeyEnumeration=true;ui.TestClose();Need(ui.Saves==1&&!ui.TestVisible,"draft save skipped");f.Released();});
        Test("UI save failure does not leak input lease",()=>
        {var f=new Fixture();var ui=f.Ui();ui.FailSave=true;ui.TestClose();f.Advance();f.Released();Need(f.Log.Entries.Any(s=>s.Contains("[UI/CLOSE-SAVE]")),"save failure unreported");});
        Test("UI already invisible with pending lease still cleans up",()=>
        {var f=new Fixture();var ui=f.Ui();ui.TestMakeInvisible();ui.TestClose(true);f.Released();Need(ui.Saves==0,"invisible retry saved twice");});
        Test("UI immediate lifecycle close does not depend on another Update",()=>
        {var f=new Fixture();var ui=f.Ui();f.Key.Down=true;ui.TestClose(true);f.Released();Need(ui.Saves==1,"draft not saved on immediate close");});
        Test("UI ordinary close does not stop running timing audio",()=>
        {
            var f=new Fixture();var ui=f.Ui();var owner=new GameObject("test owner");new GameObject("listener").AddComponent<AudioListener>();
            var actual=new AudioClip{name="test waveform",samples=4,channels=1,frequency=8000,Data=new float[]{.1f,.2f,.1f,0}};
            using(var audio=new TimingAudio(owner.transform,f.Log))
            {
                audio.Play(()=>actual,new System.Collections.Generic.List<int>{0,100},"artifice",.8f);
                Need(audio.Playing,"mock audio did not start");ui.TestClose();f.Advance();f.Released();Need(audio.Playing,"closing input lease canceled sound");
            }
        });
        Test("UI repeated F10-style open close cycles retain no input subscription",()=>
        {var f=new Fixture();for(int n=0;n<32;n++){if(!f.Lease.Held)f.Lease.Acquire(f.Bridge);var ui=f.Ui();ui.TestClose();f.Advance();f.Released();}Need(f.GameAction.Enables==0&&f.GameAction.Disables==0,"action lifecycle changed during cycles");});
        Test("Input all 131 actions retain enabled state across a complete UI cycle",()=>
        {
            var f=new Fixture();var actions=Enumerable.Range(0,131).Select(i=>new InputAction{enabled=(i%3)!=0}).ToArray();
            var enabled=actions.Select(a=>a.enabled).ToArray();InputSystem.Actions.AddRange(actions);
            foreach(var a in actions)f.Bridge.Targets.Standalone.Add(a);
            f.Lease.Enforce();f.Lease.BeginRelease();f.Advance();f.Released();
            for(int i=0;i<actions.Length;i++)Need(actions[i].enabled==enabled[i]&&actions[i].Enables==0&&actions[i].Disables==0,"shared map was changed");
        });
        Test("Input protects movement without depending on discoverable action assets",()=>
        {var f=new Fixture();f.Lease.Release();f.Bridge.Targets.Standalone.Clear();f.Bridge.Targets.Assets.Clear();f.Lease.Acquire(f.Bridge);Need(f.Player.disableMoveInput&&f.Player.disableLookInput,"flag guards missing");f.Lease.Release();f.Released();});
        Test("Input virtual-pointer modal performs zero native cursor writes in 1000 cycles",()=>
        {
            var f=new Fixture();
            for(int i=0;i<1000;i++)
            {
                if(!f.Lease.Held)f.Lease.Acquire(f.Bridge);
                InputSystem.BeforeUpdate();f.Lease.Enforce();f.Lease.BeginRelease();f.Advance();f.Released();
            }
            Need(Cursor.Writes==0,"modal wrote native cursor state");
            Need(InputSystem.SubscriberCount==0,"modal input subscription leaked");
        });
        Test("Input preserves external unlocked cursor without restoring a stale lock",()=>
        {
            var f=new Fixture();Cursor.lockState=CursorLockMode.None;Cursor.visible=true;
            var before=Cursor.Writes;f.Lease.Enforce();f.Lease.Release();f.Released();
            Need(Cursor.Writes==before&&Cursor.visible&&Cursor.lockState==CursorLockMode.None,"overwrote external cursor change");
        });
        Test("Input retains pre-existing movement/look restrictions on close",()=>
        {var f=new Fixture();f.Lease.Release();f.Player.disableMoveInput=true;f.Player.disableLookInput=true;f.Lease.Acquire(f.Bridge);f.Lease.Release();Need(f.Player.disableMoveInput&&f.Player.disableLookInput,"overrode another restriction");Need(InputSystem.SubscriberCount==0,"subscriber leaked");});
    }
}
