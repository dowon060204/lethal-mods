#!/usr/bin/env python3
"""Source/packaging checks only. Does not run C# or Unity."""
from pathlib import Path
import hashlib, json, re, sys
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
results=[]
def check(name, value):
    results.append({'name':name, 'result':'PASS' if value else 'FAIL', 'kind':'SOURCE_STATIC_ONLY'})
def read(path): return (root/path).read_text(encoding='utf-8-sig')
manifest=json.loads(read('manifest.json'))
check('README description equals manifest exactly',read('README.md').splitlines()[0]==manifest['description'])
check('Manifest version 0.1.11',manifest['version_number']=='0.1.11')
check('Plugin version 0.1.11','Version="0.1.11"' in read('src/Runtime/Plugin.cs'))
check('Assembly version 0.1.11.0','<AssemblyVersion>0.1.11.0</AssemblyVersion>' in read('CruiserLineup.csproj'))
check('Build version 0.1.11',"$version = '0.1.11'" in read('Build.ps1'))
for p in root.rglob('*.csproj'):
    ET.parse(p); check('Project XML parses: '+str(p.relative_to(root)),True)
for p in root.rglob('*.json'):
    if 'verification' in p.relative_to(root).parts: continue
    json.loads(p.read_text(encoding='utf-8-sig'));check('JSON parses: '+str(p.relative_to(root)),True)
ui=read('src/Runtime/LineupUi.cs'); rt=read('src/Runtime/LineupRuntime.cs')
text=read('src/Runtime/SystemUiText.cs'); prep=read('src/Runtime/UiPreparation.cs')
check('UI has no TMP classes or namespace', all(v not in ui for v in ['using TMPro','TMP_InputField','TextMeshProUGUI']))
check('UI creates native bounded Text and native InputField', 'AddComponent<LineupUiText>()' in ui and 'AddComponent<InputField>()' in ui)
check('UI labels use cached native text', 't.font=systemText.Get()' in ui)
check('Text uses OS font APIs, no raw font asset files', 'CreateDynamicFontFromOSFont' in text and 'File.' not in text and 'CreateFontAsset' not in text)
check('Only one native font creation call site', text.count('Font.CreateDynamicFontFromOSFont(')==1)
check('Native font cache suppresses repeated failed attempts', 'if(attempted) throw' in text and 'if(cached!=null) return cached;' in text)
check('Known-readable default Hangul family is present','"Malgun Gothic"' in text)
check('No designer font family requested', '"Orbit"' not in text and '"3270"' not in text and '"IBM 3270"' not in text)
check('No TMP dependency required by plugin project', 'Unity.TextMeshPro.dll' not in read('CruiserLineup.csproj'))
check('Unused TMP audit removed and actual native APIs audited','Method(tmp,' not in read('tools/ApiAudit/Program.cs') and '"UnityEngine.UI.Text","set_font"' in read('tools/ApiAudit/Program.cs'))
check('Hidden UI constructed using yielded stages', 'private IEnumerator BuildRetainedUi()' in ui and ui.count('yield return null;')>=9)
check('Open defers input lease until UI ready',rt.index('if(!uiReady)',rt.index('private void OpenUi()'))<rt.index('inputLease.Acquire(Bridge)',rt.index('private void OpenUi()')))
check('Close cancels pending opens before any early return',read('src/Runtime/ModalClose.cs').index('CancelPendingUiOpen();')<read('src/Runtime/ModalClose.cs').index('if(!wasVisible'))
check('One build tick per frame guarded','frame==lastFrame' in read('src/Core/UiFrameBuild.cs'))
check('Build has finite yielded step limit','steps>maximumSteps' in read('src/Core/UiFrameBuild.cs'))
check('Mesh reentrancy guarded','if(populating)' in read('src/Runtime/LineupUiText.cs'))
check('Mesh fault suppresses native redraw until reset','if(Fault!=null) return false;' in read('src/Core/UiRenderBudget.cs'))
check('Render fault hides whole own UI on next Update','uiRoot.SetActive(false)' in prep and 'CloseUi(true)' in prep)
check('Fallback event root not parented to hidden runtime','ownedEventRoot.transform.SetParent' not in ui and 'DontDestroyOnLoad(ownedEventRoot)' in ui)
check('Automatic best-fit font resizing disabled','resizeTextForBestFit=false' in ui)
check('No OnGUI rendering','void OnGUI(' not in ui)
check('Legacy F10 is only used when new keyboard absent',rt.count('UnityEngine.Input.GetKeyDown(')==1 and 'if(keyboard==null&&settings.ToggleKey.Value==Key.F10' in rt)
check('Slot format remains 13 maps, 8 slots each',len(json.loads(read('assets/CruiserLineup.defaults.json'))['moons'])==13 and all(len(m['slots'])==8 for m in json.loads(read('assets/CruiserLineup.defaults.json'))['moons']))
for f in root.rglob('*'):
    if not f.is_file():continue
    if f.suffix.lower() in {'.ttf','.otf','.woff','.woff2','.ttc','.dll','.exe'}:check('No binary/font payload: '+str(f.relative_to(root)),False)
check('Plugin never compiles test fake API classes','<EnableDefaultCompileItems>false</EnableDefaultCompileItems>' in read('CruiserLineup.csproj') and '<Compile Include="src/**/*.cs" />' in read('CruiserLineup.csproj'))
ghost=read('src/Runtime/GhostRenderer.cs'); material=read('src/Runtime/GhostMaterial.cs')
pointer=read('src/Runtime/UiPointerModule.cs'); lease=read('src/Runtime/InputLease.cs')
audit=read('tools/ApiAudit/Program.cs'); trace=read('src/Runtime/HangTrace.cs')
check('Overlay only selects HDRP Unlit shader', 'Shader.Find("HDRP/Unlit")' in material and 'Shader.Find("Hidden/Internal-Colored")' not in material and 'Shader.Find("UI/Default")' not in material)
check('Private material uses HDRP validator', 'validate.Invoke(null' in material and 'BindingFlags.Public | BindingFlags.Static' in material)
check('HDRP forward transparency checked before commit', '"_SURFACE_TYPE_TRANSPARENT"' in material and '"_ZWrite") != 0' in material and 'FindPass("ForwardOnly")' in material)
check('No manual draw or rendering commands', not re.search(r'Graphics\.Draw\w*\s*\(|new CommandBuffer\s*\(|new RenderTexture\s*\(|AddComponent<Camera>',ghost))
check('Snapshot has only retained mesh objects', 'AddComponent<MeshFilter>()' in ghost and 'AddComponent<MeshRenderer>()' in ghost and 'Object.Instantiate' not in ghost)
check('Snapshot transform chain preserves local rotations and scales', 'go.transform.localRotation = original.localRotation' in ghost and 'go.transform.localScale = original.localScale' in ghost)
check('Snapshot limits vertices and submeshes', 'vertices > 2000000' in ghost and 'subMeshes > 512' in ghost)
check('Snapshot render callbacks detach symmetrically', all(v in ghost for v in ['beginCameraRendering += BeginCamera','beginCameraRendering -= BeginCamera','endCameraRendering += EndCamera','endCameraRendering -= EndCamera']))
check('Only target camera renders snapshot', 'camera == targetCamera' in ghost)
check('Overlay suspended while modal visible', '!visible&&settings.OverlayEnabled.Value' in rt and 'ghost.SetView(null,false)' in rt)
check('Overlay diagnostic bypass skips vehicle lookup and load', 'if(settings.OverlayEnabled.Value)' in rt and 'OVERLAY/BYPASS disabled; mesh/shader/material calls=0' in rt)
check('Transparency applied only on value changes', 'Mathf.Approximately(appliedOpacity, value)' in ghost)
check('Camera failures deferred to main thread cleanup', 'callbackFailed = true' in ghost and 'if (callbackFailed) { Clear(); return; }' in ghost)
check('No native cursor assignment in production source', all(not re.search(r'Cursor\.(?:lockState|visible)\s*=(?!=)',f.read_text()) for f in (root/'src').rglob('*.cs')))
check('No pointer warp or per-frame cursor-maintenance call', all(v not in lease+pointer+rt for v in ['WarpCursorPosition(', 'MaintainCursor(', 'RestoreCursor(']))
check('UI uses private module and no shared raycast traversal', 'AddComponent<UiPointerModule>()' in ui and 'raycaster.Raycast(pointer' in pointer and 'eventSystem.RaycastAll(' not in pointer)
check('No third-party input module enable-disable API', 'StandaloneInputModule' not in ui and 'InputSystemUIInputModule' not in ui)
check('UI restores only owned current EventSystem', 'if(restore&&previousEventSystem!=null&&previousEventSystem.isActiveAndEnabled)' in ui)
check('InputField text update remains enabled', 'ExecuteEvents.updateSelectedHandler' in pointer)
check('Pointer processing guards repeated frame calls', 'lastFrame == Time.frameCount' in pointer and 'frame == lastFrame' in read('src/Core/UiPointerState.cs'))
check('Pointer resets without click on focus loss', 'if (!focus)' in pointer and 'Release(null, false)' in pointer)
check('Canvas/camera observation counters included', 'framePhases(update/late/pointer/preCanvas/willCanvas/cameraBegin/cameraEnd)' in trace)
check('UI and HDRP runtime API checks included', '"UnityEngine.EventSystems.BaseInputModule","Process"' in audit and 'HDMaterial.ValidateMaterial(Material)' in audit)
check('Overlay enabled default retains requested feature', '"Overlay","Enabled",true' in read('src/Runtime/Plugin.cs'))
check('Written regression tests include zero native cursor calls', 'Cursor.Writes==0' in read('tests/InputRuntimeTests.cs'))
check('Written coordinate tests registered in C# runner', 'UiPointerTests.Register(Test)' in read('tests/Program.cs'))
# Optional lexical check, explicitly not a compiler/syntax/API proof.
try:
    from pygments import lex
    from pygments.lexers import CSharpLexer
    from pygments.token import Token
    count=0
    for f in root.rglob('*.cs'):
        stack=[]; error=False
        for typ,val in lex(f.read_text(encoding='utf-8-sig'),CSharpLexer()):
            if typ in Token.Error:error=True
            if typ in Token.Punctuation:
                for c in val:
                    if c in '([{':stack.append(c)
                    elif c in ')]}':
                        if not stack or stack.pop()!={')':'(',']':'[','}':'{'}[c]:error=True
        check('C# lexical delimiters only: '+str(f.relative_to(root)),not stack and not error);count+=1
except ImportError:
    results.append({'name':'Pygments lexical checks','result':'NOT_RUN','kind':'SOURCE_STATIC_ONLY'})
failed=sum(x['result']=='FAIL' for x in results)
output={'scope':'Source/static checks. NOT C# compilation, tests, Unity, Windows, GPU, IME, physical audio or multiplayer.', 'failed':failed, 'checks':results}
(root/'verification/static-checks.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(f"Source/static checks: {len(results)-failed} non-failing / {len(results)} entries; {failed} failed. NOT C# / Unity execution.")
for r in results:
    if r['result']=='FAIL':print(r['name'])
sys.exit(1 if failed else 0)
