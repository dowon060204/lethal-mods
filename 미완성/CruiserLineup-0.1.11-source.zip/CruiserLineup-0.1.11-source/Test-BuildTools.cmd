@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Test-BuildSupport.ps1"
set "RESULT=%ERRORLEVEL%"
popd
pause
exit /b %RESULT%
