﻿[CmdletBinding()]
param([string]$BepInExPath)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$root=$PSScriptRoot
$out=Join-Path $root ('CruiserLineup-logs-'+[DateTime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6))
[void][IO.Directory]::CreateDirectory($out)
$report=New-Object 'System.Collections.Generic.List[string]'
$report.Add('Local diagnostic copy only. No network requests/uploads, no configuration changes.')
$report.Add('Logs can contain player names, chat and local paths. Review before sharing.')

function Copy-LiveLog([string]$Source,[string]$Name) {
    if(-not $Source -or -not [IO.File]::Exists($Source)) { $report.Add('NOT FOUND: '+$Source); return $false }
    $inputFile=$null; $outputFile=$null
    try {
        $inputFile=[IO.File]::Open($Source,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
        $size=$inputFile.Length; $remaining=[Math]::Min($size,64MB)
        if($size -gt 64MB) { [void]$inputFile.Seek($size-64MB,[IO.SeekOrigin]::Begin); $report.Add('TAIL ONLY (64 MiB): '+$Source) }
        $destination=Join-Path $out $Name
        $outputFile=[IO.File]::Open($destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
        $buffer=New-Object byte[] 65536
        while($remaining -gt 0) {
            $n=$inputFile.Read($buffer,0,[int][Math]::Min($buffer.Length,$remaining))
            if($n -le 0) {break}
            $outputFile.Write($buffer,0,$n);$remaining-=$n
        }
        $report.Add('COPIED '+$Name+' <- '+$Source)
        Write-Host ('COPIED: '+$Name)
        return $true
    } catch { $report.Add('COPY FAILED: '+$Source+' | '+$_.Exception.Message); return $false }
    finally { if($null -ne $outputFile){$outputFile.Dispose()};if($null -ne $inputFile){$inputFile.Dispose()} }
}

try {
    if(-not $BepInExPath) {
        # Enumerate profile directories, not every file in the game/drive.
        $candidates=New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
        foreach($base in @((Join-Path $env:APPDATA 'com.kesomannen.gale\lethal-company\profiles'),
                           (Join-Path $env:APPDATA 'r2modmanPlus-local\LethalCompany\profiles'),
                           (Join-Path $env:APPDATA 'Thunderstore Mod Manager\DataFolder\LethalCompany\profiles'))) {
            if([IO.Directory]::Exists($base)) {
                foreach($profile in [IO.Directory]::EnumerateDirectories($base)) {
                    $log=Join-Path $profile 'BepInEx\LogOutput.log'
                    if([IO.File]::Exists($log)) {$candidates.Add([IO.FileInfo]::new($log))}
                }
            }
        }
        if($candidates.Count -gt 0) {
            $recent=$candidates | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
            $BepInExPath=$recent.DirectoryName
            $report.Add('Selected MOST RECENT profile log. Check that this is the profile that froze: '+$BepInExPath)
        }
    }
    $playerLog=$null
    if($BepInExPath) {
        [void](Copy-LiveLog (Join-Path $BepInExPath 'LogOutput.log') 'LogOutput.log')
        [void](Copy-LiveLog (Join-Path $BepInExPath 'CruiserLineup.trace.log') 'CruiserLineup.trace.log')
        [void](Copy-LiveLog (Join-Path $BepInExPath 'CruiserLineup.trace.log.previous') 'CruiserLineup.trace.previous.log')
        foreach($name in @('LogOutput.log','CruiserLineup.trace.log')) {
            $file=Join-Path $out $name
            if([IO.File]::Exists($file)) {
                foreach($line in [IO.File]::ReadLines($file,[Text.Encoding]::UTF8)) {
                    # Prefer the path reported by Unity itself; it also handles a custom -logFile.
                    if($line -match '\[PATH/PLAYER-LOG\]\s*(.+)$' -or $line -match 'PATH/PLAYER-LOG\s+(.+)$') {
                        $possible=$Matches[1].Trim()
                        if([IO.Path]::IsPathRooted($possible) -and [IO.File]::Exists($possible)) {$playerLog=$possible}
                    }
                }
            }
        }
    } else { $report.Add('No managed profile LogOutput.log found. Player log collection still attempted.') }
    $native=Join-Path $env:USERPROFILE 'AppData\LocalLow\ZeekerssRBLX\Lethal Company'
    if(-not $playerLog) {$playerLog=Join-Path $native 'Player.log'}
    [void](Copy-LiveLog $playerLog 'Player.log')
    [void](Copy-LiveLog (Join-Path ([IO.Path]::GetDirectoryName($playerLog)) 'Player-prev.log') 'Player-prev.log')
    $report.Add('Collect before restarting the game. A second launch may replace/rotate Player.log and LogOutput.log.')
} catch { $report.Add('COLLECTOR ERROR: '+$_.Exception.Message);Write-Host $_.Exception.Message }
finally {
    [IO.File]::WriteAllLines((Join-Path $out 'READ-ME.txt'),$report,[Text.UTF8Encoding]::new($false))
}
try {
    $zip=$out+'.zip'
    Compress-Archive -LiteralPath ([IO.Directory]::GetFiles($out)) -DestinationPath $zip
    Write-Host ('LOG ZIP: '+$zip)
    Write-Host 'No upload was performed. Attach the ZIP in chat after reviewing it.'
} catch {Write-Host ('ZIP failed; attach the files from: '+$out)}
