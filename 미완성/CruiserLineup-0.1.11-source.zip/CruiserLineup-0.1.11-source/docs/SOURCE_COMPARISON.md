# 0.1.11 소스 비교와 증거 범위

## 첨부 실행 0.1.10

현재 LogOutput.log는 CruiserLineup 0.1.10을 로드한 실행입니다. 308행에는 Korean sample=True, 314행에는 native uGUI, 315~316행에는 크루저 원음 준비, 325~327행에는 F10/UI SHOW가 있습니다. 최신 trace의 RUN version=0.1.10 이후 UI/TEXT/BUILD/AUDIO/PRELOAD가 끝나고 F10 이후 STALL이 기록됩니다. 이 실행에는 차량 오버레이 불러오기/캡처/재질 생성 로그가 없습니다. 사진에서도 한글 표시 자체는 복구되어 있습니다.

기존 소스는 GhostRenderer 생성자에서 메시·재질을 만들지 않고 LoadSlot의 ghost.Load에서만 만들었습니다. 따라서 '투명도를 바꾼 뒤 문제가 시작됐다'는 시간적 연관은 검토할 가치가 있지만, 최신 실행의 UI 열기 멈춤을 오버레이 코드만으로 확정할 증거는 아닙니다. consoleSelection=none이며 이전의 console 선택 가설 역시 이번 실행을 설명하지 못합니다.

## 투명도 구현 비교

0.1.0은 HDRP/Unlit 및 fallback 재질 경로가 있었고, 0.1.1~0.1.10은 Hidden/Internal-Colored와 UI/Default 대체 경로를 사용했습니다. 0.1.10 GhostRenderer.Draw는 LateUpdate에서 Graphics.DrawMesh를 반복 호출했습니다. 이 방식의 코드 존재가 GPU 멈춤의 증명은 아닙니다.

0.1.11에서는 해당 디버그/UI 셰이더 선택과 수동 DrawMesh 경로를 없앴습니다. 새 독립 HDRP/Unlit 재질을 검증하고, MeshFilter/MeshRenderer만 보유한 변환 계층을 생성하여 Unity/HDRP의 렌더링에 맡깁니다. 원본 차량의 데이터/재질/스크립트/물리/네트워크는 변경하지 않습니다. 적용된 alpha 값이 변경되었을 때만 색을 갱신합니다. 캡처는 메시·정점·서브메시·계층 깊이의 상한을 넘으면 전체 실패 처리하고 부분 성공을 보고하지 않습니다.

F10 창이 열릴 때는 기존 차량 오버레이도 숨깁니다. UI를 여는 작업은 차량 메시와 재질을 새로 생성하지 않습니다. 진단용 Enabled=false는 LoadSlot에서 FindVehicle와 ghost.Load 자체를 호출하지 않습니다.

## UI 공통 경로

0.1.10 InputLease.Acquire/MaintainCursor/RestoreCursor는 실제 커서 잠금과 표시 상태를 변경했습니다. 모달이 열린 동안 LateUpdate에서 커서를 유지하는 구조였습니다. 이 또한 특정 네이티브 함수가 실제로 멈췄다는 의미는 아닙니다.

0.1.11은 이 모드 소스에서 Cursor.lockState/visible 대입과 mouse warp를 제거합니다. 자체 BaseInputModule이 잠긴 마우스의 이동량으로 UI 포인터 좌표를 계산하며, 열린 창의 GraphicRaycaster만 검사합니다. 기존 InputField의 문자/한글 조합 이벤트는 유지합니다. 독립 EventSystem은 소유 범위에서만 current를 바꾸고 복구합니다. 다른 메뉴가 current를 바꾸면 다시 차지하지 않고 UI 종료를 요청합니다.

## 유지한 것

SystemUiText, LineupUiText, UiPreparation, 데이터 모델/저장/슬롯 순서/녹화 타이밍, GameBridge, 기존 Harmony 입력/녹화 훅, LocalChat, TimingAudio, 기본 슬롯 JSON과 라이선스는 0.1.10과 비교하여 별도 preservation.json에 바이트 단위 일치 결과를 기록합니다. 새 고급 폰트 기능이나 배포 폰트는 추가하지 않았습니다.

## 해석 한계

정적 비교는 수정 사항의 존재와 보존만 확인합니다. 실제 C# 컴파일, API 검사 실행, GPU 프레임, Windows 포인터/한글 입력, 소리 출력, 최소 프로필/호스트/게스트/4인/재입장은 현재 제작 환경에서 미검증입니다. 오류 원인을 확정하거나 모든 응답 없음이 해소되었다고 주장하지 않습니다.
