# CruiserLineup 0.1.11 검증 보고서

## 결론과 범위

이번 결과물은 소스 패키지입니다. 설치용 DLL을 컴파일하지 않았습니다. **응답 없음의 실제 원인 확정, 게임에서의 해소, 최종 반투명도 및 마우스/한글 입력 동작을 확인한 배포 완료본이 아닙니다.**

확인한 것은 사용자 제공 로그, 이전/수정 소스의 비교, 파일 구조·버전·설정·렉서 기반 정적 검사와 패키지 무결성입니다. 0.1.10에서 한글 표시가 정상임은 첨부 화면과 Korean sample=True 로그로 확인됩니다. 새 글꼴 기능을 추가하거나 그 표시 경로를 변경하지 않았습니다.

## 제공 로그로 확인되는 사실

- LogOutput.log 20~28행: 실제 로드 버전 0.1.10, imperium 프로필. 사용자 로그의 게임 v81/Unity 2022.3.62f2/Input System 1.14.0/BepInEx 5.4.23.5/Harmony 2.9.0 정보는 참고 기준이며 새 0.1.11 빌드 검증이 아닙니다.
- 308~316행: 한글 표시 준비와 native uGUI 생성, 실제 크루저 점프 원음/재생 소스 준비 완료.
- 325~327행: F10/UI 열림. 이후 마이크 버퍼 경고. 현재 실행에는 오버레이 캡처/재질 생성/불러오기 기록이 없습니다.
- trace 최신 RUN version=0.1.10 이후 텍스트·UI 준비 완료, F10 이후 STALL. consoleSelection=none. 이전 실행의 기록은 최신 실행과 구분했습니다.
- 마지막 관측 단계는 `late-update/returned-to-engine`입니다. 네이티브/그래픽/Windows 함수의 호출 스택이 없으므로 멈춘 내부 함수는 확정할 수 없습니다. Dissonance 버퍼 손실 역시 원인인지 결과인지 단정하지 않습니다.

## 수정 내용

1. 오버레이의 디버그/UI 셰이더 및 매 프레임 Graphics.DrawMesh 제거. private HDRP/Unlit 재질을 HDMaterial.ValidateMaterial로 검증한 후 MeshFilter/MeshRenderer만 있는 로컬 스냅샷을 유지합니다. 원본 크루저와 공유 재질·렌더링 전역 상태를 변경하지 않습니다. 일반 알파 블렌딩의 겹친 표면은 더 진해 보일 수 있습니다.
2. 오버레이는 지정 로컬 카메라에서만 허용하고 F10 UI가 열린 동안 숨깁니다. 버튼을 누르기 전의 UI 준비가 오버레이 재질·메시를 생성하지 않도록 분리합니다.
3. 모든 생산 소스에서 Cursor.lockState/visible 대입과 마우스 워프를 제거했습니다. 게임에 잠긴 마우스는 UI 소프트웨어 포인터로 처리합니다. 전용 BaseInputModule은 이 모드 Canvas의 Raycaster만 호출합니다. 다른 UI의 Raycaster 및 InputModule을 순회/활성화/비활성화하지 않습니다. 이름/안내 입력은 기존 native InputField입니다.
4. 전용 EventSystem의 current 소유/반납 경계, 포커스 손실과 클릭 취소, 반복 프레임/연속 클릭 제한을 적용합니다. 다른 메뉴가 current를 바꾸면 모드를 닫고 다시 빼앗지 않습니다.
5. [Overlay] Enabled=false 분리 진단은 오버레이 FindVehicle/메시/셰이더/재질 생성을 통째로 제외합니다. UI·타이밍·채팅·데이터는 남습니다. 기본값은 true이며, 기능을 꺼 두고 문제 해결로 간주하지 않습니다.
6. trace의 단계별 프레임 카운터는 Update/LateUpdate/포인터/Canvas/카메라 진행을 구별합니다. 별도 스레드는 Unity를 호출하지 않으며 데이터만 읽습니다. 카운터는 스택 덤프/실기 테스트의 대체가 아닙니다.

## 실제 수행한 검사

- `python verification/check_source.py`: **102개 정적 검사 통과**. JSON/XML 파싱, 버전 일치, 호출 경로/독립 객체 정리/글꼴 부재, C# 렉서의 구분자 균형 등. C# 컴파일러 검사는 아닙니다.
- 0.1.10과 **16개 파일의 바이트 단위 보존 비교 통과**. 결과 및 SHA256은 verification/preservation.json. 저장 데이터·기본104슬롯·오디오·GameBridge·입력 훅·한글 표시·라이선스 포함.
- 원본 0.1.10 대비 실제 변경 diff: verification/source-changes.patch.
- 소스 패키지 파일 내용과 ZIP CRC 전체 검사 수행. 최종 요약은 verification/RESULTS.json 및 ZIP 옆 package-check JSON에 기록.
- 모드/manifest/프로젝트/빌드 스크립트 버전 0.1.11 일치 확인. 빌드용 스크립트의 Windows 실행은 미수행.
- 폰트 및 DLL/EXE·빌드 캐시·사용자 로그/개인 슬롯은 소스 ZIP에 넣지 않았습니다.

## 작성되어 있으나 실행하지 않은 테스트

C# 테스트 러너에 **196개 테스트 항목**이 있습니다. 이번에는 UI 좌표 상태 14개와 실제 InputLease의 커서 무변경/외부 상태 보존 2개를 추가했습니다. Cursor는 테스트용 모형이므로 실행되더라도 Windows 네이티브 커서 시험은 아닙니다.

나머지에는 실제 Core C# 데이터의 한글/좌표/104슬롯 직렬화·저장·순서 검사, native audio/input의 API 모형 테스트, UI 생성/텍스트 렌더링 정책 검사가 있습니다. 오래된 PCM 유틸리티의 테스트는 유지하지만 실제 오디오 런타임은 원래 AudioClip 예약 재생이며 PCM 콜백을 사용하지 않습니다.

**196개를 실행해 통과했다는 뜻이 아닙니다.** 새 GhostRenderer/실제 HDRP 및 실제 UiPointerModule/Unity EventSystem은 이 테스트 러너로 실행되지 않습니다. 새 버전에서 해당 엔진 동작은 별도 실제 게임 시험이 필요합니다.

## 미검증과 구체적인 부족 환경

제작 환경에서 dotnet/csc/mcs/mono/pwsh/powershell 실행 도구와 실제 설치 게임·BepInEx 참조 DLL을 찾지 못했습니다. 따라서 다음은 수행하지 않았습니다.

- C# 플러그인 및 API 검사 도구 컴파일, C# 자동 테스트 실행, 실제 어셈블리 API 감사 실행.
- Windows Build.cmd의 전체 성공 및 dist DLL/배포 ZIP 생성.
- HDRP shader variant, 부품 겹침/카메라 컬링/투명도/그림자/다른 카메라 노출의 실제 GPU 검증.
- F10 반복 열기/닫기, 녹색 UI 포인터, 클릭/선택/드래그, 한국어 IME/한영 전환/텍스트 편집/포커스 손실.
- 실제 소리 출력 및 밀리초 타이밍, 응답 없음이 사라지는지 확인.
- 최소 환경(BepInEx+이 모드), 호스트/게스트 교대, 4인/재접속/중도 입장, Imperium 등 선택 모드와의 호환.

네트워크 상태 공유나 RPC가 없는 본인 전용 도구이므로 메시지 직렬화·버전·ACK 프로토콜 항목은 적용하지 않습니다. 그러나 호스트/게스트 각각의 로컬 UI, 입력 및 라이프사이클은 별도로 검증해야 합니다. 업데이트 데이터 보존은 소스/파일 형식 비교만 했으며 실제 기존 사용자 설정의 새 버전 적용은 실기 미검증입니다.

## 사용자 PC에서 확인할 순서

Build.cmd의 C# 테스트 → API 도구 자체 테스트 → 실제 게임 API 검사 → 플러그인 컴파일 → 배포 ZIP 단계가 모두 통과해야 합니다. 성공한 dist/CruiserLineup-0.1.11.zip을 실제 플레이 프로필에 설치하고 기존 DLL을 중복시키지 않습니다. BepInEx/config는 삭제하지 않습니다.

먼저 기존 슬롯 UI가 열리고 유지되는지 확인한 뒤 불러오기, UI 재열기/닫기, 타이밍 듣기, 이름/안내 입력, 삭제 취소, 순서 변경을 확인합니다. 원인 분리가 필요한 경우에만 종료 후 Overlay.Enabled=false로 바꿔 동일 UI 경로를 비교합니다. 다시 멈추면 재실행 전에 CollectLogs.cmd로 같은 실행의 로그를 보존합니다.
