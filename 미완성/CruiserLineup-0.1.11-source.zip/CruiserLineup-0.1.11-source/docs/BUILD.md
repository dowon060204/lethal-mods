# CruiserLineup 0.1.11 빌드·설치

Windows의 실제 Lethal Company 설치, BepInEx 5 및 .NET 8 SDK 이상이 필요합니다. 소스를 압축 해제한 뒤 **Build.cmd**를 실행합니다. 모드 실행 대상은 netstandard2.1이고, 검사 도구는 설치된 SDK에 맞춰 빌드됩니다. SDK와 게임 실행 대상을 혼동하지 않습니다.

게임·BepInEx 경로 자동 탐색 → C# 테스트 → API 검사 도구 빌드 및 자체 테스트 → 실제 게임 API 감사 → 플러그인 컴파일 → 라이선스 확인 → ZIP 생성 순서입니다. 실패하면 새 배포본을 만들지 않고 이전 ZIP을 이번 성공 결과로 표시하지 않습니다.

성공 시 `dist/CruiserLineup-0.1.11.zip`이 생성됩니다. 이 소스 ZIP 자체는 설치용이 아닙니다. 게임을 종료하고 실제 플레이하는 Gale 프로필에 생성된 ZIP을 설치하세요. `BepInEx/config`의 사용자 좌표·임시 편집·환경 설정은 삭제하지 마세요. 예전 DLL을 함께 남겨 두지 않습니다.

폰트 파일을 넣거나 설치할 필요가 없습니다. Orbit·IBM-3270·TTF 파일·폰트 다운로드/설치기·TMP 폰트 생성 코드는 없습니다. 모드 UI의 Text/InputField만 운영체제의 한글 글꼴을 한 번 불러와 재사용합니다. Windows에서는 Malgun Gothic(맑은 고딕)을 먼저 사용합니다. 게임 HUD와 다른 모드의 폰트/입력 액션은 수정하지 않습니다. 이 구현은 한글 글리프가 없는 게임 기본 TMP 에셋에 다시 의존하지 않습니다.

빌드 API 감사는 실제 `UnityEngine.UI.dll`의 Text/InputField 및 `UnityEngine.TextRenderingModule.dll`의 Font API를 검사합니다. 사용하지 않는 TMP_InputField 검사는 제거했습니다. 물리 키 대체·필수 패치 무시로 검사를 통과시키지 않습니다.

실패 시 `build-reports/Build.log`와 `build-reports/build-failure.json`을 보존하세요. 게임 재현 로그는 `CollectLogs.cmd`로 모을 수 있습니다. Build.cmd 실행·게임 실기·멀티플레이 검증은 별개입니다.

## 0.1.11 추가 참조/API 검사

게임에 포함된 HDRP 런타임의 `HDMaterial.ValidateMaterial(Material)`, CoreModule의 SRP 카메라 이벤트/메시 렌더러, uGUI의 BaseInputModule과 전용 GraphicRaycaster 시그니처를 검사합니다. 이 도구는 PE 메타데이터만 읽으며 Unity를 실행하지 않습니다. 실제 GPU 투명도와 UI 입력 동작은 컴파일과 별개의 실기 확인이 필요합니다. BepInEx 외의 별도 HDRP 모드를 설치하라는 뜻이 아닙니다.

## 실행 시 달라지는 부분

F10 창에는 마우스가 게임에 잠겨 있을 때 녹색 UI 전용 포인터가 표시됩니다. 마우스로 기존과 같이 클릭/스크롤하고 이름과 안내를 입력합니다. 모드가 Windows 커서를 매 프레임 잠금/해제하지 않습니다. 다른 UI의 입력 모듈을 Disable/Enable하지 않으며, 닫을 때 모드가 획득한 EventSystem만 복구합니다.

크루저 오버레이는 F10 창을 열면 일시적으로 숨고 닫으면 허용된 위성/착륙 상태에서 다시 표시됩니다. 위치를 삭제하거나 좌표를 바꾸지는 않습니다. 기본 Opacity는 0.25이고 기존 0.2 또는 0.3 값도 유지됩니다. 앞뒤로 겹치는 다른 차체 표면은 일반 알파 블렌딩 때문에 더 진해 보일 수 있으므로 최종 GPU 모습은 실기 확인이 필요합니다.

## 분리 진단

`BepInEx/config/com.cruiserlineup.mod.cfg`의 `[Overlay] Enabled = false`는 크루저 메시/재질/셰이더 생성 경로만 제외합니다. UI, 타이밍 듣기, 채팅, 슬롯 저장은 남습니다. 설정을 true로 돌려야 반투명 차량 표시를 사용할 수 있습니다. 값은 UI를 다시 열 때 읽습니다. 이 설정에서 멈추는지는 오버레이 가설을 분리하는 자료이지, 꺼 놓은 것을 수정 완료로 간주하는 기준이 아닙니다.

`CruiserLineup.trace.log`는 `UI/OPEN-STATE`에 preparedMeshes와 overlayRendering, `UI/POINTER-FIRST`에 자체 포인터 처리 진입, STALL에 Update/Late/포인터/Canvas/카메라 프레임 카운터를 기록합니다. 로그 카운터는 호출 스택이나 실기 테스트의 대체물이 아닙니다.
