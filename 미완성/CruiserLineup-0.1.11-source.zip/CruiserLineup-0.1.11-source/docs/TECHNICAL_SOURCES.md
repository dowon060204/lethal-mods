# 확인한 공식 자료

아래는 구현 API의 공식 자료입니다. 사용자의 실제 멈춤 원인을 증명하는 자료가 아닙니다. 확인일: 2026-10-09.

- Unity HDRP 14 Material API: https://docs.unity3d.com/Packages/com.unity.render-pipelines.high-definition@14.0/manual/Material-API.html
  스크립트로 HDRP 재질을 바꾸면 Inspector와 달리 자동 검증되지 않으므로 HDMaterial API/ValidateMaterial을 사용해야 한다는 설명.
- Unity Graphics 2022.3/staging Unlit shader: https://raw.githubusercontent.com/Unity-Technologies/Graphics/2022.3/staging/Packages/com.unity.render-pipelines.high-definition/Runtime/Material/Unlit/Unlit.shader
  _UnlitColor, transparent forward blending/ZWrite/pass 명칭 확인. 실제 설치 게임의 shader variant가 포함되는지는 실행 시 확인해야 함.
- HDRP Unlit API: https://raw.githubusercontent.com/Unity-Technologies/Graphics/2022.3/staging/Packages/com.unity.render-pipelines.high-definition/Runtime/Material/Unlit/UnlitAPI.cs
- Unity 2022.3 SRP camera callback: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Rendering.RenderPipelineManager-beginCameraRendering.html
- Unity 2022.3 Cursor.lockState: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Cursor-lockState.html
  잠김 상태에서 기본 마우스 커서가 중앙에 고정되고 표시되지 않는다는 동작 확인. 문서는 이번 응답 없음의 원인을 특정하지 않음.
- Unity uGUI EventSystem/BaseInputModule 소스: https://github.com/Unity-Technologies/uGUI/tree/main/com.unity.ugui/Runtime/UGUI/EventSystem
  모듈의 Process, selection, pointer handlers, current EventSystem 처리 참고. main은 실제 게임 버전과 동일하다고 가정하지 않으며 빌드 API 감사로 사용하는 실제 시그니처를 검사.
