﻿[CmdletBinding()]
param([string]$GamePath, [string]$BepInExPath)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = $PSScriptRoot
$version = '0.1.11'
$buildToolRevision = '0.1.0-buildfix2'
$reportDir = Join-Path $root 'build-reports'
$workDir = Join-Path $root '.build'
$dist = Join-Path $root 'dist'
$zip = Join-Path $dist "CruiserLineup-$version.zip"
$stage = $null
$transcript = $false
$buildLock = $null
$ownsLock = $false
$currentStage = 'startup'
$dotnet = $null
$childEnvironment = @{
    DOTNET_NOLOGO='1'
    DOTNET_CLI_TELEMETRY_OPTOUT='1'
    DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE='1'
    DOTNET_CLI_UI_LANGUAGE='en-US'
    DOTNET_CLI_USE_MSBUILD_SERVER='0'
    MSBUILDDISABLENODEREUSE='1'
}
. (Join-Path $root 'tools\BuildSupport.ps1')

function Invoke-BuildDotnet {
    param([string]$Name, [string[]]$Arguments, [int]$TimeoutSeconds=180, [switch]$CaptureOutput)
    $script:currentStage = $Name
    return Invoke-CLProcess -Name $Name -FilePath $dotnet -Arguments $Arguments `
        -WorkingDirectory $root -ReportDirectory $reportDir -TimeoutSeconds $TimeoutSeconds `
        -ChildEnvironment $childEnvironment -CaptureOutput:$CaptureOutput
}
function Is-Game([string]$Path) {
    return ($Path -and (Test-Path -LiteralPath (Join-Path $Path 'Lethal Company_Data\Managed\Assembly-CSharp.dll')))
}
function Is-BepInEx([string]$Path) {
    return ($Path -and (Test-Path -LiteralPath (Join-Path $Path 'core\BepInEx.dll')) -and (Test-Path -LiteralPath (Join-Path $Path 'core\0Harmony.dll')))
}
try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
        throw 'Build.cmd targets Windows with the locally installed game. This full build is not a Linux/game test.'
    }
    [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
    $OutputEncoding = [Console]::OutputEncoding
    New-Item -ItemType Directory -Path $reportDir,$dist,$workDir -Force | Out-Null
    try {
        $buildLock = [IO.File]::Open((Join-Path $workDir 'build.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        $ownsLock = $true
    } catch { throw 'Another build is using this source folder, or build.lock is not writable. Stop the old build and retry.' }
    # Only this source folder's outputs are invalidated. Never touch a Gale config or another dotnet process.
    foreach ($oldPath in @($zip, "$zip.sha256.txt", (Join-Path $reportDir 'build-result.json'), (Join-Path $reportDir 'build-failure.json'), (Join-Path $reportDir 'environment.json'), (Join-Path $reportDir 'api-audit.json'))) {
        if (Test-Path -LiteralPath $oldPath) { Remove-Item -LiteralPath $oldPath -Force }
    }
    Start-Transcript -Path (Join-Path $reportDir 'Build.log') -Force | Out-Null
    $transcript = $true
    Write-Host ('CruiserLineup ' + $version + ' | build tools ' + $buildToolRevision)
    Write-Host 'Source build -> C# tests -> actual game API audit -> plugin compilation -> release ZIP'
    Write-Host 'Each subprocess prints its command, output, exit code and a heartbeat every 10 seconds.'
    Write-Host ('Logs: ' + $reportDir)
    $dotnetCommand = Get-Command dotnet -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $dotnetCommand) { throw 'The .NET SDK is missing. Install .NET 8 SDK (x64) or newer, not just the runtime.' }
    $dotnet = $dotnetCommand.Source
    Write-CLProgress ('dotnet executable: ' + $dotnet)
    $sdkProbe = Invoke-BuildDotnet -Name '01-sdk-list' -Arguments @('--list-sdks') -TimeoutSeconds 30 -CaptureOutput
    $sdks = @($sdkProbe.StdOut -split '\r?\n' | Where-Object { $_ -match '^\d+\.' })
    if (-not ($sdks | Where-Object { $_ -match '^(\d+)\.' -and [int]$Matches[1] -ge 8 })) {
        throw 'An installed .NET SDK 8 or newer is required. A runtime-only install is insufficient.'
    }
    $selectedProbe = Invoke-BuildDotnet -Name '02-sdk-selected' -Arguments @('--version') -TimeoutSeconds 30 -CaptureOutput
    $selected = @($selectedProbe.StdOut -split '\r?\n' | Where-Object { $_ -match '^\d+\.\d+\.\d+' } | Select-Object -Last 1)
    if ($selected.Count -ne 1) { throw 'Could not determine the selected SDK from dotnet --version. See 02-sdk-selected.stdout.log.' }
    $selectedMatch = [regex]::Match($selected[0], '^(\d+)\.')
    if (-not $selectedMatch.Success) { throw 'The selected SDK version is invalid.' }
    $sdkMajor = [int]$selectedMatch.Groups[1].Value
    if ($sdkMajor -lt 8) { throw 'dotnet selected an SDK older than 8 (possibly due to a parent global.json). Run from a folder selecting SDK 8 or newer.' }
    # Compile/run build-only tools against the selected installed SDK, not an absent net8 targeting pack.
    # The game plugin always remains netstandard2.1.
    $toolFramework = 'net' + $sdkMajor + '.0'
    $currentStage = '03-path-detection'
    Write-CLProgress ('START ' + $currentStage)
    if (-not $GamePath -and $env:LETHAL_COMPANY_PATH) { $GamePath = $env:LETHAL_COMPANY_PATH }
    if (-not $GamePath) {
        $steamRoots = New-Object 'System.Collections.Generic.List[string]'
        $steamRoots.Add((Join-Path ${env:ProgramFiles(x86)} 'Steam'))
        foreach ($reg in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
            if (Test-Path $reg) {
                $values = Get-ItemProperty $reg
                foreach ($key in @('SteamPath','InstallPath')) {
                    if ($values.PSObject.Properties.Name -contains $key) { $steamRoots.Add([string]$values.$key) }
                }
            }
        }
        $libraries = New-Object 'System.Collections.Generic.List[string]'
        foreach ($steam in @($steamRoots | Select-Object -Unique)) {
            $libraries.Add($steam)
            $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
            if (Test-Path -LiteralPath $vdf) {
                $text = Get-Content -LiteralPath $vdf -Raw
                foreach ($match in [regex]::Matches($text, '"path"\s+"([^"]+)"')) {
                    $libraries.Add($match.Groups[1].Value.Replace('\\','\'))
                }
            }
        }
        foreach ($library in @($libraries | Select-Object -Unique)) {
            $candidate = Join-Path $library 'steamapps\common\Lethal Company'
            if (Is-Game $candidate) { $GamePath = $candidate; break }
        }
    }
    if (-not (Is-Game $GamePath)) { throw 'Actual game DLLs were not found. Use: .\Build.ps1 -GamePath "C:\...\steamapps\common\Lethal Company" -BepInExPath "C:\...\BepInEx"' }
    $GamePath = (Resolve-Path -LiteralPath $GamePath).Path
    $managed = Join-Path $GamePath 'Lethal Company_Data\Managed'
    if (-not $BepInExPath -and $env:LETHAL_BEPINEX_PATH) { $BepInExPath = $env:LETHAL_BEPINEX_PATH }
    if (-not $BepInExPath) {
        $profiles = Join-Path $env:APPDATA 'com.kesomannen.gale\lethal-company\profiles'
        $preferred = Join-Path $profiles '빌드용\BepInEx'
        if (Is-BepInEx $preferred) { $BepInExPath = $preferred }
        elseif (Is-BepInEx (Join-Path $GamePath 'BepInEx')) { $BepInExPath = Join-Path $GamePath 'BepInEx' }
        elseif (Test-Path -LiteralPath $profiles) {
            foreach ($profile in (Get-ChildItem -LiteralPath $profiles -Directory | Sort-Object Name)) {
                $candidate = Join-Path $profile.FullName 'BepInEx'
                if (Is-BepInEx $candidate) { $BepInExPath = $candidate; break }
            }
        }
    }
    if (-not (Is-BepInEx $BepInExPath)) { throw 'BepInEx/core/BepInEx.dll and core/0Harmony.dll are required. Gale profile "빌드용" and the game folder were searched. Supply -BepInExPath explicitly for another manager.' }
    $BepInExPath = (Resolve-Path -LiteralPath $BepInExPath).Path
    foreach ($file in @('UnityEngine.dll','UnityEngine.CoreModule.dll','UnityEngine.IMGUIModule.dll','UnityEngine.AudioModule.dll','UnityEngine.TextRenderingModule.dll','UnityEngine.UI.dll','Unity.InputSystem.dll','Unity.Netcode.Runtime.dll')) {
        if (-not (Test-Path -LiteralPath (Join-Path $managed $file))) { throw "Required actual game reference missing: $managed\$file" }
    }

    Write-Host "GamePath: $GamePath"
    Write-Host "BepInEx:  $BepInExPath"
    Write-Host ('Build SDK: ' + $selected[0] + ' | plugin target: netstandard2.1 | test/audit target: ' + $toolFramework)
    Write-CLProgress ('DONE ' + $currentStage)
    $worker = Join-Path $root 'tools\BuildWorker.ps1' 
    $powerShell = Join-Path $PSHOME 'powershell.exe'
    if (-not (Test-Path -LiteralPath $powerShell)) { $powerShell = Join-Path $PSHOME 'pwsh.exe' }
    if (-not (Test-Path -LiteralPath $powerShell)) { throw 'Could not locate the running PowerShell executable for bounded reference/HTTP workers.' }
    $currentStage = '04-reference-inventory'
    [void](Invoke-CLProcess -Name $currentStage -FilePath $powerShell -Arguments @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$worker,'-Mode','Inventory','-GamePath',$GamePath,'-BepInExPath',$BepInExPath,'-OutputPath',(Join-Path $reportDir 'environment.json')) -WorkingDirectory $root -ReportDirectory $reportDir -TimeoutSeconds 90)
    Write-CLProgress 'INVENTORY ENRICH START: verified worker report + SDK information'
    $environmentPath = Join-Path $reportDir 'environment.json'
    $environment = ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($environmentPath, [Text.Encoding]::UTF8))
    if ($environment.PSObject.Properties.Name -notcontains 'inventoryToolRevision' -or $environment.inventoryToolRevision -ne $buildToolRevision) {
        throw 'Build.ps1 and tools/BuildWorker.ps1 are from different revisions. Extract the full source ZIP into a new folder.'
    }
    Add-Member -InputObject $environment -MemberType NoteProperty -Name installedSdks -Value $sdks
    Add-Member -InputObject $environment -MemberType NoteProperty -Name selectedSdk -Value $selected[0]
    Add-Member -InputObject $environment -MemberType NoteProperty -Name dotnetPath -Value $dotnet
    Add-Member -InputObject $environment -MemberType NoteProperty -Name toolFramework -Value $toolFramework
    Add-Member -InputObject $environment -MemberType NoteProperty -Name buildToolRevision -Value $buildToolRevision
    Add-Member -InputObject $environment -MemberType NoteProperty -Name powershellVersion -Value $PSVersionTable.PSVersion.ToString()
    $environmentJson = ConvertTo-Json -InputObject $environment -Depth 4
    if ([Text.Encoding]::UTF8.GetByteCount($environmentJson) -gt 65536) { throw 'Enriched inventory exceeded the 64 KiB report limit.' }
    [IO.File]::WriteAllText($environmentPath, $environmentJson, [Text.UTF8Encoding]::new($false))
    Write-CLProgress 'INVENTORY ENRICH DONE'

    $offlineConfig = Join-Path $root 'tools\NuGet.Offline.Config'
    $testProject = Join-Path $root 'tests\CruiserLineup.CoreTests.csproj'
    $auditProject = Join-Path $root 'tools\ApiAudit\ApiAudit.csproj'
    $pluginProject = Join-Path $root 'CruiserLineup.csproj'
    # All three projects use SDK framework packs or actual local game/BepInEx DLLs, not NuGet packages.
    # Reject added PackageReference entries rather than quietly building without a requested dependency.
    foreach ($project in @($testProject, $auditProject, $pluginProject)) {
        [xml]$projectXml = Get-Content -LiteralPath $project -Raw -Encoding UTF8
        if ($projectXml.SelectNodes("//*[local-name()='PackageReference']").Count -gt 0) {
            throw ('Offline build expects no PackageReference items. A package dependency was added to ' + $project + '; review the restore configuration before building.')
        }
    }
    Write-CLProgress 'Restore uses only installed SDK packs and this project-local empty feed list. User NuGet sources are not modified.'
    Write-CLProgress 'Online repository LICENSE verification is a separate, bounded step near the end.'
    $restoreOptions = @('--configfile',$offlineConfig,'--force','--disable-parallel','--disable-build-servers','--verbosity','normal','-p:NuGetAudit=false','-nr:false')
    $buildOptions = @('-c','Release','--no-restore','--disable-build-servers','--verbosity','normal','--tl:off','-t:Rebuild','-p:UseSharedCompilation=false','-nr:false')
    $toolProperties = @("-p:TargetFramework=$toolFramework",'-p:UseAppHost=false')
    $gameProperties = @("-p:ManagedDir=$managed","-p:BepInExDir=$BepInExPath")

    [void](Invoke-BuildDotnet -Name '05-core-restore' -Arguments (@('restore',$testProject) + $restoreOptions + $toolProperties) -TimeoutSeconds 180)
    $testDll = Join-Path $root ("tests\bin\Release\$toolFramework\CruiserLineup.CoreTests.dll")
    if (Test-Path -LiteralPath $testDll) { Remove-Item -LiteralPath $testDll -Force }
    [void](Invoke-BuildDotnet -Name '06-core-build' -Arguments (@('build',$testProject) + $buildOptions + $toolProperties) -TimeoutSeconds 300)
    if (-not (Test-Path -LiteralPath $testDll)) { throw 'C# test compilation did not produce the expected new test DLL.' }
    [void](Invoke-BuildDotnet -Name '07-core-tests' -Arguments @($testDll) -TimeoutSeconds 60)

    [void](Invoke-BuildDotnet -Name '08-api-restore' -Arguments (@('restore',$auditProject) + $restoreOptions + $toolProperties) -TimeoutSeconds 180)
    $auditDll = Join-Path $root ("tools\ApiAudit\bin\Release\$toolFramework\ApiAudit.dll")
    if (Test-Path -LiteralPath $auditDll) { Remove-Item -LiteralPath $auditDll -Force }
    [void](Invoke-BuildDotnet -Name '09-api-build' -Arguments (@('build',$auditProject) + $buildOptions + $toolProperties) -TimeoutSeconds 300)
    if (-not (Test-Path -LiteralPath $auditDll)) { throw 'API audit compilation did not produce the expected new audit DLL.' }
    [void](Invoke-BuildDotnet -Name '09a-api-self-test' -Arguments @($auditDll,'--self-test') -TimeoutSeconds 30)
    [void](Invoke-BuildDotnet -Name '10-api-audit' -Arguments @($auditDll,$managed,(Join-Path $reportDir 'api-audit.json')) -TimeoutSeconds 90)

    [void](Invoke-BuildDotnet -Name '11-plugin-restore' -Arguments (@('restore',$pluginProject) + $restoreOptions + $gameProperties) -TimeoutSeconds 180)
    $dll = Join-Path $root 'bin\Release\netstandard2.1\CruiserLineup.dll'
    if (Test-Path -LiteralPath $dll) { Remove-Item -LiteralPath $dll -Force }
    [void](Invoke-BuildDotnet -Name '12-plugin-build' -Arguments (@('build',$pluginProject) + $buildOptions + $gameProperties + @('-p:ContinuousIntegrationBuild=true')) -TimeoutSeconds 300)
    if (-not (Test-Path -LiteralPath $dll)) { throw 'Compiler returned without the expected new plugin DLL.' }
    $assembly = [Reflection.AssemblyName]::GetAssemblyName($dll)
    if ($assembly.Name -ne 'CruiserLineup' -or $assembly.Version.ToString() -ne '0.1.11.0') { throw 'Compiled assembly name/version mismatch.' }
    $manifest = Get-Content -LiteralPath (Join-Path $root 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.version_number -ne $version) { throw 'Manifest version mismatch.' }
    $readme = @(Get-Content -LiteralPath (Join-Path $root 'README.md') -Encoding UTF8)
    if ($manifest.description -ne $readme[0]) { throw 'README first line and manifest.description do not match.' }

    $stage = Join-Path $dist ('.stage-' + [Guid]::NewGuid().ToString('N'))
    $pluginDir = Join-Path $stage 'plugins\CruiserLineup'
    New-Item -ItemType Directory -Path $pluginDir -Force | Out-Null
    Copy-Item -LiteralPath $dll -Destination (Join-Path $pluginDir 'CruiserLineup.dll')
    Copy-Item -LiteralPath (Join-Path $root 'assets\CruiserLineup.defaults.json') -Destination $pluginDir
    foreach ($file in @('manifest.json','README.md','CHANGELOG.md','icon.png','CollectLogs.cmd','CollectLogs.ps1')) { Copy-Item -LiteralPath (Join-Path $root $file) -Destination $stage }
    $license = Join-Path $stage 'LICENSE' 
    $currentStage = '13-license-verification'
    [void](Invoke-CLProcess -Name $currentStage -FilePath $powerShell -Arguments @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$worker,'-Mode','License','-SourceLicense',(Join-Path $root 'LICENSE'),'-OutputPath',$license) -WorkingDirectory $root -ReportDirectory $reportDir -TimeoutSeconds 60)

    $currentStage = '14-package'
    Write-CLProgress ('START ' + $currentStage)
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -CompressionLevel Optimal
    (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash | Set-Content -LiteralPath "$zip.sha256.txt" -Encoding ASCII
    $build = [ordered]@{
        version=$version; buildToolRevision=$buildToolRevision; timestampUtc=[DateTime]::UtcNow.ToString('O')
        dllSha256=(Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash
        licenseSha256=(Get-FileHash -LiteralPath $license -Algorithm SHA256).Hash
        selectedSdk=$selected[0]; toolFramework=$toolFramework; pluginFramework='netstandard2.1'
        uiTypeface='NATIVE_UGUI_OS_DEFAULT_KOREAN_NO_FONT_FILES'; apiToolSelfTests='PASS_OWN_TOOL_METADATA';
        coreTests='PASS'; coreAndNativeAudioInputCommandMockTests='PASS_NOT_UNITY_AUDIO'; mockInputAndModalCloseTests='PASS_NOT_UNITY_INPUT'; actualReferenceCompilation='PASS'; apiContract='PASS'; licenseFetch='PASS'
        unityExecution='NOT_RUN'; multiplayer='NOT_RUN'
    }
    # Success marker is written only AFTER all checks and archive creation succeeded.
    $build | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $reportDir 'build-result.json') -Encoding UTF8
    Write-CLProgress ('DONE ' + $currentStage)
    Write-Host "COMPILED PACKAGE: $zip"
    Write-Host 'Actual Unity gameplay, graphics, Korean IME, sound latency and host/guest multiplayer remain NOT TESTED.'
    Write-Host 'Build did not install the mod, alter BepInEx.cfg, reset user slots, modify global NuGet settings, or change any system settings.'
} catch {
    $errorRecord = $_
    if ($ownsLock) {
        foreach ($invalid in @($zip, "$zip.sha256.txt", (Join-Path $reportDir 'build-result.json'))) {
            if (Test-Path -LiteralPath $invalid) { Remove-Item -LiteralPath $invalid -Force -ErrorAction SilentlyContinue }
        }
        try {
            [ordered]@{buildToolRevision=$buildToolRevision;timestampUtc=[DateTime]::UtcNow.ToString('O');stage=$currentStage;message=$errorRecord.Exception.Message;position=$errorRecord.InvocationInfo.PositionMessage;stack=$errorRecord.ScriptStackTrace;success=$false} |
                ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $reportDir 'build-failure.json') -Encoding UTF8
        } catch { Write-Host ('Could not write build-failure.json: ' + $_.Exception.Message) }
    }
    Write-Host ('BUILD FAILED at ' + $currentStage + ': ' + $errorRecord.Exception.Message) -ForegroundColor Red
    Write-Host $errorRecord.InvocationInfo.PositionMessage
    Write-Host $errorRecord.ScriptStackTrace
    Write-Host 'This attempt produced no successful release package. Do not use an old ZIP as this build result.'
    Write-Host ("Send build-reports\Build.log and build-reports\build-failure.json from: " + $root)
    exit 1
} finally {
    if ($stage -and (Test-Path -LiteralPath $stage)) {
        try { Remove-Item -LiteralPath $stage -Recurse -Force } catch { Write-Host ('Stage cleanup warning: ' + $_.Exception.Message) }
    }
    if ($transcript) { try { Stop-Transcript | Out-Null } catch { Write-Host ('Transcript close warning: ' + $_.Exception.Message) } }
    if ($null -ne $buildLock) { $buildLock.Dispose() }
}
