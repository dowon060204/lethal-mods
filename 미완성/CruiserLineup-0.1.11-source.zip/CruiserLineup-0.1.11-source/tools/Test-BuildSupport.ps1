﻿# Optional actual PowerShell process-runner tests. They do NOT require or run the game.
# This file is supplied for execution on Windows, not claimed as executed in the source package.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'BuildSupport.ps1')
$root = Split-Path -Parent $PSScriptRoot
$reports = Join-Path $root 'build-reports\build-tools-tests'
$temp = Join-Path ([IO.Path]::GetTempPath()) ('CruiserLineup-도구 테스트-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $reports,$temp -Force | Out-Null
$shell = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
$probe = Join-Path $temp '입출력 테스트.ps1'
$source = @'
param([string]$Mode, [string]$Value)
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
if ($Mode -eq 'Echo') { [Console]::WriteLine($Value); [Console]::Error.WriteLine('STDERR 한글'); exit 0 }
if ($Mode -eq 'Fail') { [Console]::Error.WriteLine('Intentional exit 7'); exit 7 }
if ($Mode -eq 'Hang') { [Console]::WriteLine('Intentional timeout probe'); Start-Sleep -Seconds 120; exit 0 }
if ($Mode -eq 'Flood') {
    for ($i=0; $i -lt 64; $i++) { [Console]::Write(('A' * 4096)); [Console]::Error.Write(('B' * 4096)) }
    [Console]::WriteLine('OUT-END'); [Console]::Error.WriteLine('ERR-END'); exit 0
}
exit 9
'@
[IO.File]::WriteAllText($probe, $source, [Text.UTF8Encoding]::new($true))
$rows = [System.Collections.Generic.List[object]]::new()
function Assert-CLTest {
    param([bool]$Condition,[string]$Message)
    if (-not $Condition) { throw $Message }
}
function Run-CLTest {
    param([string]$Name,[scriptblock]$Body)
    try {
        & $Body
        $rows.Add([pscustomobject]@{name=$Name;status='PASS';error=$null})
        Write-Host ('PASS: ' + $Name)
    } catch {
        $rows.Add([pscustomobject]@{name=$Name;status='FAIL';error=$_.Exception.Message})
        Write-Host ('FAIL: ' + $Name + ': ' + $_.Exception.Message)
    }
}
try {
    Run-CLTest 'Unicode/spaces/quotes/trailing backslash and both output streams' {
        $payload = '공백 & (괄호) 따옴표" 마지막\'
        $r = Invoke-CLProcess -Name 'test-echo' -FilePath $shell -Arguments @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$probe,'-Mode','Echo','-Value',$payload) -WorkingDirectory $temp -ReportDirectory $reports -TimeoutSeconds 20 -CaptureOutput
        Assert-CLTest ($r.StdOut.TrimEnd([char[]]"`r`n") -ceq $payload) 'Native argument was changed.'
        Assert-CLTest ($r.StdErr.Contains('STDERR 한글')) 'stderr or Korean characters were lost.'
    }
    Run-CLTest 'Concurrent stdout/stderr drain with long partial lines' {
        $r = Invoke-CLProcess -Name 'test-flood' -FilePath $shell -Arguments @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$probe,'-Mode','Flood') -WorkingDirectory $temp -ReportDirectory $reports -TimeoutSeconds 30 -CaptureOutput
        Assert-CLTest ($r.StdOut.Contains('OUT-END') -and $r.StdErr.Contains('ERR-END')) 'An output pipe stalled or output was truncated.'
        Assert-CLTest ($r.StdOut.Length -gt 262144 -and $r.StdErr.Length -gt 262144) 'Flood output was incomplete.'
    }
    Run-CLTest 'Nonzero exit is rejected and recorded' {
        $rejected = $false
        try { [void](Invoke-CLProcess -Name 'test-fail' -FilePath $shell -Arguments @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$probe,'-Mode','Fail') -WorkingDirectory $temp -ReportDirectory $reports -TimeoutSeconds 20) }
        catch { $rejected = $true }
        Assert-CLTest $rejected 'Exit 7 was reported successful.'
        $status = Get-Content -LiteralPath (Join-Path $reports 'test-fail.status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        Assert-CLTest ($status.exitCode -eq 7 -and -not $status.success) 'Wrong exit/status in report.'
    }
    Run-CLTest 'Timeout rejects the step and terminates its own child' {
        $rejected = $false
        try { [void](Invoke-CLProcess -Name 'test-timeout' -FilePath $shell -Arguments @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$probe,'-Mode','Hang') -WorkingDirectory $temp -ReportDirectory $reports -TimeoutSeconds 3 -HeartbeatSeconds 1) }
        catch { $rejected = $true }
        Assert-CLTest $rejected 'Hanging process did not time out.'
        $status = Get-Content -LiteralPath (Join-Path $reports 'test-timeout.status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        Assert-CLTest ($status.timedOut -and -not $status.success) 'Wrong timeout/status in report.'
        $running = Get-Process -Id $status.pid -ErrorAction SilentlyContinue
        Assert-CLTest ($null -eq $running) 'The timed-out child is still running.'
    }
    Run-CLTest 'Missing executable is rejected and recorded' {
        $rejected = $false
        try { [void](Invoke-CLProcess -Name 'test-missing' -FilePath (Join-Path $temp 'missing.exe') -WorkingDirectory $temp -ReportDirectory $reports -TimeoutSeconds 5) }
        catch { $rejected = $true }
        Assert-CLTest $rejected 'Missing executable was reported successful.'
        $status = Get-Content -LiteralPath (Join-Path $reports 'test-missing.status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        Assert-CLTest (-not $status.success -and $null -eq $status.pid) 'Invalid missing-executable status.'
    }
    $failed = @($rows | Where-Object { $_.status -eq 'FAIL' }).Count
    [ordered]@{classification='Actual PowerShell process-runner tests; NOT C# or game tests';powershell=$PSVersionTable.PSVersion.ToString();platform=[Environment]::OSVersion.ToString();tests=$rows;failed=$failed} |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $reports 'summary.json') -Encoding UTF8
    Write-Host ('Build-tool tests: ' + ($rows.Count - $failed) + ' passed, ' + $failed + ' failed. Not game tests.')
    if ($failed -gt 0) { exit 1 }
} finally {
    if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Recurse -Force }
}
