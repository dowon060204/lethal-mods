// Runs against this tool's own compiled metadata, NOT against fake game DLLs.
internal static partial class Program
{
    private sealed class AuditFixture
    {
        public bool Flag;
        public AuditFixture(string name){Flag=name.Length!=0;}
        public static AuditFixture Instance=>null;
        public void Submit(int value) {Flag=value!=0;}
        public void AddChatMessage(string message,string name="",int player=-1,bool echo=false) {Flag=echo;}
    }
    private static int RunSelfTests()
    {
        int passed=0,failed=0;
        void Case(string label,Action assertion)
        {
            failures.Clear();
            try{assertion();passed++;Console.WriteLine("PASS audit: "+label);}
            catch(Exception e){failed++;Console.Error.WriteLine("FAIL audit: "+label+" | "+e.Message);}
            finally{failures.Clear();}
        }
        void Count(int expected)
        {if(failures.Count!=expected)throw new Exception("Expected "+expected+" failures; got "+failures.Count);}
        var type=typeof(AuditFixture).FullName;
        var data=Scan(typeof(Program).Assembly.Location,new[]{type});
        Case("metadata scanner includes selected nested type",()=>{if(!data.ContainsKey(type))throw new Exception("Nested type not scanned");});
        Case("constructor parameter is included",()=>{Method(data,type,".ctor","System.Void",false,"System.String");Count(0);});
        Case("valid instance signature accepted",()=>{Method(data,type,"Submit","System.Void",false,"System.Int32");Count(0);});
        Case("nonexistent method rejected",()=>{Method(data,type,"Unknown","System.Void",false);Count(1);});
        Case("nonexistent type rejected",()=>{Method(data,"Absent","Submit","System.Void",false,"System.Int32");Count(1);});
        Case("wrong static flag rejected",()=>{Method(data,type,"Submit","System.Void",true,"System.Int32");Count(1);});
        Case("wrong return type rejected",()=>{Method(data,type,"Submit","System.Boolean",false,"System.Int32");Count(1);});
        Case("wrong parameter type rejected",()=>{Method(data,type,"Submit","System.Void",false,"System.String");Count(1);});
        Case("missing parameter rejected",()=>{Method(data,type,"Submit","System.Void",false);Count(1);});
        Case("correct field type accepted",()=>{Field(data,type,"Flag","System.Boolean");Count(0);});
        Case("wrong field type rejected",()=>{Field(data,type,"Flag","System.Single");Count(1);});
        Case("static singleton getter accepted",()=>{Singleton(data,type);Count(0);});
        Case("optional local chat parameters accepted",()=>{if(!data[type].Methods.Any(ChatContract))throw new Exception("Valid local chat contract rejected");});
        Case("required extra chat parameter rejected",()=>{
            var m=new MethodInfoData{Name="AddChatMessage",Return="System.Void",Static=false,Parameters=new[]{"System.String","System.Boolean"},OptionalDefaults=new[]{false,false}};
            if(ChatContract(m))throw new Exception("Required parameter accepted");
        });
        Console.WriteLine("API audit self-tests: "+passed+" passed, "+failed+" failed. Own tool metadata only; NOT Unity/game execution.");
        return failed==0?0:1;
    }
}
