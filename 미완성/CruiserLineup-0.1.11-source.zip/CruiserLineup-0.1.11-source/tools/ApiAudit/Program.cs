using System.Collections.Immutable;
using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;

internal sealed class Names : ISignatureTypeProvider<string, object>
{
    public string GetArrayType(string element,ArrayShape shape)=>element+"["+new string(',',Math.Max(0,shape.Rank-1))+"]";
    public string GetByReferenceType(string element)=>element+"&";
    public string GetFunctionPointerType(MethodSignature<string> signature)=>"function-pointer";
    public string GetGenericInstantiation(string generic,ImmutableArray<string> arguments)=>generic+"<"+string.Join(",",arguments)+">";
    public string GetGenericMethodParameter(object context,int index)=>"!!"+index;
    public string GetGenericTypeParameter(object context,int index)=>"!"+index;
    public string GetModifiedType(string modifier,string unmodified,bool required)=>unmodified;
    public string GetPinnedType(string element)=>element;
    public string GetPointerType(string element)=>element+"*";
    public string GetPrimitiveType(PrimitiveTypeCode code)=>"System."+code;
    public string GetSZArrayType(string element)=>element+"[]";
    public string GetTypeFromDefinition(MetadataReader reader,TypeDefinitionHandle handle,byte rawTypeKind)
    {
        var t=reader.GetTypeDefinition(handle);var parent=t.GetDeclaringType();var name=reader.GetString(t.Name);
        if(!parent.IsNil)return GetTypeFromDefinition(reader,parent,rawTypeKind)+"+"+name;
        var ns=reader.GetString(t.Namespace);return ns.Length==0?name:ns+"."+name;
    }
    public string GetTypeFromReference(MetadataReader reader,TypeReferenceHandle handle,byte rawTypeKind)
    {
        var t=reader.GetTypeReference(handle);var name=reader.GetString(t.Name);
        if(t.ResolutionScope.Kind==HandleKind.TypeReference)return GetTypeFromReference(reader,(TypeReferenceHandle)t.ResolutionScope,rawTypeKind)+"+"+name;
        var ns=reader.GetString(t.Namespace);return ns.Length==0?name:ns+"."+name;
    }
    public string GetTypeFromSpecification(MetadataReader reader,object context,TypeSpecificationHandle handle,byte rawTypeKind)=>reader.GetTypeSpecification(handle).DecodeSignature(this,context);
}
internal sealed class MethodInfoData
{
    public string Name {get;set;} public string Return {get;set;}
    public string[] Parameters {get;set;} public bool[] OptionalDefaults {get;set;}
    public bool Static {get;set;} public string BodySha256 {get;set;}
}
internal sealed class TypeInfoData
{
    public Dictionary<string,string> Fields {get;set;}=new();
    public List<MethodInfoData> Methods {get;set;}=new();
}
internal static partial class Program
{
    private static readonly Names names=new();
    private static readonly List<string> failures=new();
    private static Dictionary<string,TypeInfoData> Scan(string path,IEnumerable<string> selected)
    {
        var wanted=selected.ToHashSet();var result=new Dictionary<string,TypeInfoData>();
        using var stream=File.OpenRead(path);using var pe=new PEReader(stream);var reader=pe.GetMetadataReader();
        foreach(var handle in reader.TypeDefinitions)
        {
            var full=names.GetTypeFromDefinition(reader,handle,0);if(!wanted.Contains(full))continue;
            var type=reader.GetTypeDefinition(handle);var data=new TypeInfoData();
            foreach(var fieldHandle in type.GetFields())
            {var field=reader.GetFieldDefinition(fieldHandle);data.Fields[reader.GetString(field.Name)]=field.DecodeSignature(names,null);}
            foreach(var methodHandle in type.GetMethods())
            {
                var method=reader.GetMethodDefinition(methodHandle);var signature=method.DecodeSignature(names,null);
                var optional=new bool[signature.ParameterTypes.Length];
                foreach(var parameterHandle in method.GetParameters())
                {
                    var p=reader.GetParameter(parameterHandle);if(p.SequenceNumber<=0||p.SequenceNumber>optional.Length)continue;
                    optional[p.SequenceNumber-1]=(p.Attributes&ParameterAttributes.Optional)!=0&&!p.GetDefaultValue().IsNil;
                }
                string hash=null;
                if(method.RelativeVirtualAddress!=0)
                    hash=Convert.ToHexString(SHA256.HashData(pe.GetMethodBody(method.RelativeVirtualAddress).GetILBytes()));
                data.Methods.Add(new MethodInfoData{Name=reader.GetString(method.Name),Return=signature.ReturnType,Parameters=signature.ParameterTypes.ToArray(),OptionalDefaults=optional,Static=(method.Attributes&MethodAttributes.Static)!=0,BodySha256=hash});
            }
            result[full]=data;
        }
        return result;
    }
    private static void Field(Dictionary<string,TypeInfoData> data,string type,string field,string expected)
    {
        if(!data.TryGetValue(type,out var t)||!t.Fields.TryGetValue(field,out var found)||found!=expected)
            failures.Add($"Missing or changed field {type}.{field}: expected {expected}");
    }
    private static void Method(Dictionary<string,TypeInfoData> data,string type,string method,string returns,bool isStatic,params string[] parameters)
    {
        if(!data.TryGetValue(type,out var owner)||!owner.Methods.Any(m=>m.Name==method&&m.Return==returns&&m.Static==isStatic&&m.Parameters.SequenceEqual(parameters)))
            failures.Add("Missing or changed required method: "+type+"."+method+"("+string.Join(",",parameters)+"):"+returns);
    }
    private static void Singleton(Dictionary<string,TypeInfoData> data,string type)
    {
        if(!data.TryGetValue(type,out var t)||!((t.Fields.TryGetValue("Instance",out var field)&&field==type)||t.Methods.Any(m=>m.Name=="get_Instance"&&m.Static&&m.Return==type&&m.Parameters.Length==0)))
            failures.Add("Missing Instance singleton contract: "+type);
    }
    private static bool ChatContract(MethodInfoData m)=>m.Name=="AddChatMessage"&&!m.Static&&m.Return=="System.Void"&&m.Parameters.Length>=1&&m.Parameters.Length<=8&&m.Parameters[0]=="System.String"&&
        Enumerable.Range(1,m.Parameters.Length-1).All(i=>m.OptionalDefaults[i]&&new[]{"System.String","System.Int32","System.Boolean"}.Contains(m.Parameters[i]));
    private static int Main(string[] args)
    {
        if(args.Length==1&&args[0]=="--self-test") return RunSelfTests();
        failures.Clear();
        if(args.Length!=2){Console.Error.WriteLine("Usage: ApiAudit <actual game Managed directory> <report.json>");return 2;}
        try
        {
            var managed=Path.GetFullPath(args[0]);var assemblyPath=Path.Combine(managed,"Assembly-CSharp.dll");
            var classes=new[]{"VehicleController","GameNetcodeStuff.PlayerControllerB","StartOfRound","HUDManager","GameNetworkManager","SelectableLevel","QuickMenuManager","IngamePlayerSettings"};
            var game=Scan(assemblyPath,classes);
            foreach(var type in classes.Take(6))if(!game.ContainsKey(type))failures.Add("Missing game type "+type);
            foreach(var spec in new[]{
                ("VehicleController","localPlayerInControl","System.Boolean"),("VehicleController","carDestroyed","System.Boolean"),("VehicleController","vehicleID","System.Int32"),("VehicleController","jumpInCarSFX","UnityEngine.AudioClip"),
                ("StartOfRound","currentLevel","SelectableLevel"),("StartOfRound","inShipPhase","System.Boolean"),("StartOfRound","shipHasLanded","System.Boolean"),
                ("GameNetcodeStuff.PlayerControllerB","disableMoveInput","System.Boolean"),("GameNetcodeStuff.PlayerControllerB","disableLookInput","System.Boolean"),("GameNetcodeStuff.PlayerControllerB","moveInputVector","UnityEngine.Vector2"),
                ("VehicleController","steeringInput","System.Single"),
                ("GameNetcodeStuff.PlayerControllerB","isPlayerDead","System.Boolean"),("GameNetcodeStuff.PlayerControllerB","isTypingChat","System.Boolean"),("GameNetcodeStuff.PlayerControllerB","gameplayCamera","UnityEngine.Camera"),
                ("GameNetworkManager","localPlayerController","GameNetcodeStuff.PlayerControllerB"),("SelectableLevel","sceneName","System.String"),("SelectableLevel","PlanetName","System.String")})Field(game,spec.Item1,spec.Item2,spec.Item3);
            foreach(var type in new[]{"StartOfRound","HUDManager","GameNetworkManager"})Singleton(game,type);
            var context="UnityEngine.InputSystem.InputAction+CallbackContext";
            if(!game.TryGetValue("VehicleController",out var vehicle)||!vehicle.Methods.Any(m=>m.Name=="DoTurboBoost"&&!m.Static&&m.Return=="System.Void"&&m.Parameters.SequenceEqual(new[]{context})))
                failures.Add("Recording requires VehicleController.DoTurboBoost(InputAction.CallbackContext):void. No physical-key fallback.");
            foreach(var contract in new[]{("VehicleController","GetVehicleInput"),("GameNetcodeStuff.PlayerControllerB","Update")})
                if(!game.TryGetValue(contract.Item1,out var owner)||!owner.Methods.Any(m=>m.Name==contract.Item2&&!m.Static&&m.Return=="System.Void"&&m.Parameters.Length==0))
                    failures.Add("Modal input protection requires "+contract.Item1+"."+contract.Item2+"():void");
            if(!game.TryGetValue("HUDManager",out var hud)||!hud.Methods.Any(ChatContract))failures.Add("No supported local HUDManager.AddChatMessage overload. Release packaging blocked.");
            var inputPath=Path.Combine(managed,"Unity.InputSystem.dll");
            var input=Scan(inputPath,new[]{context,"UnityEngine.InputSystem.Keyboard",
                "UnityEngine.InputSystem.InputDevice","UnityEngine.InputSystem.InputControl","UnityEngine.InputSystem.Controls.ButtonControl"});
            Method(input,"UnityEngine.InputSystem.Keyboard","get_current","UnityEngine.InputSystem.Keyboard",true);
            Method(input,"UnityEngine.InputSystem.Keyboard","get_allKeys",
                "UnityEngine.InputSystem.Utilities.ReadOnlyArray`1<UnityEngine.InputSystem.Controls.KeyControl>",false);
            Method(input,"UnityEngine.InputSystem.InputDevice","get_added","System.Boolean",false);
            Method(input,"UnityEngine.InputSystem.InputControl","get_device","UnityEngine.InputSystem.InputDevice",false);
            Method(input,"UnityEngine.InputSystem.Controls.ButtonControl","get_isPressed","System.Boolean",false);
            if(!input.TryGetValue(context,out var callback)||!callback.Methods.Any(m=>m.Name=="get_time"&&m.Return=="System.Double"))failures.Add("Missing input event timestamp API");
            var audioPath=Path.Combine(managed,"UnityEngine.AudioModule.dll");
            var audio=Scan(audioPath,new[]{"UnityEngine.AudioClip","UnityEngine.AudioSource","UnityEngine.AudioSettings"});
            Method(audio,"UnityEngine.AudioClip","LoadAudioData","System.Boolean",false);
            Method(audio,"UnityEngine.AudioSource","PlayScheduled","System.Void",false,"System.Double");
            Method(audio,"UnityEngine.AudioSettings","get_dspTime","System.Double",true);
            // Private BaseInputModule and own-canvas raycasts. No global RaycastAll,
            // StandaloneInputModule, InputSystemUIInputModule or cursor setter contract.
            var uiPath=Path.Combine(managed,"UnityEngine.UI.dll");
            var ui=Scan(uiPath,new[]{"UnityEngine.UI.Button","UnityEngine.UI.GraphicRaycaster","UnityEngine.EventSystems.EventSystem",
                "UnityEngine.EventSystems.BaseInputModule","UnityEngine.EventSystems.PointerEventData","UnityEngine.EventSystems.ExecuteEvents",
                "UnityEngine.UI.Text","UnityEngine.UI.InputField","UnityEngine.UI.VertexHelper"});
            Method(ui,"UnityEngine.EventSystems.EventSystem","set_current","System.Void",true,"UnityEngine.EventSystems.EventSystem");
            Method(ui,"UnityEngine.EventSystems.BaseInputModule","Process","System.Void",false);
            Method(ui,"UnityEngine.EventSystems.BaseInputModule","HandlePointerExitAndEnter","System.Void",false,"UnityEngine.EventSystems.PointerEventData","UnityEngine.GameObject");
            Method(ui,"UnityEngine.UI.GraphicRaycaster","Raycast","System.Void",false,"UnityEngine.EventSystems.PointerEventData","System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>");
            foreach(var name in new[]{"UnityEngine.UI.Button","UnityEngine.UI.GraphicRaycaster","UnityEngine.EventSystems.EventSystem","UnityEngine.EventSystems.PointerEventData","UnityEngine.EventSystems.ExecuteEvents"})
                if(!ui.ContainsKey(name)) failures.Add("Missing retained UI type: "+name);
            // Native uGUI text, not TMP. Validate what the actual implementation calls.
            Method(ui,"UnityEngine.UI.InputField","SetTextWithoutNotify","System.Void",false,"System.String");
            Method(ui,"UnityEngine.UI.InputField","set_textComponent","System.Void",false,"UnityEngine.UI.Text");
            Method(ui,"UnityEngine.UI.Text","set_font","System.Void",false,"UnityEngine.Font");
            Method(ui,"UnityEngine.UI.Text","OnPopulateMesh","System.Void",false,"UnityEngine.UI.VertexHelper");
            foreach(var name in new[]{"UnityEngine.UI.Text","UnityEngine.UI.InputField","UnityEngine.UI.VertexHelper"})
                if(!ui.ContainsKey(name)) failures.Add("Missing native UI type: "+name);
            var textPath=Path.Combine(managed,"UnityEngine.TextRenderingModule.dll");
            var textRendering=Scan(textPath,new[]{"UnityEngine.Font"});
            Method(textRendering,"UnityEngine.Font","CreateDynamicFontFromOSFont","UnityEngine.Font",true,"System.String[]","System.Int32");
            Method(textRendering,"UnityEngine.Font","RequestCharactersInTexture","System.Void",false,"System.String","System.Int32","UnityEngine.FontStyle");
            Method(textRendering,"UnityEngine.Font","HasCharacter","System.Boolean",false,"System.Char");
            Method(audio,"UnityEngine.AudioSource","set_spatializePostEffects","System.Void",false,"System.Boolean");
            Method(audio,"UnityEngine.AudioSource","set_ignoreListenerPause","System.Void",false,"System.Boolean");
            var corePath=Path.Combine(managed,"UnityEngine.CoreModule.dll");
            var rendering=Scan(corePath,new[]{"UnityEngine.Material","UnityEngine.Renderer","UnityEngine.MeshFilter","UnityEngine.Rendering.RenderPipelineManager"});
            Method(rendering,"UnityEngine.Renderer","set_enabled","System.Void",false,"System.Boolean");
            Method(rendering,"UnityEngine.Renderer","set_sharedMaterials","System.Void",false,"UnityEngine.Material[]");
            Method(rendering,"UnityEngine.MeshFilter","set_sharedMesh","System.Void",false,"UnityEngine.Mesh");
            Method(rendering,"UnityEngine.Material","FindPass","System.Int32",false,"System.String");
            foreach(var eventName in new[]{"add_beginCameraRendering","remove_beginCameraRendering","add_endCameraRendering","remove_endCameraRendering"})
                Method(rendering,"UnityEngine.Rendering.RenderPipelineManager",eventName,"System.Void",true,"System.Action`2<UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera>");
            var hdrpFiles=Directory.GetFiles(managed,"*HighDefinition*.dll");
            var hdrp=new Dictionary<string,TypeInfoData>();
            foreach(var path in hdrpFiles)
                foreach(var pair in Scan(path,new[]{"UnityEngine.Rendering.HighDefinition.HDMaterial"}))hdrp[pair.Key]=pair.Value;
            if(!hdrp.TryGetValue("UnityEngine.Rendering.HighDefinition.HDMaterial",out var hd)||
                !hd.Methods.Any(m=>m.Name=="ValidateMaterial"&&m.Static&&new[]{"System.Boolean","System.Void"}.Contains(m.Return)&&m.Parameters.SequenceEqual(new[]{"UnityEngine.Material"})))
                failures.Add("HDRP HDMaterial.ValidateMaterial(Material) is required for validated transparent overlay materials.");
            var assemblies=new List<object>();
            foreach(var p in new[]{assemblyPath,inputPath,audioPath,uiPath,textPath,corePath,Path.Combine(managed,"Unity.Netcode.Runtime.dll")}.Concat(hdrpFiles))
            {var a=AssemblyName.GetAssemblyName(p);assemblies.Add(new {path=p,name=a.Name,version=a.Version.ToString(),sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p)))});}
            var report=new {tool="CruiserLineup API audit 0.1.11",timestampUtc=DateTime.UtcNow.ToString("O"),result=failures.Count==0?"CONTRACT_PASS_NOT_GAME_TESTED":"CONTRACT_FAIL",failures,assemblies,game,input,audio,ui,textRendering,rendering,hdrp,
                limitations="Metadata and method-body hashes only; does not execute game methods, Unity, Harmony patches, input events, rendering, audio or multiplayer."};
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(args[1])));
            File.WriteAllText(args[1],JsonSerializer.Serialize(report,new JsonSerializerOptions{WriteIndented=true}));
            foreach(var failure in failures)Console.Error.WriteLine("FAIL "+failure);
            Console.WriteLine("API audit: "+(failures.Count==0?"contract passed; NOT a gameplay test":"FAILED")+". Report: "+args[1]);
            return failures.Count==0?0:1;
        }
        catch(Exception e){Console.Error.WriteLine("API AUDIT ERROR: "+e);return 2;}
    }
}
