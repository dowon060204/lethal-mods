﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateSet('Inventory','License')][string]$Mode,
    [string]$GamePath,
    [string]$BepInExPath,
    [Parameter(Mandatory=$true)][string]$OutputPath,
    [string]$SourceLicense
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding
$inventoryToolRevision = '0.1.0-buildfix2'
$tempReport = $null

function Assert-CLInventoryRoundTrip {
    param([System.Collections.IDictionary]$Expected, [object]$Actual)
    if ($null -eq $Actual) { throw 'The inventory JSON restored as null.' }
    foreach ($key in @('inventoryToolRevision','gamePath','bepinexPath','actualGameExecution','multiplayer','hideManagerGameObjectStatus')) {
        if ($Actual.PSObject.Properties.Name -notcontains $key) { throw ('Inventory JSON is missing: ' + $key) }
        if ($Actual.$key -isnot [string] -or $Actual.$key -cne $Expected[$key]) { throw ('Inventory JSON value/type mismatch: ' + $key) }
    }
    # PowerShell 5.1 preserves this ISO value as a string; newer editions can
    # restore a DateTime. Compare the UTC instant without requiring a new-only flag.
    if ($Actual.PSObject.Properties.Name -notcontains 'timestampUtc') { throw 'Inventory JSON is missing timestampUtc.' }
    $restoredTimestamp = $Actual.timestampUtc
    if ($restoredTimestamp -is [DateTime]) { $restoredTimestamp = $restoredTimestamp.ToUniversalTime().ToString('O') }
    elseif ($restoredTimestamp -is [DateTimeOffset]) { $restoredTimestamp = $restoredTimestamp.UtcDateTime.ToString('O') }
    if ($restoredTimestamp -isnot [string] -or $restoredTimestamp -cne $Expected['timestampUtc']) {
        throw 'Inventory timestamp did not round-trip.'
    }
    if ($Actual.PSObject.Properties.Name -notcontains 'assemblies') { throw 'Inventory JSON is missing assemblies.' }
    if ($Actual.assemblies -isnot [System.Array] -or $Actual.assemblies.Count -ne $Expected.assemblies.Count) {
        throw 'Inventory JSON assembly list/count mismatch.'
    }
    for ($i=0; $i -lt $Expected.assemblies.Count; $i++) {
        foreach ($key in @('path','name','version','sha256')) {
            if ($Actual.assemblies[$i].PSObject.Properties.Name -notcontains $key) { throw ('Inventory assembly is missing: ' + $key) }
            if ($Actual.assemblies[$i].$key -isnot [string] -or $Actual.assemblies[$i].$key -cne $Expected.assemblies[$i][$key]) {
                throw ('Inventory assembly round-trip mismatch at index ' + $i + ': ' + $key)
            }
        }
    }
    if ($Actual.PSObject.Properties.Name -notcontains 'hideManagerGameObject') { throw 'Inventory JSON is missing the config-line array.' }
    if ($Actual.hideManagerGameObject -isnot [System.Array] -or $Actual.hideManagerGameObject.Count -ne $Expected.hideManagerGameObject.Count) {
        throw 'Inventory JSON config-line array/count mismatch.'
    }
    for ($i=0; $i -lt $Expected.hideManagerGameObject.Count; $i++) {
        if ($Actual.hideManagerGameObject[$i] -isnot [string] -or $Actual.hideManagerGameObject[$i] -cne $Expected.hideManagerGameObject[$i]) {
            throw ('Inventory config line did not round-trip at index ' + $i)
        }
    }
}

try {
    if ($Mode -eq 'Inventory') {
        $managed = Join-Path $GamePath 'Lethal Company_Data\Managed'
        $result = [ordered]@{
            inventoryToolRevision=$inventoryToolRevision
            timestampUtc=[DateTime]::UtcNow.ToString('O'); gamePath=$GamePath; bepinexPath=$BepInExPath
            actualGameExecution='NOT_RUN'; multiplayer='NOT_RUN'; assemblies=@()
        }
        foreach ($file in @((Join-Path $managed 'Assembly-CSharp.dll'),(Join-Path $managed 'Unity.InputSystem.dll'),(Join-Path $managed 'UnityEngine.CoreModule.dll'),(Join-Path $managed 'Unity.Netcode.Runtime.dll'),(Join-Path $BepInExPath 'core\BepInEx.dll'),(Join-Path $BepInExPath 'core\0Harmony.dll'))) {
            Write-Host ('REFERENCE START: ' + $file)
            $assembly = [Reflection.AssemblyName]::GetAssemblyName($file)
            Write-Host ('REFERENCE HASH:  ' + $assembly.Name)
            $hash = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
            $result.assemblies += [ordered]@{path=$file;name=$assembly.Name;version=$assembly.Version.ToString();sha256=$hash}
            Write-Host ('REFERENCE DONE:  ' + $assembly.Name + ' ' + $assembly.Version)
        }
        $bepConfig = Join-Path $BepInExPath 'config\BepInEx.cfg'
        Write-Host ('CONFIG READ START: ' + $bepConfig + ' | read-only')
        $configLines = [System.Collections.Generic.List[string]]::new()
        $configStatus = 'file-not-found'
        if (Test-Path -LiteralPath $bepConfig -PathType Leaf) {
            # Get-Content attaches ETS properties (PSDrive/PSProvider/PSPath) to its
            # output. Windows PowerShell 5.1 ConvertTo-Json traverses those objects.
            # ReadAllLines returns only .NET strings; never serialize provider objects.
            foreach ($line in [IO.File]::ReadAllLines($bepConfig, [Text.Encoding]::UTF8)) {
                if ($line -match '^\s*HideManagerGameObject\s*=') {
                    $configLines.Add($line.ToString())
                }
            }
            $configStatus = if ($configLines.Count -gt 0) { 'matched-lines' } else { 'key-not-found' }
        }
        # Keep an actual array for 0, 1 and many matches. Missing is NOT false.
        $result['hideManagerGameObject'] = $configLines.ToArray()
        $result['hideManagerGameObjectStatus'] = $configStatus
        Write-Host ('CONFIG READ DONE: status=' + $configStatus + ' | matched=' + $configLines.Count)
        Write-Host 'REPORT JSON START: primitive fields only'
        $json = ConvertTo-Json -InputObject $result -Depth 4
        if ([Text.Encoding]::UTF8.GetByteCount($json) -gt 65536) { throw 'Inventory JSON exceeded 64 KiB. Refusing an unexpectedly expanded report.' }
        Assert-CLInventoryRoundTrip -Expected $result -Actual (ConvertFrom-Json -InputObject $json)
        Write-Host ('REPORT JSON DONE: chars=' + $json.Length + ' | round-trip=PASS')
        Write-Host ('REPORT WRITE START: ' + $OutputPath)
        $tempReport = $OutputPath + '.tmp-' + [Guid]::NewGuid().ToString('N')
        [IO.File]::WriteAllText($tempReport, $json, [Text.UTF8Encoding]::new($false))
        $readBack = [IO.File]::ReadAllText($tempReport, [Text.Encoding]::UTF8)
        if ($readBack -cne $json) { throw 'Inventory report bytes did not read back as the original UTF-8 text.' }
        Assert-CLInventoryRoundTrip -Expected $result -Actual (ConvertFrom-Json -InputObject $readBack)
        if ([IO.File]::Exists($OutputPath)) {
            [IO.File]::Replace($tempReport, $OutputPath, $null)
        } else {
            [IO.File]::Move($tempReport, $OutputPath)
        }
        $tempReport = $null
        Write-Host ('REPORT WRITE DONE: assemblies=' + $result.assemblies.Count + ' | configLines=' + $configLines.Count + ' | disk round-trip=PASS')
        Write-Host ('REFERENCE REPORT: ' + $OutputPath)
    } else {
        if (-not (Test-Path -LiteralPath $SourceLicense)) { throw 'The source LICENSE file is missing.' }
        $sourceText = [IO.File]::ReadAllText($SourceLicense)
        if (-not $sourceText.StartsWith('# Pensil License 1.1')) { throw 'The source license is not the reviewed Pensil License 1.1.' }
        $uri = 'https://raw.githubusercontent.com/dowon060204/lethal-mods/main/LICENSE'
        Write-Host ('LICENSE FETCH: ' + $uri + ' | HTTP timeout=30s')
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri $uri -OutFile $OutputPath -TimeoutSec 30
        $remoteText = [IO.File]::ReadAllText($OutputPath)
        if (-not $remoteText.StartsWith('# Pensil License 1.1')) {
            throw 'Upstream license no longer matches the reviewed Pensil License 1.1 version. Review before packaging.'
        }
        $remoteHash = (Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash
        # Keep the downloaded raw bytes. Do not rewrite encoding/newlines or require a locally reconstructed snapshot's byte hash.
        Write-Host ('LICENSE FETCHED: Pensil License 1.1 | upstream raw-byte SHA256=' + $remoteHash)
    }
} catch {
    [Console]::Error.WriteLine(('WORKER FAILED: ' + $_.Exception.Message))
    [Console]::Error.WriteLine($_.ScriptStackTrace)
    exit 1
}
finally {
    if ($null -ne $tempReport -and [IO.File]::Exists($tempReport)) {
        try { [IO.File]::Delete($tempReport) }
        catch { [Console]::Error.WriteLine(('WORKER TEMP CLEANUP WARNING: ' + $_.Exception.Message)) }
    }
}
