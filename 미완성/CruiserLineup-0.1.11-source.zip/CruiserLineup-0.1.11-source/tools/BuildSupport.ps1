﻿# Build tooling only. Windows PowerShell 5.1 / PowerShell 7 compatible syntax.
# No event callbacks: stdout and stderr are read concurrently with Task-based reads.
Set-StrictMode -Version Latest

function ConvertTo-CLNativeArgument {
    param([AllowEmptyString()][string]$Value)
    if ($Value.IndexOf([char]0) -ge 0) { throw 'A native argument contains a NUL character.' }
    # Windows CRT quoting: escape quotes, and double backslashes before quotes/end.
    $builder = [System.Text.StringBuilder]::new()
    [void]$builder.Append('"')
    $slashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq [char]92) { $slashes++; continue }
        if ($character -eq [char]34) {
            [void]$builder.Append([char]92, (2 * $slashes + 1))
            [void]$builder.Append([char]34)
        } else {
            [void]$builder.Append([char]92, $slashes)
            [void]$builder.Append($character)
        }
        $slashes = 0
    }
    [void]$builder.Append([char]92, (2 * $slashes))
    [void]$builder.Append('"')
    return $builder.ToString()
}

function Write-CLProgress {
    param([string]$Message)
    Write-Host ('[{0}] {1}' -f [DateTime]::Now.ToString('HH:mm:ss'), $Message)
}

function Stop-CLProcessTree {
    param([System.Diagnostics.Process]$Process)
    if ($Process.HasExited) { return }
    Write-CLProgress ('STOP: terminating only this build process tree, PID={0}' -f $Process.Id)
    if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
        $killer = [System.Diagnostics.Process]::new()
        try {
            $killer.StartInfo.FileName = Join-Path $env:SystemRoot 'System32\taskkill.exe'
            $killer.StartInfo.Arguments = '/PID ' + $Process.Id + ' /T /F'
            $killer.StartInfo.UseShellExecute = $false
            $killer.StartInfo.CreateNoWindow = $true
            $killer.StartInfo.RedirectStandardOutput = $true
            $killer.StartInfo.RedirectStandardError = $true
            if ($killer.Start()) {
                $outTask = $killer.StandardOutput.ReadToEndAsync()
                $errTask = $killer.StandardError.ReadToEndAsync()
                if (-not $killer.WaitForExit(5000)) { $killer.Kill() }
                if ($outTask.IsCompleted -and -not $outTask.IsFaulted) { Write-Host -NoNewline $outTask.Result }
                if ($errTask.IsCompleted -and -not $errTask.IsFaulted) { Write-Host -NoNewline $errTask.Result }
            }
        } catch { Write-CLProgress ('WARNING: process-tree cleanup: ' + $_.Exception.Message) }
        finally { $killer.Dispose() }
    } else {
        try { $Process.Kill($true) } catch { Write-CLProgress ('WARNING: process-tree cleanup: ' + $_.Exception.Message) }
    }
    if (-not $Process.HasExited) {
        try { $Process.Kill() } catch { Write-CLProgress ('WARNING: process cleanup: ' + $_.Exception.Message) }
    }
    if (-not $Process.WaitForExit(3000)) {
        Write-CLProgress ('WARNING: PID {0} could not be confirmed stopped. Close the old build window before retrying.' -f $Process.Id)
    }
}

function Invoke-CLProcess {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string[]]$Arguments = @(),
        [Parameter(Mandatory=$true)][string]$WorkingDirectory,
        [Parameter(Mandatory=$true)][string]$ReportDirectory,
        [ValidateRange(1,3600)][int]$TimeoutSeconds = 180,
        [ValidateRange(1,60)][int]$HeartbeatSeconds = 10,
        [hashtable]$ChildEnvironment = @{},
        [switch]$CaptureOutput,
        [int[]]$AllowedExitCodes = @(0)
    )
    $safeName = [regex]::Replace($Name, '[^a-zA-Z0-9_-]', '-')
    $stdoutPath = Join-Path $ReportDirectory ($safeName + '.stdout.log')
    $stderrPath = Join-Path $ReportDirectory ($safeName + '.stderr.log')
    $statusPath = Join-Path $ReportDirectory ($safeName + '.status.json')
    [void][IO.Directory]::CreateDirectory($ReportDirectory)
    $encoding = [System.Text.UTF8Encoding]::new($false)
    $process = [System.Diagnostics.Process]::new()
    $streams = @()
    $started = $false
    $success = $false
    $exitCode = $null
    $childId = $null
    $failure = $null
    $timedOut = $false
    $startedUtc = [DateTime]::UtcNow.ToString('O')
    $clock = [System.Diagnostics.Stopwatch]::StartNew()
    $quoted = @($Arguments | ForEach-Object { ConvertTo-CLNativeArgument $_ })
    $command = (ConvertTo-CLNativeArgument $FilePath) + ' ' + ($quoted -join ' ')
    Write-CLProgress ('START {0} | timeout={1}s' -f $Name, $TimeoutSeconds)
    Write-CLProgress ('COMMAND ' + $command)
    Write-CLProgress ('LOG ' + $stdoutPath + ' / ' + $stderrPath)
    try {
        $process.StartInfo.FileName = $FilePath
        $process.StartInfo.Arguments = $quoted -join ' '
        $process.StartInfo.WorkingDirectory = $WorkingDirectory
        $process.StartInfo.UseShellExecute = $false
        $process.StartInfo.CreateNoWindow = $true
        $process.StartInfo.RedirectStandardInput = $true
        $process.StartInfo.RedirectStandardOutput = $true
        $process.StartInfo.RedirectStandardError = $true
        $process.StartInfo.StandardOutputEncoding = $encoding
        $process.StartInfo.StandardErrorEncoding = $encoding
        foreach ($key in $ChildEnvironment.Keys) {
            $process.StartInfo.EnvironmentVariables[[string]$key] = [string]$ChildEnvironment[$key]
        }
        # Open log writers before process startup, so a disk error cannot leave an unobserved child.
        foreach ($kind in @('stdout','stderr')) {
            $path = if ($kind -eq 'stdout') { $stdoutPath } else { $stderrPath }
            $writer = [IO.StreamWriter]::new($path, $false, $encoding)
            $writer.AutoFlush = $true
            $streams += [pscustomobject]@{
                Kind=$kind; Writer=$writer; Reader=$null; Buffer=([char[]](New-Object char[] 4096))
                Pending=$null; Done=$false; Captured=([Text.StringBuilder]::new())
            }
        }
        if (-not $process.Start()) { throw 'Process.Start returned false.' }
        $started = $true
        $childId = $process.Id
        $process.StandardInput.Close() # Never wait indefinitely for a hidden interactive prompt.
        $streams[0].Reader = $process.StandardOutput
        $streams[1].Reader = $process.StandardError
        foreach ($stream in $streams) {
            $stream.Pending = $stream.Reader.ReadAsync($stream.Buffer, 0, $stream.Buffer.Length)
        }
        Write-CLProgress ('RUNNING {0} | PID={1}' -f $Name, $childId)
        $nextHeartbeat = [double]$HeartbeatSeconds
        $lastOutputAt = 0.0
        $exitObservedAt = -1.0
        while ($true) {
            foreach ($stream in $streams) {
                # Limit one drain pass so an output flood cannot starve the timeout or the other pipe.
                $drained = 0
                while (-not $stream.Done -and $stream.Pending.IsCompleted -and $drained -lt 64) {
                    $drained++
                    $count = $stream.Pending.GetAwaiter().GetResult()
                    if ($count -eq 0) { $stream.Done = $true; break }
                    $text = [string]::new($stream.Buffer, 0, [int]$count)
                    $stream.Writer.Write($text)
                    Write-Host -NoNewline $text
                    if ($CaptureOutput) {
                        if ($stream.Captured.Length + $text.Length -gt 2097152) { throw 'Diagnostic output exceeded the 2 MiB capture limit; full output is in the stream log.' }
                        [void]$stream.Captured.Append($text)
                    }
                    $lastOutputAt = $clock.Elapsed.TotalSeconds
                    $stream.Pending = $stream.Reader.ReadAsync($stream.Buffer, 0, $stream.Buffer.Length)
                }
            }
            $elapsed = $clock.Elapsed.TotalSeconds
            if ($process.HasExited) {
                if ($exitObservedAt -lt 0) { $exitObservedAt = $elapsed }
                if ($streams[0].Done -and $streams[1].Done) { break }
                if ($elapsed - $exitObservedAt -gt 5) { throw 'The child exited but an output pipe stayed open for over 5 seconds. This step is not considered successful.' }
            }
            if ($elapsed -ge $TimeoutSeconds) {
                $timedOut = $true
                throw ('TIMEOUT in {0} after {1}s. No successful build is being reported. See {2} and {3}.' -f $Name, $TimeoutSeconds, $stdoutPath, $stderrPath)
            }
            if ($elapsed -ge $nextHeartbeat) {
                Write-CLProgress ('WAIT {0} | PID={1} | elapsed={2:N0}s | no new output={3:N0}s | limit={4}s' -f $Name, $childId, $elapsed, ($elapsed - $lastOutputAt), $TimeoutSeconds)
                $nextHeartbeat = $elapsed + $HeartbeatSeconds
            }
            Start-Sleep -Milliseconds 100
        }
        $exitCode = $process.ExitCode
        if ($AllowedExitCodes -notcontains $exitCode) {
            throw ('{0} failed with exit code {1}. See {2} and {3}.' -f $Name, $exitCode, $stdoutPath, $stderrPath)
        }
        $success = $true
        Write-CLProgress ('DONE {0} | exit={1} | elapsed={2:N1}s' -f $Name, $exitCode, $clock.Elapsed.TotalSeconds)
        return [pscustomobject]@{
            ExitCode=$exitCode; StdOut=$streams[0].Captured.ToString(); StdErr=$streams[1].Captured.ToString()
            StdOutPath=$stdoutPath; StdErrPath=$stderrPath; DurationSeconds=$clock.Elapsed.TotalSeconds
        }
    } catch {
        $failure = $_.Exception.Message
        Write-CLProgress ('FAILED {0}: {1}' -f $Name, $failure)
        throw
    } finally {
        if ($started) {
            try { if (-not $process.HasExited) { Stop-CLProcessTree $process } }
            catch { Write-CLProgress ('WARNING: process cleanup failed: ' + $_.Exception.Message) }
        }
        foreach ($stream in $streams) {
            try { $stream.Writer.Dispose() } catch { Write-CLProgress ('WARNING: log close: ' + $_.Exception.Message) }
        }
        $process.Dispose()
        $clock.Stop()
        try {
            [ordered]@{
                name=$Name; command=$command; startedUtc=$startedUtc; durationSeconds=$clock.Elapsed.TotalSeconds
                pid=$childId; exitCode=$exitCode; success=$success; timedOut=$timedOut; error=$failure
                stdout=$stdoutPath; stderr=$stderrPath
            } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $statusPath -Encoding UTF8
        } catch { Write-CLProgress ('WARNING: status report write: ' + $_.Exception.Message) }
    }
}
