﻿# Optional actual PowerShell regression tests for the inventory worker.
# These use copies of the local CLR assembly as fixtures. They do NOT validate any game API.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'BuildSupport.ps1')
$root = Split-Path -Parent $PSScriptRoot
$reports = Join-Path $root 'build-reports\inventory-tests'
$temp = Join-Path ([IO.Path]::GetTempPath()) ('CruiserLineup-목록 회귀 테스트-' + [Guid]::NewGuid().ToString('N'))
$game = Join-Path $temp 'fixture game (NOT THE GAME)'
$bep = Join-Path $temp '빌드용\BepInEx'
$managed = Join-Path $game 'Lethal Company_Data\Managed'
$core = Join-Path $bep 'core'
$configDir = Join-Path $bep 'config'
$config = Join-Path $configDir 'BepInEx.cfg'
$shell = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
$worker = Join-Path $PSScriptRoot 'BuildWorker.ps1'
$fixtureAssembly = [object].Assembly.Location
$rows = [System.Collections.Generic.List[object]]::new()
$utf8 = [Text.UTF8Encoding]::new($true)
$failed = 0
New-Item -ItemType Directory -Path $reports,$managed,$core,$configDir -Force | Out-Null

function Assert-CLInventoryTest {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}
function Run-CLInventoryCase {
    param([string]$Name, [AllowNull()][string]$ConfigText, [string[]]$ExpectedLines, [string]$ExpectedStatus, [switch]$MissingFile)
    try {
        if ($MissingFile) {
            if ([IO.File]::Exists($config)) { [IO.File]::Delete($config) }
        } else { [IO.File]::WriteAllText($config, $ConfigText, $utf8) }
        $before = if ($MissingFile) { '' } else { (Get-FileHash -LiteralPath $config -Algorithm SHA256).Hash }
        $output = Join-Path $reports ($Name + '.environment.json')
        if ([IO.File]::Exists($output)) { [IO.File]::Delete($output) }
        $r = Invoke-CLProcess -Name $Name -FilePath $shell -Arguments @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$worker,'-Mode','Inventory','-GamePath',$game,'-BepInExPath',$bep,'-OutputPath',$output) -WorkingDirectory $temp -ReportDirectory $reports -TimeoutSeconds 20 -CaptureOutput
        $text = [IO.File]::ReadAllText($output, [Text.Encoding]::UTF8)
        $data = ConvertFrom-Json -InputObject $text
        Assert-CLInventoryTest ($data.inventoryToolRevision -eq '0.1.0-buildfix2') 'Wrong worker revision.'
        Assert-CLInventoryTest ($text.Length -lt 65536) 'Report unexpectedly expanded.'
        Assert-CLInventoryTest ($text -notmatch '"(PSPath|PSDrive|PSProvider|PSParentPath)"\s*:') 'Provider metadata leaked into report.'
        Assert-CLInventoryTest ($data.gamePath -ceq $game -and $data.bepinexPath -ceq $bep) 'Unicode/space path changed.'
        Assert-CLInventoryTest ($data.assemblies -is [System.Array] -and $data.assemblies.Count -eq 6) 'Expected six fixture references.'
        Assert-CLInventoryTest ($data.hideManagerGameObjectStatus -ceq $ExpectedStatus) 'Wrong config status.'
        Assert-CLInventoryTest ($data.hideManagerGameObject -is [System.Array]) 'Config lines are not an array.'
        Assert-CLInventoryTest ($data.hideManagerGameObject.Count -eq $ExpectedLines.Count) 'Wrong config-line count.'
        for ($i=0; $i -lt $ExpectedLines.Count; $i++) {
            Assert-CLInventoryTest ($data.hideManagerGameObject[$i] -is [string] -and $data.hideManagerGameObject[$i] -ceq $ExpectedLines[$i]) 'Config line changed or is a wrapped object.'
        }
        Assert-CLInventoryTest ($r.StdOut.Contains('REPORT JSON DONE:') -and $r.StdOut.Contains('REPORT WRITE DONE:')) 'Missing fine-grained progress.'
        foreach ($entry in $data.assemblies) {
            $wantHash = (Get-FileHash -LiteralPath $entry.path -Algorithm SHA256).Hash
            Assert-CLInventoryTest ($entry.sha256 -ceq $wantHash) 'Reference hash did not round-trip.'
        }
        if ($MissingFile) {
            Assert-CLInventoryTest (-not [IO.File]::Exists($config)) 'Worker created a missing config.'
        } else {
            Assert-CLInventoryTest ((Get-FileHash -LiteralPath $config -Algorithm SHA256).Hash -ceq $before) 'Worker changed BepInEx.cfg.'
        }
        $rows.Add([pscustomobject]@{name=$Name;status='PASS';error=$null;durationSeconds=$r.DurationSeconds})
        Write-Host ('PASS: ' + $Name)
    } catch {
        $rows.Add([pscustomobject]@{name=$Name;status='FAIL';error=$_.Exception.Message;durationSeconds=$null})
        Write-Host ('FAIL: ' + $Name + ': ' + $_.Exception.Message)
    }
}
try {
    Write-Host 'Inventory regression tests: local CLR fixture assemblies only. NOT game/API/C# tests.'
    foreach ($name in @('Assembly-CSharp.dll','Unity.InputSystem.dll','UnityEngine.CoreModule.dll','Unity.Netcode.Runtime.dll')) {
        [IO.File]::Copy($fixtureAssembly, (Join-Path $managed $name))
    }
    foreach ($name in @('BepInEx.dll','0Harmony.dll')) { [IO.File]::Copy($fixtureAssembly, (Join-Path $core $name)) }
    Run-CLInventoryCase -Name 'false-one-line-unicode' -ConfigText "# 한국어 설정`r`n[Chainloader]`r`nHideManagerGameObject = false`r`n" -ExpectedLines @('HideManagerGameObject = false') -ExpectedStatus 'matched-lines'
    Run-CLInventoryCase -Name 'true-one-line' -ConfigText "[Chainloader]`r`nHideManagerGameObject = true`r`n" -ExpectedLines @('HideManagerGameObject = true') -ExpectedStatus 'matched-lines'
    Run-CLInventoryCase -Name 'missing-file' -MissingFile -ExpectedLines @() -ExpectedStatus 'file-not-found'
    Run-CLInventoryCase -Name 'missing-key-not-false' -ConfigText "[Chainloader]`r`n# HideManagerGameObject = false`r`n" -ExpectedLines @() -ExpectedStatus 'key-not-found'
    Run-CLInventoryCase -Name 'empty-file' -ConfigText '' -ExpectedLines @() -ExpectedStatus 'key-not-found'
    Run-CLInventoryCase -Name 'duplicate-lines-preserved' -ConfigText "HideManagerGameObject = false`r`nHideManagerGameObject = true`r`n" -ExpectedLines @('HideManagerGameObject = false','HideManagerGameObject = true') -ExpectedStatus 'matched-lines'
    Run-CLInventoryCase -Name 'unicode-inline-comment' -ConfigText "  HideManagerGameObject = false # 설정 기록만`r`n" -ExpectedLines @('  HideManagerGameObject = false # 설정 기록만') -ExpectedStatus 'matched-lines'
    try {
        $bad = Join-Path $managed 'Assembly-CSharp.dll'
        [IO.File]::WriteAllText($bad, 'invalid assembly fixture', $utf8)
        $output = Join-Path $reports 'invalid-reference.environment.json'
        if ([IO.File]::Exists($output)) { [IO.File]::Delete($output) }
        $rejected = $false
        try {
            [void](Invoke-CLProcess -Name 'invalid-reference' -FilePath $shell -Arguments @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$worker,'-Mode','Inventory','-GamePath',$game,'-BepInExPath',$bep,'-OutputPath',$output) -WorkingDirectory $temp -ReportDirectory $reports -TimeoutSeconds 20)
        } catch { $rejected = $true }
        $status = ConvertFrom-Json -InputObject ([IO.File]::ReadAllText((Join-Path $reports 'invalid-reference.status.json'), [Text.Encoding]::UTF8))
        Assert-CLInventoryTest ($rejected -and $status.exitCode -eq 1 -and -not $status.success -and -not $status.timedOut) 'Invalid reference was not an explicit non-timeout failure.'
        Assert-CLInventoryTest (-not [IO.File]::Exists($output)) 'Invalid reference produced a successful report.'
        $rows.Add([pscustomobject]@{name='invalid-reference-rejected';status='PASS';error=$null})
        Write-Host 'PASS: invalid-reference-rejected'
    } catch {
        $rows.Add([pscustomobject]@{name='invalid-reference-rejected';status='FAIL';error=$_.Exception.Message})
        Write-Host ('FAIL: invalid-reference-rejected: ' + $_.Exception.Message)
    }
    $failed = @($rows | Where-Object { $_.status -eq 'FAIL' }).Count
    [ordered]@{classification='Actual PowerShell fixture regression tests ONLY; NOT actual game API tests';powershell=$PSVersionTable.PSVersion.ToString();platform=[Environment]::OSVersion.ToString();tests=$rows.ToArray();failed=$failed} |
        ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $reports 'summary.json') -Encoding UTF8
    Write-Host ('Inventory fixture tests: ' + ($rows.Count - $failed) + ' passed, ' + $failed + ' failed. Not game tests.')
} finally {
    if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Recurse -Force }
}
if ($failed -gt 0) { exit 1 }
