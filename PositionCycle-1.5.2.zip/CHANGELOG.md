# PositionCycle 1.5.2

## 1.5.2 — v80+ 렌더링/occlusion culling 상태 재동기화

- v80에서 추가된 바닐라 실내 거리/방 culling 때문에 임의 순간이동 후 이전 방 기준의 가시성 상태가 남아 벽이 사라지거나 화면이 비정상적으로 밝거나 어두워질 수 있는 문제를 수정.
- 실제 v81 `StartOfRound.SetOcclusionCullerToPosition(Vector3)`와 `UpdateOcclusionCuller()` API를 시작 시 검증.
- 모든 로컬 owner 순간이동에서 목적지 `AudioReverbPreset`을 재적용하고, 시설 내부 목적지는 occlusion culler origin을 즉시 새 플레이어 위치로 이동.
- 순간이동 직후 / 다음 프레임 / 약 0.12초 뒤에 vanilla view state를 재동기화해 출발 지점 trigger callback이 목적지 상태를 덮는 race를 완화.
- 1.5.1의 3인 이상 authoritative roster 수정, 60초 주기, 바닐라 텔레포터 연출, 아이템 드롭은 유지.
- protocol 8 / version 1.5.2로 올려 이전 빌드와 혼용 차단.

## 1.5.2 — 3인 이상 roster 검증 및 부분 순간이동 방지 보강

- 실제 3인 로그에서 `client=2`가 `ROSTER_MISMATCH_OR_MISSING_SELF`로 PREPARE를 거절해 회차가 반복 취소되는 원인을 확인.
- 전체 활성 플레이어 roster의 최종 결정권을 호스트/서버로 한정.
- 게스트는 원격 플레이어 복제 상태 전체를 호스트와 완전 일치시킬 필요 없이, 자기 로컬 owner의 `ClientId`/`NetworkObjectId`/소유권을 중심으로 PREPARE를 검증.
- 게스트의 원격 roster가 다르면 `CLIENT_REMOTE_ROSTER_VIEW_DIFF` 경고만 남기고, 로컬 owner가 유효하면 서버의 authoritative plan을 수락.
- COMMIT 단계에서 전체 roster를 다시 재검증하지 않도록 변경. PREPARE에서 확정된 frozen plan을 실행하여 한 클라이언트만 뒤늦게 거절하고 나머지 둘만 이동하는 위험을 줄임.
- COMMIT 직전 `isPlayerControlled`/`isPlayerDead`가 일시적으로 달라져도 안정적인 local owner identity가 유지되면 이미 PREPARE된 plan을 실행하고 `COMMIT_LOCAL_STATE_DRIFT`로 진단.
- protocol 8 / version 1.5.2로 올려 이전 빌드와 혼용 차단.
- 1.5.0의 시설↔실외 밝기/환경 프리셋 동기화 수정, 60초 주기, 바닐라 6초 예고 연출, `DropAllHeldItemsAndSync` 경로를 그대로 포함.
- buildfix3의 one-command build 및 `.Path`/`.ProviderPath` 비의존 경로 처리 유지.

## 이전 변경

- 1.5.0: 시설↔실외 환경/밝기 상태 동기화.
- 1.4.0: 실제 v81 ShipTeleporter의 3초+3초 예고 연출 및 `DropAllHeldItemsAndSync` 경로 반영.
- 1.3.0: 주기를 60초로 변경하고 전원 Ready + 활성 2명부터 타이머 시작.
- 1.2.0: 전원 설치 핸드셰이크 및 현재 DropAllHeldItems API 대응.
