# PositionCycle 1.5.2 — 60초마다 플레이어 위치 순환

## 1.5.2 핵심 — v80+ 바닐라 실내 culling 재동기화

Lethal Company v80부터 실내에는 플레이어 주변 방만 렌더링하는 바닐라 거리/occlusion culling이 추가됐습니다. 좌표만 멀리 순간이동하면 culling origin이 출발 방에 남을 수 있어 **벽/방이 투명해지거나 사라지고, 반대로 이전 구역의 안개·조명이 남아 화면이 지나치게 밝거나 어두워지는 현상**이 발생할 수 있습니다.

1.5.2는 각 로컬 owner 순간이동에서 목적지 `AudioReverbPreset`을 매번 재적용하고, 시설 내부 목적지라면 실제 v81 `StartOfRound.SetOcclusionCullerToPosition(...)`으로 culling origin을 새 위치로 즉시 이동시킵니다. 이어 `UpdateOcclusionCuller()`를 강제로 실행하고, Unity 카메라/trigger 갱신 순서 때문에 상태가 다시 덮일 가능성을 줄이기 위해 다음 프레임과 약 0.12초 뒤에도 같은 바닐라 view-state 동기화를 반복합니다.

## 이번 수정의 핵심 — 3인 이상 PREPARE/COMMIT 안정화

실제 3인 로그에서 호스트는 3명의 snapshot을 정상 생성했지만, 세 번째 클라이언트가 자기 PC에서 보이는 **원격 플레이어 roster 전체**를 호스트 roster와 완전 동일 비교하면서 `ROSTER_MISMATCH_OR_MISSING_SELF`를 반환했습니다. 그 결과 2인에서는 잘 되지만 3인이 되면 PREPARE 단계에서 회차가 취소될 수 있었습니다.

1.5.2은 **호스트/서버가 전체 참가자 roster의 authoritative source**가 되도록 바꿉니다. 게스트는 자기 로컬 owner의 `ClientId`/`NetworkObjectId`/소유권을 검증하며, 늦은 참가·씬 전환 등으로 원격 복제 상태가 잠시 달라도 전체 회차를 거절하지 않습니다. 차이는 `CLIENT_REMOTE_ROSTER_VIEW_DIFF` 로그로만 남깁니다.

또한 COMMIT에서는 PREPARE에서 이미 검증된 frozen plan을 전체 roster로 다시 판정하지 않습니다. 이렇게 해서 한 클라이언트만 COMMIT 직전에 재검증에 실패하고 다른 두 명만 이동하는 부분 적용 위험을 줄였습니다.


## 이번 수정의 핵심 — 실내/실외 밝기 상태 동기화

1.4.0은 좌표와 `isInsideFactory`/함선 플래그만 바꿨고, 바닐라 순간이동기가 함께 호출하는 `AudioReverbTrigger.ChangeAudioReverbForPlayer(...)`를 호출하지 않았습니다. 이 클래스는 이름과 달리 오디오뿐 아니라 실내 조명, 분위기, 로컬 안개, 날씨 전환 상태도 함께 다룹니다. 그래서 시설↔실외 순환 직후 카메라가 이전 구역의 어두운 상태를 유지하다가 실제 출입구를 다시 통과했을 때만 정상화될 수 있었습니다.

1.5.2은 **시설 경계를 넘는 순환 이동에 한해** 바닐라 환경 프리셋을 먼저 적용한 뒤 기존 `TeleportPlayer(...)`를 실행합니다. 시설 목적지는 프리셋 2, 비시설 목적지는 프리셋 3을 사용합니다. 이는 바닐라 역순간이동기/일반 순간이동기와 같은 `AudioReverbPresets` 경로입니다. 같은 시설 내부끼리 멀리 이동하는 경우에도 culling origin이 바뀌어야 하므로 환경/culling 상태를 다시 동기화합니다.

60초 고정 주기, 바닐라 6초 순간이동 예고 연출, `DropAllHeldItemsAndSync(...)`, 전원 동일 모드 설치 조건은 그대로 유지합니다.

## 동작 규칙

- **방에 연결된 모든 사람이 PositionCycle 1.5.2의 동일 호환 빌드를 설치해야 기능이 활성화됩니다. 같은 모드를 낀 활성 생존 플레이어가 2명 이상 확인된 시점부터 첫 60초를 셉니다.** 죽어서 관전 중인 연결 클라이언트도 방 구성원이므로 모드 핸드셰이크 대상입니다.
- 실제 위치 순환 대상은 현재 `isPlayerControlled`이며 살아 있는 플레이어입니다.
- 0~1명만 살아 있으면 그 시간 경계는 아무 일도 하지 않습니다.
- 2명: `1 → 2의 원래 위치`, `2 → 1의 원래 위치`
- 3명: `1 → 2`, `2 → 3`, `3 → 1`
- 4명: `1 → 2`, `2 → 3`, `3 → 4`, `4 → 1`
- N명: 슬롯 순서의 i번째 플레이어가 다음 플레이어의 **이동 직전 위치**로 이동하고, 마지막은 첫 번째 위치로 갑니다.
- 각 플레이어가 들고 있던 아이템은 자기 출발 위치에 내려놓고 사람만 이동합니다.
- 알림, 채팅 명령어, 키바인딩, 사용자 설정은 만들지 않았습니다.

## 60초 스케줄

호스트가 **모든 접속자의 호환 모드 핸드셰이크 완료 + 활성 생존 플레이어 2명 이상**을 처음 확인한 서버 시간을 기준점으로 잡습니다. 첫 순간이동은 정확히 그 시점에서 60초 뒤이며 이후 경계는:

`+60초 → +120초 → +180초 → ...`

입니다. 이전 이동이 몇 초 늦게 끝났더라도 다음 시간이 `이동 완료 + 60초`으로 밀리지 않습니다.

정확한 경계 시점에 월드가 준비되지 않았거나 방 구성원 중 한 명이라도 모드가 없거나 호환 핸드셰이크가 완료되지 않았다면 **그 경계는 건너뜁니다.** 다음 시도는 원래 기준점의 다음 60초 경계입니다. 부분 인원만 이동시키지 않습니다.

네트워크 Prepare/Commit 검증 때문에 실제 화면상의 순간이동은 서버 시간 경계 직후 통신 지연만큼 늦을 수 있습니다. 스케줄 기준 자체는 고정 경계입니다.

## 왜 모두 설치해야 하나

호스트가 전체 순환 계획과 원래 위치를 결정합니다. Commit을 받은 각 PC는 자기 로컬 소유 플레이어에 대해서만:

1. 현재 인벤토리를 확인
2. 게임의 기본 `DropAllHeldItemsAndSync(...)` 호출
3. 드롭 후 인벤토리/아이템 분리 확인
4. 다음 플레이어의 저장된 위치로 `TeleportPlayer`
5. 성공/실패 ACK 전송

을 수행합니다. 살아 있는 각 플레이어는 자기 PC에서 정확히 1회의 드롭+이동을 수행하며, 관전자/사망자는 0회의 정상 ACK를 보냅니다.

## 빌드 — 명령어 하나

기본 경로가 이미 들어 있습니다.

- 게임: `C:\Program Files (x86)\Steam\steamapps\common\Lethal Company`
- BepInEx: `C:\Users\kmh04\AppData\Roaming\com.kesomannen.gale\lethal-company\profiles\빌드용\BepInEx`

압축을 푼 폴더에서 실행:

```bat
build.cmd
```

성공할 때만 다음 파일이 생성됩니다.

`artifacts\PositionCycle-1.5.2.zip`

그 ZIP을 Gale Local mod로 넣거나, 내부 `BepInEx/plugins/PositionCycle/PositionCycle.dll`을 모든 참가자의 같은 프로필에 설치하세요. **이전 버전과 섞지 마세요.** 1.5.2은 protocol 8입니다.

`build.cmd`는 BOM 없이 저장하여 `癤?echo off` 문제가 나지 않게 했고, 콘솔 코드페이지를 UTF-8로 맞춥니다. `build.ps1`은 한글 기본 경로 보존을 위해 UTF-8 BOM을 유지합니다.

## 정상 시작 로그에서 확인할 것

초기화가 성공하면 최소한 다음 단계가 나와야 합니다.

`PLUGIN_LOAD` → `CSHARP_CODEC_DROP_SEQUENCE_SELFTEST_OK` → `API_CONTRACT_OK` → `RUNTIME_FIRST_UPDATE` → `NETWORK_REGISTER`

호스트에서는 모든 방 구성원이 준비되기 전 `ALL_ROOM_MOD_REQUIRED`가 보일 수 있습니다. 전원이 준비되면 `STATE HOST_60S_TIMER_RUNNING_ALL_MODDED`가 나타납니다.

첫 60초 경계에서 `PREPARE_CREATED` → `PREPARED_ACK` → `COMMIT_DECIDED` → 각 PC의 `LOCAL_APPLY_RESULT` → 호스트의 `CYCLE_RESULT` 순서를 확인합니다.

## 밝기 수정 확인 로그

시설↔실외 경계를 넘는 회차에서는 각 소유자 PC에 다음 로그가 나와야 합니다.

`VANILLA_ENVIRONMENT_APPLIED ... VANILLA_ENV_PRESET_APPLIED:2` — 시설로 이동

`VANILLA_ENVIRONMENT_APPLIED ... VANILLA_ENV_PRESET_APPLIED:3` — 시설 밖/비시설로 이동

같은 구역끼리 이동해도 1.5.2에서는 `VANILLA_ENVIRONMENT_APPLIED`와 `VANILLA_VIEW_RESYNC`가 정상입니다. 프리셋이 준비되지 않았다면 PREPARE 단계에서 회차를 거절하므로 아이템을 먼저 버린 뒤 이동 실패하는 상황을 피합니다.

## 현재 검증 상태

이번 대화에서 실제 게임 v81 DLL 3개를 받아 메타데이터/IL 분석까지 수행했습니다. 다만 이 작성 환경에는 .NET SDK가 없어 **1.5.2 C# 컴파일과 게임 실행은 여기서 수행하지 못했습니다.** 사용자가 제공한 1.2.0 로그에서는 `API_CONTRACT_OK`, 호스트/게스트 `NETWORK_REGISTER`, `PEER_HANDSHAKE sessionConfirmed=True`, 게스트 `STATE GUEST_SESSION_BOUND`까지 확인됐고, `CYCLE` 실행 기록은 없었습니다. 1.5.2은 그 로그에서 확인된 3600초 스케줄을 60초로 고친 소스입니다.

`build.cmd`가 사용자 PC의 실제 현재 게임 어셈블리를 참조해 다시 컴파일하므로, 빌드 성공 여부가 첫 번째 실제 검증입니다. 이후 실제 2인/3인/4인 및 역할 교대 테스트는 별도입니다.

## 1.5.2 실제 게임 순간이동기 연출 경로

업로드된 게임 v81 `Assembly-CSharp.dll`의 실제 `ShipTeleporter` IL을 기준으로 구현했습니다. 일반 순간이동기의 `beamUpPlayer`는 3초 회전 대기 후 `PlayerControllerB.beamUpParticle`/전용 SFX를 재생하고 다시 3초 뒤 `DropAllHeldItemsAndSync(...)` → 속도 초기화 → `TeleportPlayer(...)`를 실행합니다. PositionCycle은 이 6초 빌드업을 각 60초 경계 직전에 재현하되, 목적지는 고정 텔레포터 패드가 아니라 **경계 순간에 캡처한 다음 플레이어의 현재 위치**로 바꿉니다. 따라서 1→2, 2→3, …, 마지막→1 순환 규칙을 유지합니다.

실제 일반 ShipTeleporter 오브젝트가 현재 씬에 있으면 버튼/회전/빔 효과음도 그 오브젝트의 원본 필드에서 재생합니다. 구매되지 않아 오브젝트가 없더라도 각 플레이어의 원본 `beamUpParticle`은 사용합니다. 아이템 드롭은 직접 흉내내지 않고 게임의 `DropAllHeldItemsAndSync`를 호출합니다.

### 60초 경계의 실제 연출 타이밍

- 54초: 바닐라 일반 순간이동기의 버튼/회전 효과를 시작(일반 ShipTeleporter 오브젝트가 존재할 때).
- 57초: 모든 활성 플레이어에 원본 `beamUpParticle`과 바닐라 몸체 효과음을 재생. 각 클라이언트에서 모든 대상자를 표시하므로 서로의 예고 효과가 보입니다.
- 60초: 그 순간의 플레이어 위치를 캡처하고 1→2→…→1 순환 목적지를 만든 뒤, 각 소유자 클라이언트가 `DropAllHeldItemsAndSync(...)` 후 `TeleportPlayer(...)`를 실행합니다.
- 120초/180초/...: 같은 고정 경계를 반복합니다.
